package com.potatooptimizer.mixins;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BlockEntity.class)
public class BlockEntityTickMixin {
    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void slowFarBlockEntities(CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        BlockEntity self = (BlockEntity)(Object)this;
        if (self.getPos().getSquaredDistance(mc.player.getBlockPos()) > 64 * 64) {
            if (mc.world.getTime() % 5 != 0) ci.cancel(); // tick slower
        }
    }
}