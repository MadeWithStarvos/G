package com.potatooptimizer;

import net.fabricmc.api.ClientModInitializer;

public class PotatoOptimizer implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        System.out.println("Potato Optimizer (Balanced Mode) loaded");
    }
}