import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  role: text("role", { enum: ["admin", "user"] }).default("user").notNull(),
  plan: text("plan", { enum: ["free", "pro", "enterprise", "custom"] }).default("free").notNull(),
  avatarUrl: text("avatar_url"),
  twoFactorEnabled: boolean("two_factor_enabled").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const nodes = pgTable("nodes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  ipAddress: text("ip_address").notNull(),
  status: text("status", { enum: ["online", "offline", "maintenance"] }).default("online"),
  cpuCores: integer("cpu_cores").notNull(),
  ramGb: integer("ram_gb").notNull(),
  diskTb: integer("disk_tb").notNull(),
  region: text("region").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const vms = pgTable("vms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  userId: integer("user_id").notNull(),
  nodeId: integer("node_id").notNull(),
  os: text("os").notNull(), // Ubuntu 22.04, Debian 11, etc.
  status: text("status", { enum: ["running", "stopped", "provisioning", "error"] }).default("provisioning"),
  ipAddress: text("ip_address"),
  cpuCores: integer("cpu_cores").notNull(),
  ramGb: integer("ram_gb").notNull(),
  diskGb: integer("disk_gb").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const storageVolumes = pgTable("storage_volumes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  userId: integer("user_id").notNull(),
  vmId: integer("vm_id"), // Nullable if not attached
  sizeGb: integer("size_gb").notNull(),
  status: text("status", { enum: ["attached", "detached", "creating"] }).default("detached"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: integer("amount").notNull(), // in cents
  status: text("status", { enum: ["paid", "pending", "overdue"] }).default("pending"),
  date: timestamp("date").defaultNow(),
  pdfUrl: text("pdf_url"),
});

export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  action: text("action").notNull(),
  details: text("details"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const firewallRules = pgTable("firewall_rules", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  vmId: integer("vm_id").notNull(),
  name: text("name").notNull(),
  type: text("type", { enum: ["inbound", "outbound"] }).notNull(),
  protocol: text("protocol", { enum: ["tcp", "udp", "icmp"] }).notNull(),
  portRange: text("port_range").notNull(),
  source: text("source").notNull(),
  action: text("action", { enum: ["allow", "deny"] }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertFirewallRuleSchema = createInsertSchema(firewallRules).omit({ id: true, createdAt: true });
export type FirewallRule = typeof firewallRules.$inferSelect;
export type InsertFirewallRule = z.infer<typeof insertFirewallRuleSchema>;

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  hostname: text("hostname").default("Matrix Cloud"),
  appIcon: text("app_icon").default("M"),
});

// === RELATIONS ===

export const usersRelations = relations(users, ({ many }) => ({
  vms: many(vms),
  volumes: many(storageVolumes),
  invoices: many(invoices),
  logs: many(activityLogs),
}));

export const vmsRelations = relations(vms, ({ one, many }) => ({
  user: one(users, { fields: [vms.userId], references: [users.id] }),
  node: one(nodes, { fields: [vms.nodeId], references: [nodes.id] }),
  volumes: many(storageVolumes),
  firewallRules: many(firewallRules),
}));

export const firewallRulesRelations = relations(firewallRules, ({ one }) => ({
  vm: one(vms, { fields: [firewallRules.vmId], references: [vms.id] }),
}));

export const nodesRelations = relations(nodes, ({ many }) => ({
  vms: many(vms),
}));

// === SCHEMAS ===

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertVmSchema = createInsertSchema(vms).omit({ id: true, createdAt: true, status: true, ipAddress: true });
export const insertNodeSchema = createInsertSchema(nodes).omit({ id: true, createdAt: true });
export const insertVolumeSchema = createInsertSchema(storageVolumes).omit({ id: true, createdAt: true, status: true });
export const insertSettingsSchema = createInsertSchema(settings).omit({ id: true });

// === TYPES ===

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Settings = typeof settings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;

export type Vm = typeof vms.$inferSelect;
export type InsertVm = z.infer<typeof insertVmSchema>;

export type Node = typeof nodes.$inferSelect;
export type InsertNode = z.infer<typeof insertNodeSchema>;

export type Volume = typeof storageVolumes.$inferSelect;
export type Invoice = typeof invoices.$inferSelect;
export type ActivityLog = typeof activityLogs.$inferSelect;

export type VmActionRequest = {
  action: "start" | "stop" | "reboot" | "shutdown" | "reset_password" | "generate_ssh";
};

export type VmResizeRequest = {
  cpuCores: number;
  ramGb: number;
  diskGb: number;
};

// Dashboard Stats
export type UserDashboardStats = {
  activeVms: number;
  totalCost: number;
  cpuUsage: number;
  ramUsage: number;
};

export type AdminDashboardStats = {
  totalUsers: number;
  totalVms: number;
  totalNodes: number;
  systemHealth: number;
};
