import { z } from 'zod';
import { insertUserSchema, insertVmSchema, insertNodeSchema, insertVolumeSchema, vms, nodes, users, storageVolumes, invoices, activityLogs } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  users: {
    list: {
      method: 'GET' as const,
      path: '/api/admin/users',
      responses: {
        200: z.array(z.custom<typeof users.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/admin/users',
      input: insertUserSchema,
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PATCH' as const,
      path: '/api/admin/users/:id',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/admin/users/:id',
      responses: {
        204: z.void(),
      },
    },
  },
  auth: {
    login: {
      method: 'POST' as const,
      path: '/api/auth/login',
      input: z.object({ username: z.string(), password: z.string() }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: z.object({ message: z.string() }),
      },
    },
    logout: {
      method: 'POST' as const,
      path: '/api/auth/logout',
      responses: {
        200: z.void(),
      },
    },
    me: {
      method: 'GET' as const,
      path: '/api/user',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: z.void(),
      },
    },
  },
  stats: {
    user: {
      method: 'GET' as const,
      path: '/api/stats/user',
      responses: {
        200: z.object({
          activeVms: z.number(),
          totalCost: z.number(),
          cpuUsage: z.number(),
          ramUsage: z.number(),
        }),
      },
    },
    admin: {
      method: 'GET' as const,
      path: '/api/stats/admin',
      responses: {
        200: z.object({
          totalUsers: z.number(),
          totalVms: z.number(),
          totalNodes: z.number(),
          systemHealth: z.number(),
        }),
      },
    },
  },
  vms: {
    list: {
      method: 'GET' as const,
      path: '/api/vms',
      responses: {
        200: z.array(z.custom<typeof vms.$inferSelect & { node: typeof nodes.$inferSelect }>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/vms/:id',
      responses: {
        200: z.custom<typeof vms.$inferSelect & { node: typeof nodes.$inferSelect }>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/vms',
      input: insertVmSchema,
      responses: {
        201: z.custom<typeof vms.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    action: {
      method: 'POST' as const,
      path: '/api/vms/:id/action',
      input: z.object({ action: z.enum(["start", "stop", "reboot", "shutdown", "reset_password", "generate_ssh"]) }),
      responses: {
        200: z.object({ message: z.string(), newStatus: z.string().optional(), command: z.string().optional(), details: z.string().optional() }),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/vms/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  nodes: {
    list: {
      method: 'GET' as const,
      path: '/api/nodes',
      responses: {
        200: z.array(z.custom<typeof nodes.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/nodes',
      input: insertNodeSchema,
      responses: {
        201: z.custom<typeof nodes.$inferSelect>(),
      },
    },
  },
  volumes: {
    list: {
      method: 'GET' as const,
      path: '/api/volumes',
      responses: {
        200: z.array(z.custom<typeof storageVolumes.$inferSelect>()),
      },
    },
  },
  invoices: {
    list: {
      method: 'GET' as const,
      path: '/api/invoices',
      responses: {
        200: z.array(z.custom<typeof invoices.$inferSelect>()),
      },
    },
  },
  logs: {
    list: {
      method: 'GET' as const,
      path: '/api/logs',
      responses: {
        200: z.array(z.custom<typeof activityLogs.$inferSelect>()),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
