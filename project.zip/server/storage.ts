import { db } from "./db";
import {
  users, vms, nodes, storageVolumes, invoices, activityLogs, settings, firewallRules,
  type User, type InsertUser, type Vm, type InsertVm, type Node, type InsertNode,
  type Volume, type InsertSettings, type Settings, type ActivityLog, type Invoice,
  type FirewallRule, type InsertFirewallRule
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User>;
  deleteUser(id: number): Promise<void>;
  
  // VMs
  getVms(userId?: number): Promise<(Vm & { node: Node | null })[]>;
  getVm(id: number): Promise<(Vm & { node: Node | null }) | undefined>;
  createVm(vm: InsertVm): Promise<Vm>;
  updateVmStatus(id: number, status: string): Promise<Vm>;
  deleteVm(id: number): Promise<void>;
  
  // Nodes
  getNodes(): Promise<Node[]>;
  getNode(id: number): Promise<Node | undefined>;
  createNode(node: InsertNode): Promise<Node>;
  
  // Volumes
  getVolumes(userId: number): Promise<Volume[]>;
  createVolume(volume: any): Promise<Volume>;
  
  // Firewall
  getFirewallRules(vmId: number): Promise<FirewallRule[]>;
  createFirewallRule(rule: InsertFirewallRule): Promise<FirewallRule>;
  
  // Invoices
  getInvoices(userId: number): Promise<Invoice[]>;
  
  // Logs
  getLogs(userId: number): Promise<ActivityLog[]>;
  createLog(log: { userId: number; action: string; details?: string }): Promise<ActivityLog>;
  
  // Stats
  getUserStats(userId: number): Promise<{ activeVms: number; totalCost: number }>;
  getAdminStats(): Promise<{ totalUsers: number; totalVms: number; totalNodes: number }>;

  // Settings
  getSettings(): Promise<Settings>;
  updateSettings(settings: Partial<Settings>): Promise<Settings>;
}

export class DatabaseStorage implements IStorage {
  async getSettings(): Promise<Settings> {
    const [existing] = await db.select().from(settings).limit(1);
    if (!existing) {
      const [newSettings] = await db.insert(settings).values({}).returning();
      return newSettings;
    }
    return existing;
  }

  async updateSettings(settingsUpdate: Partial<Settings>): Promise<Settings> {
    const current = await this.getSettings();
    const [updated] = await db.update(settings)
      .set(settingsUpdate)
      .where(eq(settings.id, current.id))
      .returning();
    return updated;
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async getUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  async updateUser(id: number, userUpdate: Partial<User>): Promise<User> {
    const [updatedUser] = await db.update(users)
      .set(userUpdate)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  async deleteUser(id: number): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  async getVms(userId?: number): Promise<(Vm & { node: Node | null })[]> {
    const query = db.select().from(vms)
      .leftJoin(nodes, eq(vms.nodeId, nodes.id));
      
    if (userId) {
      query.where(eq(vms.userId, userId));
    }
    
    const results = await query;
    return results.map(r => ({ ...r.vms, node: r.nodes }));
  }

  async getVm(id: number): Promise<(Vm & { node: Node | null }) | undefined> {
    const [result] = await db.select().from(vms)
      .leftJoin(nodes, eq(vms.nodeId, nodes.id))
      .where(eq(vms.id, id));
      
    if (!result) return undefined;
    return { ...result.vms, node: result.nodes };
  }

  async createVm(vm: InsertVm): Promise<Vm> {
    const [newVm] = await db.insert(vms).values(vm).returning();
    return newVm;
  }

  async updateVmStatus(id: number, status: "running" | "stopped" | "provisioning" | "error"): Promise<Vm> {
    const [updatedVm] = await db.update(vms)
      .set({ status })
      .where(eq(vms.id, id))
      .returning();
    return updatedVm;
  }

  async deleteVm(id: number): Promise<void> {
    await db.delete(vms).where(eq(vms.id, id));
  }

  async getNodes(): Promise<Node[]> {
    return await db.select().from(nodes);
  }

  async getNode(id: number): Promise<Node | undefined> {
    const [node] = await db.select().from(nodes).where(eq(nodes.id, id));
    return node;
  }

  async createNode(node: InsertNode): Promise<Node> {
    const [newNode] = await db.insert(nodes).values(node).returning();
    return newNode;
  }

  async getVolumes(userId: number): Promise<Volume[]> {
    return await db.select().from(storageVolumes).where(eq(storageVolumes.userId, userId));
  }

  async createVolume(volume: any): Promise<Volume> {
    const [newVolume] = await db.insert(storageVolumes).values(volume).returning();
    return newVolume;
  }

  async getFirewallRules(vmId: number): Promise<FirewallRule[]> {
    return await db.select().from(firewallRules).where(eq(firewallRules.vmId, vmId));
  }

  async createFirewallRule(rule: InsertFirewallRule): Promise<FirewallRule> {
    const [newRule] = await db.insert(firewallRules).values(rule).returning();
    return newRule;
  }

  async getInvoices(userId: number): Promise<Invoice[]> {
    return await db.select().from(invoices).where(eq(invoices.userId, userId)).orderBy(desc(invoices.date));
  }

  async getLogs(userId: number): Promise<ActivityLog[]> {
    return await db.select().from(activityLogs).where(eq(activityLogs.userId, userId)).orderBy(desc(activityLogs.createdAt));
  }

  async createLog(log: { userId: number; action: string; details?: string }): Promise<ActivityLog> {
    const [newLog] = await db.insert(activityLogs).values(log).returning();
    return newLog;
  }

  async getUserStats(userId: number): Promise<{ activeVms: number; totalCost: number }> {
    const userVms = await db.select().from(vms).where(eq(vms.userId, userId));
    // Mock cost calculation: $10/vm
    return {
      activeVms: userVms.filter(v => v.status === 'running').length,
      totalCost: userVms.length * 1000 // cents
    };
  }

  async getAdminStats(): Promise<{ totalUsers: number; totalVms: number; totalNodes: number }> {
    const [userCount] = await db.select({ count: users.id }).from(users);
    const [vmCount] = await db.select({ count: vms.id }).from(vms);
    const [nodeCount] = await db.select({ count: nodes.id }).from(nodes);
    
    return {
      totalUsers: Number(userCount?.count || 0),
      totalVms: Number(vmCount?.count || 0),
      totalNodes: Number(nodeCount?.count || 0)
    };
  }
}

export const storage = new DatabaseStorage();
