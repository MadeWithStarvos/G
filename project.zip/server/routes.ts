import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Authentication (Passport)
  setupAuth(app);

  // === USERS (Admin) ===
  app.get(api.users.list.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') return res.sendStatus(403);
    const usersList = await storage.getUsers();
    res.json(usersList);
  });

  app.post(api.users.create.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') return res.sendStatus(403);
    try {
      const input = api.users.create.input.parse(req.body);
      const user = await storage.createUser(input);
      await storage.createLog({ userId: req.user!.id, action: "user.create", details: `Created user ${user.username}` });
      res.status(201).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const id = Number(req.params.id);
    if (req.user!.role !== 'admin' && req.user!.id !== id) return res.sendStatus(403);
    
    const updateData: any = {};
    if (req.body.email) updateData.email = req.body.email;
    if (req.body.password) updateData.password = req.body.password;
    
    const user = await storage.updateUser(id, updateData);
    res.json(user);
  });

  app.patch(api.users.update.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') return res.sendStatus(403);
    const id = Number(req.params.id);
    const user = await storage.updateUser(id, req.body);
    res.json(user);
  });

  app.delete(api.users.delete.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') return res.sendStatus(403);
    await storage.deleteUser(Number(req.params.id));
    res.sendStatus(204);
  });

  // === STATS ===
  app.get(api.stats.user.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const stats = await storage.getUserStats(req.user!.id);
    res.json({
      ...stats,
      cpuUsage: Math.floor(Math.random() * 60) + 10, // Mock data
      ramUsage: Math.floor(Math.random() * 70) + 20, // Mock data
    });
  });

  app.get(api.stats.admin.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') return res.sendStatus(401);
    const stats = await storage.getAdminStats();
    res.json({
      ...stats,
      systemHealth: 98, // Mock data
    });
  });

  // === VMs ===
  app.get(api.vms.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    // If admin, show all? Or just user's? Let's show all for admin, user's for user.
    const userId = req.user!.role === 'admin' ? undefined : req.user!.id;
    const vms = await storage.getVms(userId);
    res.json(vms);
  });

  app.get(api.vms.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const vm = await storage.getVm(Number(req.params.id));
    if (!vm) return res.status(404).json({ message: "VM not found" });
    if (req.user!.role !== 'admin' && vm.userId !== req.user!.id) return res.sendStatus(403);
    res.json(vm);
  });

  app.post(api.vms.create.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') return res.sendStatus(403);
    try {
      const input = api.vms.create.input.parse(req.body);
      const vm = await storage.createVm(input);
      await storage.createLog({ userId: req.user!.id, action: "vm.create", details: `Created VM ${vm.name} for user ${vm.userId}` });
      res.status(201).json(vm);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.post(api.vms.action.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const vm = await storage.getVm(Number(req.params.id));
    if (!vm) return res.status(404).json({ message: "VM not found" });
    if (req.user!.role !== 'admin' && vm.userId !== req.user!.id) return res.sendStatus(403);

    const { action } = req.body;
    let newStatus = vm.status;
    
    // Mock actions
    switch (action) {
      case "start": 
        newStatus = "running"; 
        break;
      case "stop": 
        newStatus = "stopped"; 
        break;
      case "reboot": 
        // Simulated reboot delay
        await storage.updateVmStatus(vm.id, "provisioning");
        setTimeout(() => storage.updateVmStatus(vm.id, "running"), 5000);
        return res.json({ message: "Reboot initiated", newStatus: "provisioning" });
      case "shutdown": 
        newStatus = "stopped"; 
        break;
      case "generate_ssh": 
        await storage.createLog({ userId: req.user!.id, action: "vm.ssh_gen", details: `Generated SSH session for VM ${vm.name}` });
        const sessionName = Math.random().toString(36).substring(2, 14);
        return res.json({ 
          message: "SSH session generated successfully", 
          command: `ssh ${sessionName}@nyc1.tmate.io`,
          tmateCommand: `apt update && apt install -y tmate && tmate -S /tmp/tmate.sock new-session -d && tmate -S /tmp/tmate.sock wait-for-connection && tmate -S /tmp/tmate.sock display -p '#{tmate_ssh}'`,
          sshUrl: `https://tmate.io/t/${sessionName}`,
          newStatus: vm.status,
          details: "tmate session initiated. Copy the SSH command below to access your instance remotely or use the Web Console."
        });
    }

    const updated = await storage.updateVmStatus(vm.id, newStatus as any);
    await storage.createLog({ userId: req.user!.id, action: `vm.${action}`, details: `Performed ${action} on VM ${vm.name}` });
    
    res.json({ message: `VM ${action} successful`, newStatus });
  });

  app.delete(api.vms.delete.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const vm = await storage.getVm(Number(req.params.id));
    if (!vm) return res.status(404).json({ message: "VM not found" });
    if (req.user!.role !== 'admin' && vm.userId !== req.user!.id) return res.sendStatus(403);

    await storage.deleteVm(vm.id);
    await storage.createLog({ userId: req.user!.id, action: "vm.delete", details: `Deleted VM ${vm.name}` });
    res.sendStatus(204);
  });

  // === NODES (Admin) ===
  app.get(api.nodes.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const nodes = await storage.getNodes();
    res.json(nodes);
  });

  app.post(api.nodes.create.path, async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') return res.sendStatus(403);
    const input = api.nodes.create.input.parse(req.body);
    const node = await storage.createNode(input);
    res.status(201).json(node);
  });

  // === VOLUMES ===
  app.get(api.volumes.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const volumes = await storage.getVolumes(req.user!.id);
    res.json(volumes);
  });

  app.post("/api/volumes", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const volume = await storage.createVolume({ ...req.body, userId: req.user!.id });
    res.json(volume);
  });

  app.get("/api/firewall/:vmId", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const rules = await storage.getFirewallRules(Number(req.params.vmId));
    res.json(rules);
  });

  app.post("/api/firewall", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const rule = await storage.createFirewallRule({ ...req.body, userId: req.user!.id });
    res.json(rule);
  });

  // === LOGS ===
  app.get(api.logs.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const logs = await storage.getLogs(req.user!.id);
    res.json(logs);
  });

  // === INVOICES ===
  app.get(api.invoices.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const invoices = await storage.getInvoices(req.user!.id);
    res.json(invoices);
  });

  // === SETTINGS ===
  app.get("/api/settings", async (req, res) => {
    const settings = await storage.getSettings();
    res.json(settings);
  });

  app.patch("/api/settings", async (req, res) => {
    if (!req.isAuthenticated() || req.user!.role !== 'admin') return res.sendStatus(403);
    const updated = await storage.updateSettings(req.body);
    res.json(updated);
  });

  return httpServer;
}

// Helper to seed data
export async function seedDatabase() {
  const existingUsers = await storage.getUserByUsername("admin");
  if (!existingUsers) {
    try {
      // 1. Create Admin
      const admin = await storage.createUser({
        username: "admin",
        password: "admin123@root",
        email: "admin@gmail.com",
        role: "admin",
        avatarUrl: "https://github.com/shadcn.png",
        twoFactorEnabled: true,
      });

      // 2. Create User
      const user = await storage.createUser({
        username: "demo_user",
        password: "password123",
        email: "example@gmail.com",
        role: "user",
        plan: "custom",
        avatarUrl: "https://github.com/shadcn.png",
        twoFactorEnabled: false,
      });

      // 3. Create Nodes
      const node1 = await storage.createNode({
        name: "node-01.us-east",
        ipAddress: "192.168.1.10",
        region: "US East (N. Virginia)",
        cpuCores: 64,
        ramGb: 256,
        diskTb: 10,
      });

      const node2 = await storage.createNode({
        name: "node-02.eu-central",
        ipAddress: "192.168.1.20",
        region: "EU Central (Frankfurt)",
        cpuCores: 32,
        ramGb: 128,
        diskTb: 5,
      });

      // 4. Create VMs
      await storage.createVm({
        name: "production-web-01",
        userId: user.id,
        nodeId: node1.id,
        os: "Ubuntu 22.04 LTS",
        cpuCores: 4,
        ramGb: 8,
        diskGb: 100,
      });

      await storage.createVm({
        name: "worker-process-01",
        userId: user.id,
        nodeId: node2.id,
        os: "Debian 11",
        cpuCores: 2,
        ramGb: 4,
        diskGb: 50,
      });
      
      // 5. Create Logs
      await storage.createLog({
        userId: user.id,
        action: "vm.create",
        details: "Created VM production-web-01"
      });
    } catch (err) {
      console.error("Error seeding database:", err);
    }
  }
}
