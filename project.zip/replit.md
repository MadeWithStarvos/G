# Matrix Cloud - VPS Management Platform

## Overview

Matrix Cloud is a full-stack VPS (Virtual Private Server) management platform built with React, Express, and PostgreSQL. It provides a modern SaaS-style dashboard for users to manage virtual machines, storage volumes, and billing, with an admin panel for infrastructure oversight.

The application follows a monorepo structure with a React frontend (Vite), Express backend, and shared TypeScript types/schemas between client and server.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with shadcn/ui component library (New York style)
- **Build Tool**: Vite with custom Replit plugins
- **Animations**: Framer Motion for page transitions and UI interactions
- **Charts**: Recharts for dashboard resource usage graphs

The frontend uses a component-based architecture with:
- `client/src/components/ui/` - Reusable shadcn/ui components
- `client/src/components/layout/` - Shell and Sidebar layout components
- `client/src/pages/` - Route-based page components
- `client/src/hooks/` - Custom React hooks for auth, VMs, stats, etc.

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database ORM**: Drizzle ORM with PostgreSQL
- **Authentication**: Passport.js with local strategy and session-based auth
- **Session Storage**: PostgreSQL-backed sessions via connect-pg-simple

API routes are defined in `server/routes.ts` with a type-safe API contract in `shared/routes.ts` using Zod schemas.

### Data Storage
- **Database**: PostgreSQL (via DATABASE_URL environment variable)
- **Schema Location**: `shared/schema.ts` using Drizzle ORM table definitions
- **Migrations**: Generated via `drizzle-kit push` command

Key database tables:
- `users` - User accounts with roles (admin/user)
- `vms` - Virtual machine instances
- `nodes` - Physical infrastructure nodes
- `storageVolumes` - Attached storage volumes
- `invoices` - Billing records
- `activityLogs` - User action logging

### Authentication & Authorization
- Session-based authentication with Passport.js local strategy
- Sessions stored in PostgreSQL for persistence
- Role-based access control (admin vs user)
- Protected routes using custom React wrapper component

### Build & Development
- Development: `npm run dev` - Runs Vite dev server with HMR proxied through Express
- Production: `npm run build` - Uses esbuild for server, Vite for client
- Database: `npm run db:push` - Syncs schema to database

## External Dependencies

### Database
- **PostgreSQL**: Primary database, connection via `DATABASE_URL` environment variable
- **Drizzle ORM**: Type-safe database queries and schema management

### UI Libraries
- **shadcn/ui**: Complete component library built on Radix UI primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library

### Authentication
- **Passport.js**: Authentication middleware
- **express-session**: Session management
- **connect-pg-simple**: PostgreSQL session store

### Data Fetching
- **TanStack React Query**: Server state management and caching
- **Zod**: Schema validation for API contracts

### Fonts (External)
- Google Fonts: DM Sans, Fira Code, Geist Mono, Architects Daughter