## Packages
recharts | For dashboard resource usage graphs (CPU, RAM, Disk)
framer-motion | For page transitions, card hover effects, and smooth UI interactions
date-fns | For formatting dates and timestamps

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Poppins", "sans-serif"],
  mono: ["Fira Code", "monospace"],
}
