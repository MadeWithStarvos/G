import { useQuery, useMutation } from "@tanstack/react-query";
import { Shell } from "@/components/layout/Shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { Shield, Plus, Loader2, Trash2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { type FirewallRule } from "@shared/schema";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function FirewallPage({ vmId }: { vmId: number }) {
  const { toast } = useToast();
  const { data: rules, isLoading } = useQuery<FirewallRule[]>({ 
    queryKey: [`/api/firewall/${vmId}`] 
  });

  const form = useForm({
    defaultValues: { 
      name: "", 
      type: "inbound", 
      protocol: "tcp", 
      portRange: "80", 
      source: "0.0.0.0/0", 
      action: "allow",
      vmId: vmId
    }
  });

  const createMutation = useMutation({
    mutationFn: async (values: any) => {
      const res = await apiRequest("POST", "/api/firewall", values);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/firewall/${vmId}`] });
      toast({ title: "Rule added", description: "Firewall rule has been created." });
      form.reset({ ...form.getValues(), name: "" });
    }
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">Firewall Rules</h2>
          <p className="text-sm text-muted-foreground">Define network access rules for this instance.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-sm">Add New Rule</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit((v) => createMutation.mutate(v))} className="space-y-3">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs uppercase font-bold text-muted-foreground">Label</FormLabel>
                      <FormControl><Input {...field} placeholder="HTTP Access" className="h-8" /></FormControl>
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-2">
                  <FormField
                    control={form.control}
                    name="protocol"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs uppercase font-bold text-muted-foreground">Protocol</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl><SelectTrigger className="h-8"><SelectValue /></SelectTrigger></FormControl>
                          <SelectContent>
                            <SelectItem value="tcp">TCP</SelectItem>
                            <SelectItem value="udp">UDP</SelectItem>
                            <SelectItem value="icmp">ICMP</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="portRange"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs uppercase font-bold text-muted-foreground">Port</FormLabel>
                        <FormControl><Input {...field} placeholder="80" className="h-8" /></FormControl>
                      </FormItem>
                    )}
                  />
                </div>
                <Button type="submit" className="w-full h-8 text-xs" disabled={createMutation.isPending}>
                  {createMutation.isPending ? <Loader2 className="animate-spin mr-2 h-3 w-3" /> : <Plus className="mr-2 h-3 w-3" />}
                  Add Rule
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        <div className="lg:col-span-2 space-y-2">
          {isLoading ? (
            <Loader2 className="animate-spin mx-auto mt-8" />
          ) : rules?.length === 0 ? (
            <div className="text-center py-8 bg-muted/10 rounded-lg border border-dashed border-primary/20">
              <Shield className="w-8 h-8 mx-auto text-muted-foreground mb-2 opacity-20" />
              <p className="text-sm text-muted-foreground">No custom rules defined.</p>
            </div>
          ) : (
            rules?.map(rule => (
              <div key={rule.id} className="flex items-center justify-between p-3 rounded-lg border border-primary/10 bg-card/50">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded bg-primary/10 text-primary">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-sm font-bold">{rule.name}</p>
                    <p className="text-[10px] text-muted-foreground uppercase font-bold">
                      {rule.protocol} • {rule.portRange} • {rule.type} • {rule.action}
                    </p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive">
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
