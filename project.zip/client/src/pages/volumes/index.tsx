import { useQuery, useMutation } from "@tanstack/react-query";
import { Shell } from "@/components/layout/Shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { HardDrive, Plus, Loader2, Trash2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { type Volume } from "@shared/schema";

export default function VolumesPage() {
  const { toast } = useToast();
  const { data: volumes, isLoading } = useQuery<Volume[]>({ queryKey: ["/api/volumes"] });

  const form = useForm({
    defaultValues: { name: "", sizeGb: 20 }
  });

  const createMutation = useMutation({
    mutationFn: async (values: any) => {
      const res = await apiRequest("POST", "/api/volumes", values);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/volumes"] });
      toast({ title: "Volume created", description: "Storage volume has been provisioned." });
      form.reset();
    }
  });

  return (
    <Shell>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-display font-bold">Storage Volumes</h1>
          <p className="text-muted-foreground">Manage persistent block storage for your instances.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle>Create Volume</CardTitle>
              <CardDescription>Add extra storage to your account.</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit((v) => createMutation.mutate(v))} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Volume Name</FormLabel>
                        <FormControl><Input {...field} placeholder="data-vol-01" /></FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="sizeGb"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Size (GB)</FormLabel>
                        <FormControl><Input type="number" {...field} onChange={e => field.onChange(parseInt(e.target.value))} /></FormControl>
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="w-full" disabled={createMutation.isPending}>
                    {createMutation.isPending ? <Loader2 className="animate-spin mr-2" /> : <Plus className="mr-2" />}
                    Create Volume
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <div className="md:col-span-2 space-y-4">
            {isLoading ? (
              <Loader2 className="animate-spin mx-auto" />
            ) : volumes?.length === 0 ? (
              <div className="text-center py-12 bg-muted/20 rounded-xl border border-dashed">
                <HardDrive className="w-12 h-12 mx-auto text-muted-foreground mb-4 opacity-20" />
                <p>No storage volumes found.</p>
              </div>
            ) : (
              volumes?.map(vol => (
                <Card key={vol.id} className="hover-elevate">
                  <CardContent className="p-6 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-3 rounded-lg bg-primary/10 text-primary">
                        <HardDrive className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="font-bold">{vol.name}</p>
                        <p className="text-xs text-muted-foreground">{vol.sizeGb} GB SSD • {vol.status}</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </Shell>
  );
}
