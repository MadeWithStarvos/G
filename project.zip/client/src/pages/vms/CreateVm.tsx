import { useVms } from "@/hooks/use-vms";
import { Shell } from "@/components/layout/Shell";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertVmSchema, type Node } from "@shared/schema";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Cpu, HardDrive, Activity, Server, Check, ArrowRight, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useState } from "react";

const TEMPLATES = [
  {
    id: "ubuntu-22.04",
    name: "Ubuntu 22.04 LTS",
    color: "bg-[#E95420]",
    description: "Most popular Linux distribution for developers.",
    defaultSpecs: { cpuCores: 1, ramGb: 2, diskGb: 10 }
  },
  {
    id: "debian-11",
    name: "Debian 11",
    color: "bg-[#D70A53]",
    description: "The universal operating system, known for stability.",
    defaultSpecs: { cpuCores: 1, ramGb: 1, diskGb: 10 }
  },
  {
    id: "centos-7",
    name: "CentOS 7",
    color: "bg-[#262577]",
    description: "Enterprise-class Linux platform.",
    defaultSpecs: { cpuCores: 1, ramGb: 2, diskGb: 20 }
  }
];

const formSchema = insertVmSchema.extend({
  cpuCores: z.coerce.number(),
  ramGb: z.coerce.number(),
  diskGb: z.coerce.number(),
  nodeId: z.coerce.number(),
  userId: z.coerce.number(),
});

export default function CreateVm() {
  const { createVm, isCreating } = useVms();
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [selectedTemplate, setSelectedTemplate] = useState(TEMPLATES[0]);

  const { data: nodes } = useQuery<Node[]>({
    queryKey: [api.nodes.list.path],
  });

  const { data: user } = useQuery<any>({
    queryKey: ["/api/user"],
  });

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      os: TEMPLATES[0].name,
      nodeId: undefined as any,
      userId: undefined as any,
      cpuCores: TEMPLATES[0].defaultSpecs.cpuCores,
      ramGb: TEMPLATES[0].defaultSpecs.ramGb,
      diskGb: TEMPLATES[0].defaultSpecs.diskGb,
    },
  });

  // Set userId when user data is available
  if (user?.id && form.getValues("userId") === undefined) {
    form.setValue("userId", user.id);
  }

  const handleTemplateSelect = (template: typeof TEMPLATES[0]) => {
    setSelectedTemplate(template);
    form.setValue("os", template.name);
    form.setValue("cpuCores", template.defaultSpecs.cpuCores);
    form.setValue("ramGb", template.defaultSpecs.ramGb);
    form.setValue("diskGb", template.defaultSpecs.diskGb);
    setStep(2);
  };

  function onSubmit(values: z.infer<typeof formSchema>) {
    createVm(values, {
      onSuccess: () => setLocation("/vms"),
    });
  }

  return (
    <Shell>
      <div className="max-w-4xl mx-auto space-y-8 pb-20">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-display font-bold tracking-tight">Create Instance</h1>
            <p className="text-muted-foreground mt-1">Deploy a new virtual machine in seconds.</p>
          </div>
          <div className="flex items-center gap-2">
            {[1, 2].map((i) => (
              <div
                key={i}
                className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors",
                  step === i ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                )}
              >
                {i}
              </div>
            ))}
          </div>
        </div>

        {step === 1 ? (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {TEMPLATES.map((template) => (
                <Card 
                  key={template.id} 
                  className={cn(
                    "cursor-pointer transition-all hover-elevate border-2",
                    selectedTemplate.id === template.id ? "border-primary bg-primary/5 glow-primary" : "border-transparent"
                  )}
                  onClick={() => handleTemplateSelect(template)}
                >
                  <CardHeader>
                    <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center mb-4", template.color)}>
                      <Server className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle>{template.name}</CardTitle>
                    <CardDescription className="text-xs h-8 line-clamp-2">{template.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      <div className="flex items-center gap-1 text-[10px] font-bold uppercase px-2 py-1 rounded-md bg-muted">
                        <Cpu className="w-3 h-3" /> {template.defaultSpecs.cpuCores} vCPU
                      </div>
                      <div className="flex items-center gap-1 text-[10px] font-bold uppercase px-2 py-1 rounded-md bg-muted">
                        <Activity className="w-3 h-3" /> {template.defaultSpecs.ramGb}GB RAM
                      </div>
                      <div className="flex items-center gap-1 text-[10px] font-bold uppercase px-2 py-1 rounded-md bg-muted">
                        <HardDrive className="w-3 h-3" /> {template.defaultSpecs.diskGb}GB SSD
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            <div className="flex justify-end pt-4">
               <Button onClick={() => setStep(2)} className="gap-2">
                 Configure Resources <ArrowRight className="w-4 h-4" />
               </Button>
            </div>
          </div>
        ) : (
          <Card className="animate-in fade-in slide-in-from-right-4 duration-500">
            <CardHeader className="border-b bg-muted/30">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Resource Configuration</CardTitle>
                  <CardDescription>Customize your instance specs and location.</CardDescription>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setStep(1)}>Change Template</Button>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-6">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Instance Name</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="my-awesome-vm" className="bg-muted/30 border-primary/20 focus:border-primary focus:shadow-[0_0_10px_rgba(234,255,0,0.2)]" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="nodeId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Location / Node</FormLabel>
                            <Select onValueChange={(v) => field.onChange(parseInt(v))} defaultValue={field.value?.toString()}>
                              <FormControl>
                                <SelectTrigger className="bg-muted/30 h-11 border-primary/20 focus:border-primary focus:shadow-[0_0_10px_rgba(234,255,0,0.2)]">
                                  <SelectValue placeholder="Select a region" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-black border-primary/40">
                                {nodes?.map((node) => (
                                  <SelectItem key={node.id} value={node.id.toString()}>
                                    {node.region} - {node.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="userId" 
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Instance Owner</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="admin@gmail.com" 
                                className="bg-muted/30 h-11 border-primary/20 focus:border-primary focus:shadow-[0_0_10px_rgba(234,255,0,0.2)]"
                                defaultValue="admin@gmail.com"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="space-y-6 bg-muted/20 p-6 rounded-xl border border-primary/10">
                      <h3 className="font-bold flex items-center gap-2"><Activity className="w-4 h-4 text-primary" /> Specifications</h3>
                      <div className="space-y-4">
                        <FormField
                          control={form.control}
                          name="cpuCores"
                          render={({ field }) => (
                            <FormItem>
                              <div className="flex justify-between items-center mb-1">
                                <FormLabel className="text-xs font-bold uppercase text-muted-foreground">CPU Cores</FormLabel>
                                <span className="text-sm font-bold text-primary">{field.value} vCPU</span>
                              </div>
                              <FormControl>
                                <Input type="range" min="1" max="1" step="1" value={field.value} onChange={(e) => field.onChange(parseInt(e.target.value))} className="accent-primary" />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="ramGb"
                          render={({ field }) => (
                            <FormItem>
                              <div className="flex justify-between items-center mb-1">
                                <FormLabel className="text-xs font-bold uppercase text-muted-foreground">Memory (RAM)</FormLabel>
                                <span className="text-sm font-bold text-primary">{field.value} GB</span>
                              </div>
                              <FormControl>
                                <Input type="range" min="0.5" max="2" step="0.5" value={field.value} onChange={(e) => field.onChange(parseFloat(e.target.value))} className="accent-primary" />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="diskGb"
                          render={({ field }) => (
                            <FormItem>
                              <div className="flex justify-between items-center mb-1">
                                <FormLabel className="text-xs font-bold uppercase text-muted-foreground">Disk Storage</FormLabel>
                                <span className="text-sm font-bold text-primary">{field.value} GB SSD</span>
                              </div>
                              <FormControl>
                                <Input type="range" min="5" max="50" step="5" value={field.value} onChange={(e) => field.onChange(parseInt(e.target.value))} className="accent-primary" />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-6 border-t">
                    <div className="flex items-center gap-3">
                      <div className={cn("p-2 rounded-lg", selectedTemplate.color)}>
                        <Server className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground uppercase font-bold tracking-wider">Selected OS</p>
                        <p className="font-bold">{selectedTemplate.name}</p>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <Button type="button" variant="ghost" onClick={() => setStep(1)}>Back</Button>
                      <Button type="submit" disabled={isCreating} className="min-w-[150px] gap-2 shadow-lg shadow-primary/20">
                        {isCreating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                        Provision Instance
                      </Button>
                    </div>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        )}
      </div>
    </Shell>
  );
}
