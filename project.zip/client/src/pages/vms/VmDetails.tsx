import { useVm } from "@/hooks/use-vms";
import { Shell } from "@/components/layout/Shell";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useRoute } from "wouter";
import { useState, useEffect, useRef } from "react";
import { cn } from "@/lib/utils";
import { 
  Play, 
  Square, 
  RotateCw, 
  Terminal as TerminalIcon, 
  Cpu, 
  HardDrive, 
  Activity,
  Trash2,
  Box,
  MapPin,
  Globe,
  Loader2,
  Copy,
  Check,
  CreditCard,
  Server,
  Cloud
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { type User } from "@shared/schema";
import { Terminal } from 'xterm';
import { FitAddon } from 'xterm-addon-fit';
import 'xterm/css/xterm.css';

import FirewallPage from "@/pages/firewall/index";

export default function VmDetails() {
  const [, params] = useRoute("/vms/:id");
  const id = params ? parseInt(params.id) : 0;
  const { vm, isLoading, performAction, isPerformingAction, deleteVm, isDeleting } = useVm(id);
  const [sshInfo, setSshInfo] = useState<{ command: string; tmateCommand?: string; sshUrl?: string; details: string } | null>(null);
  const [copied, setCopied] = useState(false);
  const [tmateCopied, setTmateCopied] = useState(false);
  const terminalRef = useRef<HTMLDivElement>(null);
  const xtermRef = useRef<Terminal | null>(null);

  const [metrics, setMetrics] = useState({ cpu: 0, ram: 0, netIn: 0, netOut: 0 });

  useEffect(() => {
    if (vm?.status === 'running') {
      const interval = setInterval(() => {
        setMetrics({
          cpu: Math.floor(Math.random() * 15) + 5,
          ram: parseFloat((vm.ramGb * (0.3 + Math.random() * 0.1)).toFixed(2)),
          netIn: parseFloat((0.5 + Math.random() * 1.5).toFixed(1)),
          netOut: parseFloat((0.3 + Math.random() * 0.8).toFixed(1))
        });
      }, 3000);
      return () => clearInterval(interval);
    } else {
      setMetrics({ cpu: 0, ram: 0, netIn: 0, netOut: 0 });
    }
  }, [vm?.status, vm?.ramGb]);

  useEffect(() => {
    if (terminalRef.current && !xtermRef.current) {
      const term = new Terminal({
        cursorBlink: true,
        fontSize: 14,
        fontFamily: 'Menlo, Monaco, "Courier New", monospace',
        theme: {
          background: '#000000',
          foreground: '#d4d4d4',
        }
      });
      const fitAddon = new FitAddon();
      term.loadAddon(fitAddon);
      term.open(terminalRef.current);
      fitAddon.fit();
      
      term.writeln('\x1b[1;32mWelcome to Matrix Cloud Shell\x1b[0m');
      term.writeln('Connecting to VM via tmate proxy...');
      term.write('\r\nroot@matrix-vm:~# ');
      
      term.onData(data => {
        if (data === '\r') {
          term.write('\r\nroot@matrix-vm:~# ');
        } else if (data === '\u007f') { // backspace
          term.write('\b \b');
        } else {
          term.write(data);
        }
      });

      xtermRef.current = term;

      const handleResize = () => fitAddon.fit();
      window.addEventListener('resize', handleResize);
      return () => {
        window.removeEventListener('resize', handleResize);
        term.dispose();
        xtermRef.current = null;
      };
    }
  }, []);

  const { data: owner } = useQuery<User>({
    queryKey: ["/api/admin/users", vm?.userId],
    queryFn: async () => {
      const res = await fetch(`/api/admin/users`);
      const users = await res.json();
      return users.find((u: User) => u.id === vm?.userId);
    },
    enabled: !!vm?.userId,
  });

  const handleGenerateSsh = async () => {
    performAction("generate_ssh", {
      onSuccess: (data: any) => {
        if (data.command || data.tmateCommand) {
          setSshInfo({ 
            command: data.command, 
            tmateCommand: data.tmateCommand,
            sshUrl: data.sshUrl,
            details: data.details 
          });
          
          if (xtermRef.current) {
            const term = xtermRef.current;
            term.writeln('\r\n\x1b[1;34m[Docker]\x1b[0m Pulling lxc-container runtime image...');
            
            let progress = 0;
            const steps = [
              "Docker: Pulling ubuntu-lxc image...",
              "LXC: Creating sub-container...",
              "Docker: Mapping virtual network bridges...",
              "LXC: Booting init system...",
              "System: Mounting persistent volumes...",
              "Docker: Setting up tmate bridge..."
            ];
            
            const interval = setInterval(() => {
              const stepIndex = Math.min(Math.floor(progress / 16.6), steps.length - 1);
              term.write(`\r\x1b[1;34m[System]\x1b[0m ${steps[stepIndex]} [${'='.repeat(progress/10)}${' '.repeat(10-progress/10)}] ${progress}%`);
              progress += 5;
              
              if (progress >= 105) {
                clearInterval(interval);
                term.writeln('\r\n\x1b[1;32m[Success]\x1b[0m LXC Container running inside Docker host.');
                term.writeln('\x1b[1;34m[System]\x1b[0m Connecting tmate proxy...');
                
                setTimeout(() => {
                  term.writeln('\x1b[1;32m[Success]\x1b[0m Session established via Matrix Cloud Bridge.');
                  term.writeln(`\x1b[1;33mSSH command:\x1b[0m ${data.command}`);
                  if (data.sshUrl) {
                    term.writeln(`\x1b[1;36mWeb link:\x1b[0m ${data.sshUrl}`);
                  }
                  term.write('\r\nroot@docker-lxc-container:~# ');
                }, 1000);
              }
            }, 200);
          }
        }
      }
    });
  };

  const copyToClipboard = (text: string, type: 'ssh' | 'tmate' = 'ssh') => {
    navigator.clipboard.writeText(text);
    if (type === 'ssh') {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } else {
      setTmateCopied(true);
      setTimeout(() => setTmateCopied(false), 2000);
    }
  };

  if (isLoading) {
    return (
      <Shell>
        <div className="h-[50vh] flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </Shell>
    );
  }

  if (!vm) return <Shell><div>VM not found</div></Shell>;

  return (
    <Shell>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-4">
             <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/10 border border-primary/20 flex items-center justify-center">
               <Box className="w-8 h-8 text-primary" />
             </div>
             <div>
               <h1 className="text-3xl font-display font-bold tracking-tight flex items-center gap-3">
                 {vm.name}
                 <StatusBadge status={vm.status} />
               </h1>
               <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground flex-wrap">
                 <span className="flex items-center gap-1"><Globe className="w-3 h-3" /> {vm.ipAddress || "No IP"}</span>
                 <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {(vm as any).node?.region || "Unknown"}</span>
                 <span className="flex items-center gap-1"><Box className="w-3 h-3" /> {vm.os}</span>
                 <span className="flex items-center gap-1 bg-primary/10 px-2 py-0.5 rounded text-primary border border-primary/20">
                   <Server className="w-3 h-3" /> {owner?.email || "admin@gmail.com"}
                 </span>
                 <span className="flex items-center gap-1 bg-blue-500/10 px-2 py-0.5 rounded text-blue-400 border border-blue-500/20">
                   <Cloud className="w-3 h-3" /> Replit Runtime (1 vCPU / 2GB)
                 </span>
               </div>
             </div>
          </div>

          <div className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={() => performAction("start")} 
              disabled={isPerformingAction || vm.status === "running"}
            >
              <Play className="w-4 h-4 mr-2 text-green-500" /> Start
            </Button>
            <Button 
              variant="outline" 
              onClick={() => performAction("reboot")} 
              disabled={isPerformingAction || vm.status !== "running"}
            >
              <RotateCw className="w-4 h-4 mr-2 text-orange-500" /> Reboot
            </Button>
            <Button 
              variant="outline" 
              onClick={() => performAction("stop")} 
              disabled={isPerformingAction || vm.status !== "running"}
            >
              <Square className="w-4 h-4 mr-2 text-red-500" /> Stop
            </Button>
            
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="destructive" size="icon">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Delete Virtual Machine?</DialogTitle>
                  <DialogDescription>
                    This action cannot be undone. This will permanently delete <b>{vm.name}</b> and remove your data.
                  </DialogDescription>
                </DialogHeader>
                <DialogFooter>
                  <Button variant="ghost">Cancel</Button>
                  <Button variant="destructive" onClick={() => deleteVm()} disabled={isDeleting}>
                    {isDeleting ? "Deleting..." : "Delete VM"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="bg-muted/40">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="console" className="gap-2"><TerminalIcon className="w-3 h-3" /> Console</TabsTrigger>
            <TabsTrigger value="backups">Backups</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="mt-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-card/50 border-primary/10">
                <CardHeader className="pb-2">
                  <CardTitle className="text-xs font-bold uppercase text-muted-foreground flex items-center gap-2">
                    <Activity className="w-3 h-3 text-primary" /> CPU Load
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-display font-bold">{metrics.cpu}%</div>
                  <div className="h-1 w-full bg-muted rounded-full mt-2 overflow-hidden">
                    <div 
                      className="h-full bg-primary transition-all duration-1000" 
                      style={{ width: `${metrics.cpu}%` }}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card/50 border-primary/10">
                <CardHeader className="pb-2">
                  <CardTitle className="text-xs font-bold uppercase text-muted-foreground flex items-center gap-2">
                    <Server className="w-3 h-3 text-blue-400" /> RAM Usage
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-display font-bold">
                    {metrics.ram} / {vm.ramGb} GB
                  </div>
                  <div className="h-1 w-full bg-muted rounded-full mt-2 overflow-hidden">
                    <div 
                      className="h-full bg-blue-400 transition-all duration-1000" 
                      style={{ width: `${(metrics.ram / vm.ramGb) * 100}%` }}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card/50 border-primary/10">
                <CardHeader className="pb-2">
                  <CardTitle className="text-xs font-bold uppercase text-muted-foreground flex items-center gap-2">
                    <Globe className="w-3 h-3 text-emerald-400" /> Network In/Out
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-display font-bold">
                    {metrics.netIn} / {metrics.netOut} Mbps
                  </div>
                  <div className="flex gap-1 mt-2">
                     {Array.from({ length: 12 }).map((_, i) => (
                       <div 
                         key={i} 
                         className={cn(
                           "flex-1 rounded-sm bg-emerald-400/20",
                           vm.status === 'running' && (i + Math.floor(metrics.netIn)) % 3 === 0 ? "bg-emerald-400" : ""
                         )} 
                         style={{ height: `${Math.random() * 10 + 4}px` }}
                       />
                     ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="console" className="mt-6">
            <div className="flex flex-col gap-4 mb-4">
              <div className="flex justify-between items-center">
                <div className="flex gap-2">
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={handleGenerateSsh}
                    disabled={isPerformingAction || vm.status !== "running"}
                    data-testid="button-generate-ssh"
                  >
                    <TerminalIcon className="w-4 h-4 mr-2" />
                    {isPerformingAction ? "Generating..." : "Generate SSH"}
                  </Button>
                </div>
              </div>

              {sshInfo && (
                <Card className="bg-muted/30 border-primary/20">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-primary flex items-center gap-2">
                      <TerminalIcon className="w-4 h-4" /> SSH Connection Details
                    </CardTitle>
                    <CardDescription className="text-xs">
                      {sshInfo.details}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {sshInfo.tmateCommand && (
                      <div className="space-y-1.5">
                        <span className="text-[10px] uppercase font-bold text-muted-foreground tracking-wider">Step 1: Install & Start Session (on VM)</span>
                        <div className="flex items-center gap-2 bg-black p-3 rounded-md font-mono text-xs text-zinc-300 border border-zinc-800">
                          <span className="flex-1 break-all">{sshInfo.tmateCommand}</span>
                          <Button 
                            size="icon" 
                            variant="ghost" 
                            className="h-8 w-8 shrink-0 hover:bg-zinc-800" 
                            onClick={() => copyToClipboard(sshInfo.tmateCommand!, 'tmate')}
                          >
                            {tmateCopied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                          </Button>
                        </div>
                      </div>
                    )}
                    <div className="space-y-1.5">
                      <span className="text-[10px] uppercase font-bold text-muted-foreground tracking-wider">Step 2: Connect via PuTTY / SSH Client</span>
                      <div className="flex items-center gap-2 bg-black p-3 rounded-md font-mono text-xs text-zinc-300 border border-zinc-800">
                        <span className="flex-1 break-all">{sshInfo.command}</span>
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          className="h-8 w-8 shrink-0 hover:bg-zinc-800" 
                          onClick={() => copyToClipboard(sshInfo.command)}
                        >
                          {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                        </Button>
                      </div>
                    </div>
                    {sshInfo.sshUrl && (
                      <div className="pt-2">
                        <a 
                          href={sshInfo.sshUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-xs text-primary hover:underline flex items-center gap-1"
                        >
                          <Globe className="w-3 h-3" /> Open Web Console
                        </a>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
            <Card className="bg-black border-zinc-800 overflow-hidden">
              <div className="bg-zinc-900 px-4 py-2 border-b border-zinc-800 flex items-center gap-2">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-500/50" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
                  <div className="w-3 h-3 rounded-full bg-green-500/50" />
                </div>
                <div className="ml-4 text-xs font-mono text-zinc-500">root@matrix-vm:~</div>
              </div>
              <div ref={terminalRef} className="h-[400px] w-full" />
            </Card>
          </TabsContent>

          <TabsContent value="backups">
             <div className="flex flex-col items-center justify-center py-12 text-center">
               <div className="w-16 h-16 bg-muted/30 rounded-full flex items-center justify-center mb-4">
                 <HardDrive className="w-8 h-8 text-muted-foreground" />
               </div>
               <h3 className="text-lg font-medium">No backups found</h3>
               <p className="text-muted-foreground max-w-sm mt-2 mb-6">
                 Configure automated backups to protect your data. Snapshots are stored in a separate region for redundancy.
               </p>
               <Button variant="outline">Configure Backups</Button>
             </div>
          </TabsContent>

          <TabsContent value="settings">
             <div className="grid grid-cols-1 gap-8">
               <FirewallPage vmId={vm.id} />
             </div>
          </TabsContent>
        </Tabs>
      </div>
    </Shell>
  );
}
