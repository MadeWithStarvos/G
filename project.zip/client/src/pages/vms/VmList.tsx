import { useVms } from "@/hooks/use-vms";
import { Shell } from "@/components/layout/Shell";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Plus, Search, MoreHorizontal } from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function VmList() {
  const { vms, isLoading } = useVms();

  return (
    <Shell>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold tracking-tight">Virtual Machines</h1>
            <p className="text-muted-foreground mt-1">Manage your compute instances.</p>
          </div>
          <Link href="/vms/create">
            <Button className="gap-2 shadow-lg shadow-primary/20 bg-primary hover:bg-primary/90">
              <Plus className="w-4 h-4" /> Create Instance
            </Button>
          </Link>
        </div>

        <div className="bg-card rounded-2xl border border-border overflow-hidden">
          <div className="p-4 border-b border-border bg-muted/10 flex items-center gap-4">
            <div className="relative max-w-sm w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input placeholder="Search instances..." className="pl-9 bg-background border-border/50" />
            </div>
            {/* Filters could go here */}
          </div>

          <Table>
            <TableHeader className="bg-muted/30">
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-[250px]">Name</TableHead>
                <TableHead>IP Address</TableHead>
                <TableHead>Specs</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center">Loading...</TableCell>
                </TableRow>
              ) : vms?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-32 text-center text-muted-foreground">
                    No instances found. Create one to get started.
                  </TableCell>
                </TableRow>
              ) : (
                vms?.map((vm) => (
                  <TableRow key={vm.id} className="group">
                    <TableCell className="font-medium">
                      <Link href={`/vms/${vm.id}`} className="hover:text-primary transition-colors block">
                        {vm.name}
                        <div className="text-xs text-muted-foreground font-normal mt-0.5">{vm.os}</div>
                      </Link>
                    </TableCell>
                    <TableCell className="font-mono text-sm">{vm.ipAddress || "—"}</TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {vm.cpuCores} vCPU / {vm.ramGb} GB
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {vm.node?.region || "Unknown"}
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={vm.status} />
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem asChild>
                            <Link href={`/vms/${vm.id}`}>View Details</Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem>View Logs</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-destructive focus:text-destructive">
                            Delete Instance
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </Shell>
  );
}
