import { useUserStats } from "@/hooks/use-stats";
import { useVms } from "@/hooks/use-vms";
import { Shell } from "@/components/layout/Shell";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { Plus, Server, HardDrive, Cpu, Activity, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: '00:00', cpu: 20, ram: 40 },
  { name: '04:00', cpu: 35, ram: 45 },
  { name: '08:00', cpu: 55, ram: 60 },
  { name: '12:00', cpu: 85, ram: 75 },
  { name: '16:00', cpu: 65, ram: 55 },
  { name: '20:00', cpu: 45, ram: 45 },
  { name: '23:59', cpu: 30, ram: 40 },
];

export default function UserDashboard() {
  const { data: stats } = useUserStats();
  const { vms } = useVms();

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <Shell>
      <div className="space-y-8">
        <div className="flex justify-between items-end">
          <div>
            <h1 className="text-3xl font-display font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground mt-1">Overview of your infrastructure.</p>
          </div>
        </div>

        <motion.div 
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          <motion.div variants={item}>
            <Card className="hover:border-primary/50 transition-colors cursor-default">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Active VMs</CardTitle>
                <Server className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stats?.activeVms || 0}</div>
                <p className="text-xs text-muted-foreground mt-1">running instances</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={item} className="hidden">
            <Card className="hover:border-accent/50 transition-colors cursor-default">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Est. Cost</CardTitle>
                <span className="text-xl font-bold text-accent">$</span>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">${(stats?.totalCost || 0) / 100}</div>
                <p className="text-xs text-muted-foreground mt-1">current month</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={item}>
            <Card className="hover:border-blue-400/50 transition-colors cursor-default">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">CPU Usage</CardTitle>
                <Cpu className="h-4 w-4 text-blue-400" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stats?.cpuUsage || 0}%</div>
                <div className="w-full bg-muted/50 h-1.5 mt-3 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-400" style={{ width: `${stats?.cpuUsage || 0}%` }} />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={item}>
            <Card className="hover:border-purple-400/50 transition-colors cursor-default">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">RAM Usage</CardTitle>
                <Activity className="h-4 w-4 text-purple-400" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stats?.ramUsage || 0}%</div>
                <div className="w-full bg-muted/50 h-1.5 mt-3 rounded-full overflow-hidden">
                  <div className="h-full bg-purple-400" style={{ width: `${stats?.ramUsage || 0}%` }} />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Usage Chart */}
          <Card className="col-span-2 border-border/60">
            <CardHeader>
              <CardTitle>Resource Usage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data}>
                    <defs>
                      <linearGradient id="colorCpu" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorRam" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--accent))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--accent))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--popover))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                      itemStyle={{ color: 'hsl(var(--popover-foreground))' }}
                    />
                    <Area type="monotone" dataKey="cpu" stroke="hsl(var(--primary))" strokeWidth={2} fillOpacity={1} fill="url(#colorCpu)" />
                    <Area type="monotone" dataKey="ram" stroke="hsl(var(--accent))" strokeWidth={2} fillOpacity={1} fill="url(#colorRam)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Quick VM List */}
          <Card className="col-span-1 border-border/60">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Recent VMs</CardTitle>
              <Link href="/vms" className="text-sm text-primary hover:underline flex items-center gap-1">
                View all <ArrowRight className="w-3 h-3" />
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {vms?.slice(0, 5).map(vm => (
                  <Link href={`/vms/${vm.id}`} key={vm.id}>
                    <div className="flex items-center justify-between p-3 rounded-xl bg-muted/30 hover:bg-muted/60 transition-colors cursor-pointer group border border-transparent hover:border-border">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-card border border-border flex items-center justify-center">
                          <Server className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                        </div>
                        <div>
                          <div className="font-medium">{vm.name}</div>
                          <div className="text-xs text-muted-foreground">{vm.ipAddress || 'Provisioning...'}</div>
                        </div>
                      </div>
                      <StatusBadge status={vm.status || 'provisioning'} />
                    </div>
                  </Link>
                ))}
                {(!vms || vms.length === 0) && (
                  <div className="text-center text-muted-foreground py-8">
                    No active VMs found.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Shell>
  );
}
