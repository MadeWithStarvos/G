import { useQuery, useMutation } from "@tanstack/react-query";
import { Shell } from "@/components/layout/Shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertSettingsSchema, type Settings } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Save, Loader2 } from "lucide-react";

export default function AdminSettings() {
  const { toast } = useToast();
  const { data: settings, isLoading } = useQuery<Settings>({
    queryKey: ["/api/settings"],
  });

  const mutation = useMutation({
    mutationFn: async (values: Partial<Settings>) => {
      const res = await apiRequest("PATCH", "/api/settings", values);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Settings updated",
        description: "Global platform settings have been saved successfully.",
      });
    },
  });

  const form = useForm({
    resolver: zodResolver(insertSettingsSchema),
    values: settings || {
      hostname: "Matrix Cloud",
      appIcon: "M",
    },
  });

  if (isLoading) {
    return (
      <Shell>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </Shell>
    );
  }

  return (
    <Shell>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Platform Settings</h1>
          <p className="text-muted-foreground">Configure global branding and identification for your cloud panel.</p>
        </div>

        <Card className="max-w-2xl">
          <CardHeader>
            <CardTitle>Branding</CardTitle>
            <CardDescription>Update how your platform appears to all users.</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
                <FormField
                  control={form.control}
                  name="hostname"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Panel Name (Hostname)</FormLabel>
                      <FormControl>
                        <Input {...field} value={field.value || ""} placeholder="e.g. Matrix Cloud" data-testid="input-hostname" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="appIcon"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>App Icon (Text or URL)</FormLabel>
                      <FormControl>
                        <Input {...field} value={field.value || ""} placeholder="e.g. M or https://..." data-testid="input-app-icon" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full" disabled={mutation.isPending} data-testid="button-save-settings">
                  {mutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  Save Changes
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </Shell>
  );
}
