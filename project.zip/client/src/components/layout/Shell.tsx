import { ReactNode } from "react";
import { Sidebar } from "./Sidebar";

interface ShellProps {
  children: ReactNode;
}

export function Shell({ children }: ShellProps) {
  return (
    <div className="flex min-h-screen bg-[#0d0d0d] text-foreground font-sans selection:bg-primary/30">
      <Sidebar />
      <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gradient-to-br from-[#0d0d0d] via-[#111111] to-[#0d0d0d]">
        <div className="max-w-7xl mx-auto p-8 lg:p-12 animate-in fade-in duration-700">
          {children}
        </div>
      </main>
    </div>
  );
}
