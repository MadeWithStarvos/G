import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Server, 
  Settings, 
  LogOut, 
  HardDrive, 
  Shield, 
  Activity, 
  Users,
  CreditCard,
  Cloud,
  FileText,
  User,
  Plus
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { type Settings as PlatformSettings } from "@shared/schema";

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  
  const { data: settings } = useQuery<PlatformSettings>({
    queryKey: ["/api/settings"],
  });

  const isAdmin = user?.role === "admin";

  const userLinks = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/vms", label: "VMs", icon: Server },
    { href: "/logs", label: "Logs", icon: FileText },
    { href: "/profile", label: "Edit Profile", icon: User },
  ];

  const adminLinks = [
    { href: "/admin", label: "Overview", icon: Activity },
    { href: "/volumes", label: "Storage", icon: HardDrive },
    { href: "/firewalls", label: "Firewalls", icon: Shield },
    { href: "/monitoring", label: "Monitoring", icon: Activity },
    { href: "/vms/create", label: "Add Instance", icon: Plus },
    { href: "/admin/nodes", label: "Infrastructure", icon: Cloud },
    { href: "/admin/users", label: "User Management", icon: Users },
    { href: "/admin/settings", label: "Global Settings", icon: Settings },
  ];

  return (
    <div className="hidden md:flex flex-col w-64 bg-[#090909] border-r border-white/5 min-h-screen sticky top-0 h-screen">
      <div className="p-6 flex items-center gap-3">
        {settings?.appIcon?.startsWith('http') ? (
          <img src={settings.appIcon} alt="Logo" className="w-9 h-9 rounded-xl object-contain shadow-lg shadow-primary/20 border border-white/10 p-1" />
        ) : (
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-primary to-[#a3e635] flex items-center justify-center text-black font-bold text-lg shadow-xl shadow-primary/30">
            {settings?.appIcon || 'M'}
          </div>
        )}
        <span className="font-display font-bold text-xl tracking-tight truncate text-white uppercase">{settings?.hostname || 'Matrix'}</span>
      </div>

      <div className="flex-1 px-4 py-4 space-y-8 overflow-y-auto">
        <div>
          <h4 className="text-[10px] font-bold text-muted-foreground/50 mb-4 px-3 uppercase tracking-[0.2em]">
            General
          </h4>
          <nav className="space-y-1">
            {userLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <div className={cn(
                  "flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-300 cursor-pointer group relative overflow-hidden",
                  location === link.href 
                    ? "bg-white/5 text-primary font-bold shadow-inner border border-white/5" 
                    : "text-muted-foreground hover:bg-white/[0.02] hover:text-white"
                )}>
                  {location === link.href && (
                    <div className="absolute left-0 w-1 h-4 bg-primary rounded-full shadow-[0_0_10px_rgba(234,255,0,0.8)]" />
                  )}
                  <link.icon className={cn("w-4 h-4 transition-transform group-hover:scale-110", location === link.href ? "text-primary" : "text-muted-foreground group-hover:text-white")} />
                  <span className="text-sm tracking-wide">{link.label}</span>
                </div>
              </Link>
            ))}
          </nav>
        </div>

        {isAdmin && (
          <div>
            <h4 className="text-[10px] font-bold text-muted-foreground/50 mb-4 px-3 uppercase tracking-[0.2em]">
              Administration
            </h4>
            <nav className="space-y-1">
              {adminLinks.map((link) => (
                <Link key={link.href} href={link.href}>
                  <div className={cn(
                    "flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-300 cursor-pointer group relative overflow-hidden",
                    location === link.href 
                      ? "bg-white/5 text-[#a3e635] font-bold shadow-inner border border-white/5" 
                      : "text-muted-foreground hover:bg-white/[0.02] hover:text-white"
                  )}>
                    {location === link.href && (
                      <div className="absolute left-0 w-1 h-4 bg-[#a3e635] rounded-full shadow-[0_0_10px_rgba(163,230,53,0.8)]" />
                    )}
                    <link.icon className={cn("w-4 h-4 transition-transform group-hover:scale-110", location === link.href ? "text-[#a3e635]" : "text-muted-foreground group-hover:text-white")} />
                    <span className="text-sm tracking-wide">{link.label}</span>
                  </div>
                </Link>
              ))}
            </nav>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-white/5">
        <div className="flex items-center gap-3 px-4 py-4 mb-4 rounded-2xl bg-white/[0.03] border border-white/5 shadow-2xl backdrop-blur-sm">
          <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary font-bold text-lg shadow-inner">
            {user?.username.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold truncate text-white tracking-tight">{user?.username}</p>
            <p className="text-[10px] text-primary/70 truncate uppercase font-bold tracking-widest">{user?.role}</p>
          </div>
        </div>
        <button
          onClick={() => logout()}
          className="flex items-center justify-center gap-2 w-full px-4 py-3 text-xs font-bold text-muted-foreground hover:text-white hover:bg-red-500/10 rounded-xl transition-all duration-300 border border-transparent hover:border-red-500/20"
        >
          <LogOut className="w-4 h-4" />
          DISCONNECT
        </button>
      </div>
    </div>
  );
}
