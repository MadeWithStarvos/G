import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: string;
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const normalizedStatus = status.toLowerCase();
  
  const styles = {
    running: "bg-green-500/15 text-green-500 border-green-500/20",
    online: "bg-green-500/15 text-green-500 border-green-500/20",
    stopped: "bg-red-500/15 text-red-500 border-red-500/20",
    offline: "bg-red-500/15 text-red-500 border-red-500/20",
    provisioning: "bg-orange-500/15 text-orange-500 border-orange-500/20",
    maintenance: "bg-yellow-500/15 text-yellow-500 border-yellow-500/20",
  };

  const defaultStyle = "bg-muted text-muted-foreground border-border";

  return (
    <span className={cn(
      "px-2.5 py-0.5 text-xs font-medium rounded-full border flex items-center gap-1.5 w-fit",
      styles[normalizedStatus as keyof typeof styles] || defaultStyle
    )}>
      <span className={cn("w-1.5 h-1.5 rounded-full", 
        normalizedStatus === 'running' || normalizedStatus === 'online' ? "bg-green-500 animate-pulse" :
        normalizedStatus === 'stopped' || normalizedStatus === 'offline' ? "bg-red-500" :
        "bg-current"
      )} />
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}
