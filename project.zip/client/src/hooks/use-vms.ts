import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertVm, type VmActionRequest } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useVms() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // List all VMs
  const { data: vms, isLoading } = useQuery({
    queryKey: [api.vms.list.path],
    queryFn: async () => {
      const res = await fetch(api.vms.list.path);
      if (!res.ok) throw new Error("Failed to fetch VMs");
      return api.vms.list.responses[200].parse(await res.json());
    },
  });

  // Create VM
  const createVmMutation = useMutation({
    mutationFn: async (data: InsertVm) => {
      const res = await fetch(api.vms.create.path, {
        method: api.vms.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create VM");
      }
      return api.vms.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.vms.list.path] });
      toast({ title: "VM Created", description: "Your virtual machine is provisioning." });
    },
    onError: (err: Error) => {
      toast({ variant: "destructive", title: "Error", description: err.message });
    },
  });

  return { vms, isLoading, createVm: createVmMutation.mutate, isCreating: createVmMutation.isPending };
}

export function useVm(id: number) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get single VM
  const { data: vm, isLoading, error } = useQuery({
    queryKey: [api.vms.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.vms.get.path, { id });
      const res = await fetch(url);
      if (!res.ok) throw new Error("VM not found");
      return api.vms.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });

  // VM Action (Start/Stop/Reboot)
  const actionMutation = useMutation({
    mutationFn: async (action: VmActionRequest['action']) => {
      const url = buildUrl(api.vms.action.path, { id });
      const res = await fetch(url, {
        method: api.vms.action.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      if (!res.ok) throw new Error("Failed to perform action");
      return api.vms.action.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.vms.get.path, id] });
      queryClient.invalidateQueries({ queryKey: [api.vms.list.path] });
      toast({ title: "Action Sent", description: data.message });
    },
    onError: (err: Error) => {
      toast({ variant: "destructive", title: "Error", description: err.message });
    },
  });

  // Delete VM
  const deleteMutation = useMutation({
    mutationFn: async () => {
      const url = buildUrl(api.vms.delete.path, { id });
      const res = await fetch(url, { method: api.vms.delete.method });
      if (!res.ok) throw new Error("Failed to delete VM");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.vms.list.path] });
      toast({ title: "VM Deleted", description: "The virtual machine has been removed." });
    },
  });

  return {
    vm,
    isLoading,
    error,
    performAction: (action: VmActionRequest['action'], options?: any) => actionMutation.mutate(action, options),
    isPerformingAction: actionMutation.isPending,
    deleteVm: deleteMutation.mutate,
    isDeleting: deleteMutation.isPending,
  };
}
