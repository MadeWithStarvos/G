import { Switch, Route, Redirect } from "wouter";
import { queryClient, apiRequest } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import { 
  Loader2, 
  HardDrive, 
  Shield, 
  Activity, 
  Server, 
  CreditCard, 
  FileText, 
  ArrowRight,
  Cloud,
  Users,
  Plus,
  Trash2,
  Save
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { insertUserSchema, insertNodeSchema, type User, type Vm } from "@shared/schema";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

import Login from "@/pages/auth/Login";
import UserDashboard from "@/pages/dashboard/UserDashboard";
import VmList from "@/pages/vms/VmList";
import VmDetails from "@/pages/vms/VmDetails";
import CreateVm from "@/pages/vms/CreateVm";
import AdminSettings from "@/pages/admin/AdminSettings";
import NotFound from "@/pages/not-found";

import { Shell } from "@/components/layout/Shell";

// Real pages using the Shell layout
const Volumes = () => (
  <Shell>
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Storage Volumes</h1>
      <p className="text-muted-foreground">Manage your block storage and attached disks.</p>
      <Card className="p-8 text-center bg-muted/20 border-dashed">
        <HardDrive className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
        <h3 className="text-lg font-medium">No volumes found</h3>
        <p className="text-sm text-muted-foreground mt-1 mb-4">Create your first storage volume to attach to an instance.</p>
        <Button>Create Volume</Button>
      </Card>
    </div>
  </Shell>
);

const Firewalls = () => (
  <Shell>
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Firewalls</h1>
      <p className="text-muted-foreground">Configure network security rules for your instances.</p>
      <Card className="p-8 text-center bg-muted/20 border-dashed">
        <Shield className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
        <h3 className="text-lg font-medium">No firewalls found</h3>
        <p className="text-sm text-muted-foreground mt-1 mb-4">Security groups allow you to control inbound and outbound traffic.</p>
        <Button>Create Firewall</Button>
      </Card>
    </div>
  </Shell>
);

const Monitoring = () => (
  <Shell>
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Monitoring</h1>
      <p className="text-muted-foreground">Real-time performance and uptime statistics.</p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="p-6">
          <h3 className="font-medium mb-4 flex items-center gap-2 text-primary"><Activity className="w-4 h-4" /> System CPU Usage</h3>
          <div className="h-40 bg-muted/30 rounded-lg flex flex-col items-center justify-center border border-dashed">
            <div className="text-4xl font-bold text-primary">24%</div>
            <div className="text-sm text-muted-foreground mt-2">Normal operations</div>
          </div>
        </Card>
        <Card className="p-6">
          <h3 className="font-medium mb-4 flex items-center gap-2 text-blue-500"><Server className="w-4 h-4" /> RAM Consumption</h3>
          <div className="h-40 bg-muted/30 rounded-lg flex flex-col items-center justify-center border border-dashed">
            <div className="text-4xl font-bold text-blue-500">8.4 / 32 GB</div>
            <div className="text-sm text-muted-foreground mt-2">ECC Memory Active</div>
          </div>
        </Card>
        <Card className="p-6">
          <h3 className="font-medium mb-4 flex items-center gap-2 text-emerald-500"><Cloud className="w-4 h-4" /> Network Uptime</h3>
          <div className="h-40 bg-muted/30 rounded-lg flex flex-col items-center justify-center border border-dashed">
            <div className="text-4xl font-bold text-emerald-500">99.99%</div>
            <div className="text-sm text-muted-foreground mt-2">Past 30 days</div>
          </div>
        </Card>
      </div>
    </div>
  </Shell>
);

const Billing = () => (
  <Shell>
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Billing & Invoices</h1>
      <p className="text-muted-foreground">Manage your payment methods and view billing history.</p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6">
          <h3 className="text-sm font-medium text-muted-foreground mb-1">Current Balance</h3>
          <p className="text-3xl font-bold">$0.00</p>
        </Card>
        <Card className="p-6">
          <h3 className="text-sm font-medium text-muted-foreground mb-1">Next Invoice</h3>
          <p className="text-3xl font-bold">Feb 1, 2026</p>
        </Card>
        <Card className="p-6">
          <h3 className="text-sm font-medium text-muted-foreground mb-1">Payment Method</h3>
          <p className="text-sm font-medium mt-2 text-primary">Add Card <ArrowRight className="inline w-3 h-3" /></p>
        </Card>
      </div>
    </div>
  </Shell>
);

const Logs = () => (
  <Shell>
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Activity Logs</h1>
      <p className="text-muted-foreground">Track all actions performed on your account.</p>
      <Card className="overflow-hidden">
        <div className="p-8 text-center text-muted-foreground">
          <FileText className="w-12 h-12 mx-auto mb-4 opacity-20" />
          <p>No recent activity logs found.</p>
        </div>
      </Card>
    </div>
  </Shell>
);

const Profile = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("PATCH", `/api/users/${user?.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Profile updated",
        description: "Your account information has been updated successfully.",
      });
    },
  });

  const form = useForm({
    defaultValues: {
      email: user?.email || "",
      password: "",
    },
  });

  return (
    <Shell>
      <div className="max-w-2xl space-y-8">
        <div>
          <h1 className="text-3xl font-bold">Edit Profile</h1>
          <p className="text-muted-foreground">Update your email address and password.</p>
        </div>
        <Card className="p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit((data) => updateProfileMutation.mutate(data))} className="space-y-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>New Email</FormLabel>
                    <FormControl>
                      <Input {...field} type="email" placeholder="new-email@example.com" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>New Password</FormLabel>
                    <FormControl>
                      <Input {...field} type="password" placeholder="Leave blank to keep current" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full" disabled={updateProfileMutation.isPending}>
                {updateProfileMutation.isPending ? "Updating..." : "Update Profile"}
              </Button>
            </form>
          </Form>
        </Card>
      </div>
    </Shell>
  );
};

const Settings = () => (
  <Shell>
    <div className="max-w-2xl space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Account Settings</h1>
        <p className="text-muted-foreground">Global configuration and API access.</p>
      </div>
      <div className="space-y-6">
        <Card className="p-6">
          <h3 className="font-bold mb-4">Notifications</h3>
          <p className="text-sm text-muted-foreground mb-4">Manage how you receive alerts and updates.</p>
          <Button variant="outline">Configure</Button>
        </Card>
        <Card className="p-6">
          <h3 className="font-bold mb-4">API Tokens</h3>
          <p className="text-sm text-muted-foreground mb-4">Generate tokens to interact with our API programmatically.</p>
          <Button variant="outline">Manage Tokens</Button>
        </Card>
      </div>
    </div>
  </Shell>
);

// Protected Route Wrapper
function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/auth/login" />;
  }

  return <Component />;
}

const AdminOverview = () => {
  const { data: stats } = useQuery<any>({
    queryKey: [api.stats.admin.path],
  });

  return (
    <Shell>
      <div className="space-y-4">
        <h1 className="text-3xl font-bold">Admin Overview</h1>
        <p className="text-muted-foreground">Global infrastructure health and performance.</p>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="p-6">
            <h3 className="text-sm font-medium text-muted-foreground">Total Users</h3>
            <p className="text-2xl font-bold">{stats?.totalUsers || "..."}</p>
          </Card>
          <Card className="p-6">
            <h3 className="text-sm font-medium text-muted-foreground">Total VMs</h3>
            <p className="text-2xl font-bold">{stats?.totalVms || "..."}</p>
          </Card>
          <Card className="p-6">
            <h3 className="text-sm font-medium text-muted-foreground">Active Nodes</h3>
            <p className="text-2xl font-bold">{stats?.totalNodes || "..."}</p>
          </Card>
          <Card className="p-6">
            <h3 className="text-sm font-medium text-muted-foreground">System Health</h3>
            <p className="text-2xl font-bold text-green-500">{stats?.systemHealth || "98"}%</p>
          </Card>
        </div>
      </div>
    </Shell>
  );
};

const AdminNodes = () => {
  const { data: nodes, isLoading } = useQuery<any[]>({
    queryKey: [api.nodes.list.path],
  });

  const createNodeMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest(api.nodes.create.method, api.nodes.create.path, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.nodes.list.path] });
    },
  });

  const nodeForm = useForm({
    resolver: zodResolver(insertNodeSchema),
    defaultValues: {
      name: "",
      ipAddress: "",
      region: "",
      cpuCores: 8,
      ramGb: 16,
      diskTb: 1,
      status: "online",
    },
  });

  return (
    <Shell>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Infrastructure Nodes</h1>
            <p className="text-muted-foreground">Manage physical server nodes and resource allocation.</p>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button data-testid="button-add-node">
                <Plus className="w-4 h-4 mr-2" /> Add Node
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Node</DialogTitle>
                <DialogDescription>Add a physical server to the resource pool.</DialogDescription>
              </DialogHeader>
              <Form {...nodeForm}>
                <form onSubmit={nodeForm.handleSubmit((data) => createNodeMutation.mutate(data))} className="space-y-4">
                  <FormField
                    control={nodeForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Node Name</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="node-01.region" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={nodeForm.control}
                    name="ipAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>IP Address</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="1.2.3.4" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={nodeForm.control}
                    name="region"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Region</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="US-East" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-3 gap-4">
                    <FormField
                      control={nodeForm.control}
                      name="cpuCores"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>CPU (Cores)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" onChange={e => field.onChange(parseInt(e.target.value))} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={nodeForm.control}
                      name="ramGb"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>RAM (GB)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" onChange={e => field.onChange(parseInt(e.target.value))} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={nodeForm.control}
                      name="diskTb"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Disk (TB)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" onChange={e => field.onChange(parseInt(e.target.value))} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  <DialogFooter>
                    <Button type="submit" disabled={createNodeMutation.isPending}>
                      {createNodeMutation.isPending ? "Adding..." : "Add Node"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
        
        {isLoading ? (
          <div className="flex items-center justify-center p-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : nodes && nodes.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {nodes.map(node => (
              <Card key={node.id} className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="p-2 rounded-lg bg-primary/10 text-primary">
                    <Cloud className="w-6 h-6" />
                  </div>
                  <span className={`text-xs font-bold uppercase px-2 py-1 rounded ${node.status === 'online' ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}>
                    {node.status}
                  </span>
                </div>
                <h3 className="text-lg font-bold truncate">{node.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">{node.ipAddress}</p>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="bg-muted p-2 rounded">
                    <p className="text-muted-foreground mb-1">CPU</p>
                    <p className="font-bold">{node.cpuCores} Cores</p>
                  </div>
                  <div className="bg-muted p-2 rounded">
                    <p className="text-muted-foreground mb-1">RAM</p>
                    <p className="font-bold">{node.ramGb} GB</p>
                  </div>
                  <div className="bg-muted p-2 rounded">
                    <p className="text-muted-foreground mb-1">Disk</p>
                    <p className="font-bold">{node.diskTb} TB</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-8 text-center bg-muted/20 border-dashed">
            <Cloud className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-medium">No nodes found</h3>
            <p className="text-sm text-muted-foreground mt-1 mb-4">Add your first infrastructure node to start provisioning instances.</p>
            <Button>Add New Node</Button>
          </Card>
        )}
      </div>
    </Shell>
  );
};

const AdminUsers = () => {
  const { data: usersList, isLoading } = useQuery<User[]>({
    queryKey: [api.users.list.path],
  });

  const createUserMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest(api.users.create.method, api.users.create.path, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.users.list.path] });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/users/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.users.list.path] });
    },
  });

  const form = useForm({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      username: "",
      password: "",
      email: "",
      role: "user",
      plan: "free",
    },
  });

  return (
    <Shell>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">User Management</h1>
            <p className="text-muted-foreground">Control user accounts, roles, and permissions.</p>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button data-testid="button-add-user">
                <Plus className="w-4 h-4 mr-2" /> Add User
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New User</DialogTitle>
                <DialogDescription>Create a new account for your infrastructure.</DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit((data) => createUserMutation.mutate(data))} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input {...field} data-testid="input-username" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input {...field} type="email" data-testid="input-email" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input {...field} type="password" data-testid="input-password" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Role</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-role">
                              <SelectValue placeholder="Select a role" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="user">User (Standard)</SelectItem>
                            <SelectItem value="admin">Administrator</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <DialogFooter>
                    <Button type="submit" disabled={createUserMutation.isPending} data-testid="button-submit-user">
                      {createUserMutation.isPending ? "Creating..." : "Create User"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        <Card className="overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-center text-muted-foreground">
              <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" />
              <p>User directory is loading...</p>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {usersList?.map((u) => (
                <div key={u.id} className="p-4 flex justify-between items-center" data-testid={`row-user-${u.id}`}>
                  <div>
                    <div className="font-medium" data-testid={`text-username-${u.id}`}>{u.username}</div>
                    <div className="text-sm text-muted-foreground" data-testid={`text-email-${u.id}`}>{u.email}</div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-xs uppercase bg-muted px-2 py-1 rounded" data-testid={`text-role-${u.id}`}>{u.role}</span>
                    <span className="text-xs uppercase bg-primary/10 text-primary px-2 py-1 rounded" data-testid={`text-plan-${u.id}`}>{u.plan}</span>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => deleteUserMutation.mutate(u.id)}
                      disabled={deleteUserMutation.isPending}
                      data-testid={`button-delete-user-${u.id}`}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </Shell>
  );
};

function Router() {
  return (
    <Switch>
      <Route path="/auth/login" component={Login} />
      
      <Route path="/dashboard">
        <ProtectedRoute component={UserDashboard} />
      </Route>
      
      <Route path="/vms">
        <ProtectedRoute component={VmList} />
      </Route>

      <Route path="/vms/create">
        <ProtectedRoute component={CreateVm} />
      </Route>
      
      <Route path="/vms/:id">
        <ProtectedRoute component={VmDetails} />
      </Route>

      <Route path="/volumes">
        <ProtectedRoute component={Volumes} />
      </Route>

      <Route path="/firewalls">
        <ProtectedRoute component={Firewalls} />
      </Route>

      <Route path="/monitoring">
        <ProtectedRoute component={Monitoring} />
      </Route>

      <Route path="/logs">
        <ProtectedRoute component={Logs} />
      </Route>

      <Route path="/profile">
        <ProtectedRoute component={Profile} />
      </Route>

      <Route path="/settings">
        <ProtectedRoute component={Settings} />
      </Route>

      <Route path="/admin">
        <ProtectedRoute component={AdminOverview} />
      </Route>

      <Route path="/admin/nodes">
        <ProtectedRoute component={AdminNodes} />
      </Route>

      <Route path="/admin/users">
        <ProtectedRoute component={AdminUsers} />
      </Route>

      <Route path="/admin/settings">
        <ProtectedRoute component={AdminSettings} />
      </Route>

      <Route path="/">
        <Redirect to="/dashboard" />
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
