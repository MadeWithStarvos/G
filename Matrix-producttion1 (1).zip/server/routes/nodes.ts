import { Router } from 'express'
import { db } from '../db/index.js'
import { proxmoxNodes, proxmoxClusters } from '../db/schema.js'
import { eq } from 'drizzle-orm'
import { requireAuth, requireRole } from '../middleware/auth.js'
import { makeProxmox } from '../services/proxmox.js'

const router = Router()
router.use(requireAuth)
router.use(requireRole('superadmin', 'admin'))

async function getNodeAndCluster(nodeId: string) {
  const node = db.select().from(proxmoxNodes).where(eq(proxmoxNodes.id, nodeId)).get()
  if (!node) return null
  const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, node.clusterId)).get()
  if (!cluster) return null
  return { node, cluster, pve: makeProxmox(cluster) }
}

router.get('/:id/services', async (req, res) => {
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const services = await ctx.pve.getNodeServices(ctx.node.name)
    return res.json(services)
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.post('/:id/services/:service/:action', async (req, res) => {
  const { service, action } = req.params
  if (!['start', 'stop', 'restart', 'reload'].includes(action)) {
    return res.status(400).json({ error: 'Invalid action' })
  }
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const result = await ctx.pve.controlNodeService(ctx.node.name, service, action as any)
    return res.json({ success: true, upid: result })
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.get('/:id/disks', async (req, res) => {
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const disks = await ctx.pve.getNodeDisks(ctx.node.name)
    return res.json(disks)
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.get('/:id/disks/smart', async (req, res) => {
  const { disk } = req.query as { disk: string }
  if (!disk) return res.status(400).json({ error: 'disk parameter required' })
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const smart = await ctx.pve.getDiskSmart(ctx.node.name, disk)
    return res.json(smart)
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.get('/:id/syslog', async (req, res) => {
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const logs = await ctx.pve.getNodeSyslog(ctx.node.name, {
      limit: parseInt(req.query.limit as string) || 200,
      start: req.query.start ? parseInt(req.query.start as string) : undefined,
    })
    return res.json(logs)
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.get('/:id/tasks', async (req, res) => {
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const tasks = await ctx.pve.getNodeTasks(ctx.node.name, {
      limit: parseInt(req.query.limit as string) || 50,
      errors: req.query.errors === '1' ? 1 : undefined,
    })
    return res.json(tasks)
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.get('/:id/tasks/:upid/log', async (req, res) => {
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const log = await ctx.pve.getNodeTaskLog(ctx.node.name, req.params.upid)
    return res.json(log)
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.get('/:id/storage-content', async (req, res) => {
  const { storage, content } = req.query as { storage: string; content?: string }
  if (!storage) return res.status(400).json({ error: 'storage parameter required' })
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const items = await ctx.pve.getStorageContent(ctx.node.name, storage, content)
    return res.json(items)
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.delete('/:id/storage-content', async (req, res) => {
  const { storage, volid } = req.body
  if (!storage || !volid) return res.status(400).json({ error: 'storage and volid required' })
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const upid = await ctx.pve.deleteStorageContent(ctx.node.name, storage, volid)
    return res.json({ success: true, upid })
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.post('/:id/storage-download', async (req, res) => {
  const { storage, filename, url, content } = req.body
  if (!storage || !filename || !url || !content) {
    return res.status(400).json({ error: 'storage, filename, url, content required' })
  }
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const upid = await ctx.pve.downloadUrlToStorage(ctx.node.name, storage, filename, url, content)
    return res.json({ success: true, upid })
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.get('/:id/apt-updates', async (req, res) => {
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const updates = await ctx.pve.getNodeAptUpdates(ctx.node.name)
    return res.json(updates || [])
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.post('/:id/apt-fetch', async (req, res) => {
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const upid = await ctx.pve.triggerAptFetch(ctx.node.name)
    return res.json({ success: true, upid })
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.get('/:id/firewall-rules', async (req, res) => {
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const rules = await ctx.pve.getFirewallRules(ctx.node.name)
    return res.json(rules || [])
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.post('/:id/firewall-rules', async (req, res) => {
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    await ctx.pve.createFirewallRule(ctx.node.name, req.body)
    return res.json({ success: true })
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.delete('/:id/firewall-rules/:pos', async (req, res) => {
  const pos = parseInt(req.params.pos)
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    await ctx.pve.deleteFirewallRule(ctx.node.name, pos)
    return res.json({ success: true })
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.get('/:id/network', async (req, res) => {
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const network = await ctx.pve.getNodeNetwork(ctx.node.name)
    return res.json(network)
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.get('/:id/vm-config', async (req, res) => {
  const { vmid, type } = req.query as { vmid: string; type: string }
  if (!vmid) return res.status(400).json({ error: 'vmid required' })
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const cfg = await ctx.pve.getVMConfig(ctx.node.name, parseInt(vmid), (type || 'qemu') as 'qemu' | 'lxc')
    return res.json(cfg)
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.put('/:id/vm-config', async (req, res) => {
  const { vmid, type, ...cfg } = req.body
  if (!vmid) return res.status(400).json({ error: 'vmid required' })
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    if (type === 'lxc') {
      await ctx.pve.configureLXC(ctx.node.name, vmid, cfg)
    } else {
      await ctx.pve.configureVM(ctx.node.name, vmid, cfg)
    }
    return res.json({ success: true })
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.get('/:id/status', async (req, res) => {
  const ctx = await getNodeAndCluster(req.params.id)
  if (!ctx) return res.status(404).json({ error: 'Node not found' })
  try {
    const status = await ctx.pve.getNodeStatus(ctx.node.name)
    return res.json({ ...status, nodeName: ctx.node.name, nodeId: ctx.node.id })
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

export default router
