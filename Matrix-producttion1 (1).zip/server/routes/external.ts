/**
 * External API — authenticated via API token in Authorization header.
 * All provisioning returns a job ID immediately.
 */
import { Router } from 'express'
import { db } from '../db/index.js'
import {
  servers, apiTokens, jobs as jobsTable,
} from '../db/schema.js'
import { eq, and } from 'drizzle-orm'
import { createHash } from 'crypto'
import { createJob } from '../services/jobs.js'
import { fireWebhook } from '../services/webhooks.js'

const router = Router()

// ── Token authentication middleware ──────────────────────────────────────────
router.use(async (req, res, next) => {
  const authHeader = req.headers['authorization']
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing Bearer token' })
  }
  const rawToken = authHeader.slice(7)
  const tokenHash = createHash('sha256').update(rawToken).digest('hex')
  const token = db.select().from(apiTokens).where(and(eq(apiTokens.tokenHash, tokenHash), eq(apiTokens.isActive, true))).get()
  if (!token) return res.status(401).json({ error: 'Invalid or inactive API token' })

  ;(req as any).apiToken = token
  ;(req as any).apiUserId = token.userId
  next()
})

// ── GET /api/external/servers/:id/status ─────────────────────────────────────
router.get('/servers/:id/status', (req, res) => {
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  return res.json({
    id: server.id,
    status: server.status,
    vmid: server.vmid,
    ip: server.primaryIpv4,
    virtType: server.virtType,
  })
})

// ── GET /api/external/jobs/:id ────────────────────────────────────────────────
router.get('/jobs/:id', (req, res) => {
  const job = db.select().from(jobsTable).where(eq(jobsTable.id, req.params.id)).get()
  if (!job) return res.status(404).json({ error: 'Job not found' })
  return res.json({
    id: job.id, type: job.type, status: job.status,
    progress: job.progress, message: job.message, error: job.error,
    upid: job.upid, createdAt: job.createdAt, completedAt: job.completedAt,
  })
})

// ── POST /api/external/servers/:id/suspend ───────────────────────────────────
router.post('/servers/:id/suspend', async (req, res) => {
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  if (server.status === 'suspended') return res.json({ message: 'Already suspended' })

  const jobId = createJob({ type: 'power', serverId: server.id, action: 'stop', userId: (req as any).apiUserId })
  db.update(servers).set({ isSuspended: true, updatedAt: new Date().toISOString() } as any)
    .where(eq(servers.id, server.id)).run()
  fireWebhook('server.suspended', { serverId: server.id }).catch(() => {})
  return res.json({ jobId, message: 'Suspension queued' })
})

// ── POST /api/external/servers/:id/unsuspend ─────────────────────────────────
router.post('/servers/:id/unsuspend', async (req, res) => {
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })

  const jobId = createJob({ type: 'power', serverId: server.id, action: 'start', userId: (req as any).apiUserId })
  db.update(servers).set({ isSuspended: false, updatedAt: new Date().toISOString() } as any)
    .where(eq(servers.id, server.id)).run()
  fireWebhook('server.unsuspended', { serverId: server.id }).catch(() => {})
  return res.json({ jobId, message: 'Unsuspension queued' })
})

// ── POST /api/external/servers/:id/terminate ─────────────────────────────────
router.post('/servers/:id/terminate', async (req, res) => {
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  if (server.status === 'terminated') return res.json({ message: 'Already terminated' })

  db.update(servers).set({ status: 'terminating', updatedAt: new Date().toISOString() })
    .where(eq(servers.id, server.id)).run()

  const jobId = createJob({ type: 'delete', serverId: server.id, userId: (req as any).apiUserId })
  return res.json({ jobId, message: 'Termination queued' })
})

// ── POST /api/external/servers/:id/resize ────────────────────────────────────
router.post('/servers/:id/resize', async (req, res) => {
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })

  const { vcpuCores, ramMb, diskGb } = req.body
  const jobId = createJob({
    type: 'resize', serverId: server.id, userId: (req as any).apiUserId,
    params: { vcpuCores, ramMb, diskGb },
  })
  return res.json({ jobId, message: 'Resize queued' })
})

export default router
