import { Router } from 'express'
import bcrypt from 'bcryptjs'
import { nanoid } from 'nanoid'
import { z } from 'zod'
import crypto from 'crypto'
import { db } from '../db/index.js'
import { users, apiTokens, activityLogs } from '../db/schema.js'
import { eq } from 'drizzle-orm'
import { requireAuth } from '../middleware/auth.js'

const router = Router()
router.use(requireAuth)

router.put('/', async (req, res) => {
  try {
    const body = z.object({
      firstName: z.string().max(64).optional(),
      lastName: z.string().max(64).optional(),
      email: z.string().email().optional(),
    }).parse(req.body)

    const now = new Date().toISOString()
    if (body.email) {
      const existing = db.select().from(users).where(eq(users.email, body.email)).get()
      if (existing && existing.id !== req.user!.id) {
        return res.status(409).json({ error: 'Email already in use' })
      }
    }

    db.update(users).set({
      ...(body.firstName !== undefined ? { firstName: body.firstName } : {}),
      ...(body.lastName !== undefined ? { lastName: body.lastName } : {}),
      ...(body.email ? { email: body.email } : {}),
      updatedAt: now,
    }).where(eq(users.id, req.user!.id)).run()

    const user = db.select().from(users).where(eq(users.id, req.user!.id)).get()!
    return res.json({
      id: user.id, email: user.email, username: user.username,
      firstName: user.firstName, lastName: user.lastName, role: user.role,
    })
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: 'Validation failed', details: err.errors })
    console.error(err)
    return res.status(500).json({ error: 'Internal server error' })
  }
})

router.put('/password', async (req, res) => {
  try {
    const body = z.object({
      currentPassword: z.string(),
      newPassword: z.string().min(8),
    }).parse(req.body)

    const user = db.select().from(users).where(eq(users.id, req.user!.id)).get()
    if (!user) return res.status(404).json({ error: 'User not found' })

    const valid = await bcrypt.compare(body.currentPassword, user.passwordHash)
    if (!valid) return res.status(400).json({ error: 'Current password is incorrect' })

    const hash = await bcrypt.hash(body.newPassword, 12)
    db.update(users).set({ passwordHash: hash, updatedAt: new Date().toISOString() })
      .where(eq(users.id, req.user!.id)).run()

    db.insert(activityLogs).values({
      id: nanoid(), userId: req.user!.id, actorId: req.user!.id,
      action: 'user.password_changed', ipAddress: req.ip, createdAt: new Date().toISOString(),
    }).run()

    return res.json({ success: true })
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: 'Validation failed', details: err.errors })
    return res.status(500).json({ error: 'Internal server error' })
  }
})

router.get('/tokens', (req, res) => {
  const tokens = db.select().from(apiTokens).where(eq(apiTokens.userId, req.user!.id)).all()
  return res.json(tokens.filter(t => t.isActive).map(t => ({
    id: t.id, name: t.name, lastUsedAt: t.lastUsedAt,
    expiresAt: t.expiresAt, isActive: t.isActive, createdAt: t.createdAt,
    scopes: JSON.parse(t.scopes || '[]'),
  })))
})

router.post('/tokens', async (req, res) => {
  try {
    const body = z.object({ name: z.string().min(1).max(64) }).parse(req.body)
    const raw = crypto.randomBytes(32).toString('hex')
    const tokenHash = crypto.createHash('sha256').update(raw).digest('hex')
    const id = nanoid()
    const now = new Date().toISOString()

    db.insert(apiTokens).values({
      id, userId: req.user!.id, name: body.name,
      tokenHash, isActive: true, scopes: '[]', createdAt: now,
    }).run()

    return res.status(201).json({ id, token: `mh_${raw}` })
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: 'Validation failed', details: err.errors })
    return res.status(500).json({ error: 'Internal server error' })
  }
})

router.delete('/tokens/:id', (req, res) => {
  const token = db.select().from(apiTokens).where(eq(apiTokens.id, req.params.id)).get()
  if (!token || token.userId !== req.user!.id) {
    return res.status(404).json({ error: 'Token not found' })
  }
  db.update(apiTokens).set({ isActive: false }).where(eq(apiTokens.id, req.params.id)).run()
  return res.json({ success: true })
})

export default router
