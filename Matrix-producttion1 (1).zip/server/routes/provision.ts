import { Router } from 'express'
import { z } from 'zod'
import { nanoid } from 'nanoid'
import { db } from '../db/index.js'
import {
  servers, proxmoxClusters, proxmoxNodes, templates,
  ipAddresses, ipPools, activityLogs, storagePools, networkBridges,
  vmidReservations, users,
} from '../db/schema.js'
import { eq, and, lt } from 'drizzle-orm'
import { requireAuth, requireRole } from '../middleware/auth.js'
import { makeProxmox } from '../services/proxmox.js'
import { createJob } from '../services/jobs.js'

const router = Router()
router.use(requireAuth)
router.use(requireRole('superadmin', 'admin'))

interface NodeScore {
  node: typeof proxmoxNodes.$inferSelect
  score: number
}

function selectBestNode(
  clusterNodes: (typeof proxmoxNodes.$inferSelect)[],
  requiredRamMb: number,
  requiredCores: number,
  storagePoolName: string,
  bridgeName: string,
  templateNode: string,
): typeof proxmoxNodes.$inferSelect | null {
  const eligible = clusterNodes.filter(n => {
    if (n.status !== 'online') return false
    if (n.isMaintenanceMode) return false
    if (!n.isProvisioningEnabled) return false
    const freeRam = (n.totalRam ?? 0) - (n.usedRam ?? 0)
    if (freeRam < requiredRamMb * 1024 * 1024) return false
    return true
  })

  if (!eligible.length) return null

  const scored: NodeScore[] = eligible.map(n => {
    const freeRam = (n.totalRam ?? 0) - (n.usedRam ?? 0)
    const totalRam = n.totalRam ?? 1
    const freeRamPct = freeRam / totalRam
    const cpuLoad = n.cpuUsage ?? 0
    const cpuScore = 1 - cpuLoad
    const ramScore = freeRamPct

    // Bonus if template lives on same node (reduces clone traffic)
    const sameNodeBonus = n.name === templateNode ? 0.2 : 0

    // Check storage pool exists on this node
    const hasStorage = !storagePoolName || db.select().from(storagePools)
      .where(and(eq(storagePools.node, n.name), eq(storagePools.storage, storagePoolName)))
      .get() != null
    if (!hasStorage) return { node: n, score: -1 }

    // Check bridge exists on this node
    const hasBridge = !bridgeName || db.select().from(networkBridges)
      .where(and(eq(networkBridges.node, n.name), eq(networkBridges.iface, bridgeName)))
      .get() != null
    if (!hasBridge) return { node: n, score: -1 }

    const score = ramScore * 0.5 + cpuScore * 0.3 + sameNodeBonus + Math.random() * 0.05
    return { node: n, score }
  })

  const best = scored.filter(s => s.score >= 0).sort((a, b) => b.score - a.score)[0]
  return best?.node ?? null
}

function reserveVmid(clusterId: string, vmid: number, serverId: string): boolean {
  const now = new Date().toISOString()
  const expiry = new Date(Date.now() + 10 * 60 * 1000).toISOString()
  try {
    // Remove only expired reservations for THIS vmid (allows re-use after expiry)
    db.delete(vmidReservations)
      .where(and(
        eq(vmidReservations.clusterId, clusterId),
        eq(vmidReservations.vmid, vmid),
        eq(vmidReservations.status, 'reserved'),
        lt(vmidReservations.expiresAt, now),
      ))
      .run()

    // Try to insert — will fail with UNIQUE violation if (clusterId, vmid, 'reserved') already exists
    db.insert(vmidReservations).values({
      id: nanoid(),
      clusterId,
      vmid,
      serverId,
      status: 'reserved',
      expiresAt: expiry,
      createdAt: now,
    }).run()
    return true
  } catch {
    return false
  }
}

const provisionSchema = z.object({
  userId: z.string(),
  clusterId: z.string(),
  nodeId: z.string().optional(),
  templateId: z.string(),
  displayName: z.string().min(2).max(64),
  hostname: z.string().min(2).max(64).regex(/^[a-zA-Z0-9-]+$/),
  cpuCores: z.number().int().min(1),
  ramMb: z.number().int().min(128),
  diskGb: z.number().int().min(1),
  storagePool: z.string().optional().default('local'),
  ipPoolId: z.string().optional(),
  password: z.string().optional(),
  username: z.string().optional(),
  sshKeys: z.string().optional(),
  bridge: z.string().optional().default('vmbr0'),
  nameserver: z.string().optional().default('1.1.1.1'),
})

router.post('/', async (req, res) => {
  try {
    const body = provisionSchema.parse(req.body)

    // ── User validation ──────────────────────────────────────────────────────
    const user = db.select().from(users).where(eq(users.id, body.userId)).get()
    if (!user || !user.isActive) return res.status(400).json({ error: 'User not found or inactive' })

    // ── Cluster validation ───────────────────────────────────────────────────
    const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, body.clusterId)).get()
    if (!cluster) return res.status(400).json({ error: 'Cluster not found' })
    if (!cluster.isEnabled) return res.status(400).json({ error: 'Cluster is disabled' })
    if (cluster.connectionStatus !== 'connected') return res.status(400).json({ error: 'Cluster is not connected — run a sync first' })

    // ── Template validation ──────────────────────────────────────────────────
    const template = db.select().from(templates).where(eq(templates.id, body.templateId)).get()
    if (!template || !template.isEnabled) return res.status(400).json({ error: 'Template not found or disabled' })
    if (template.clusterId !== cluster.id) return res.status(400).json({ error: 'Template does not belong to this cluster' })

    // Check virtType compatibility
    // ── Node validation ──────────────────────────────────────────────────────
    const clusterNodes = db.select().from(proxmoxNodes).where(eq(proxmoxNodes.clusterId, cluster.id)).all()
    const storagePoolName = body.storagePool || 'local'
    const bridgeName = body.bridge

    let node: typeof proxmoxNodes.$inferSelect | null = null
    if (body.nodeId) {
      node = clusterNodes.find(n => n.id === body.nodeId) ?? null
      if (!node) return res.status(400).json({ error: 'Node not found in this cluster' })
      if (node.status !== 'online') return res.status(400).json({ error: 'Node is offline' })
      if (node.isMaintenanceMode) return res.status(400).json({ error: 'Node is in maintenance mode' })
      if (!node.isProvisioningEnabled) return res.status(400).json({ error: 'Node does not allow provisioning' })

      const freeRam = (node.totalRam ?? 0) - (node.usedRam ?? 0)
      if (freeRam < body.ramMb * 1024 * 1024) {
        return res.status(400).json({ error: `Node has insufficient RAM (need ${body.ramMb} MB, free: ${Math.floor(freeRam / 1024 / 1024)} MB)` })
      }
    } else {
      node = selectBestNode(clusterNodes, body.ramMb, body.cpuCores, storagePoolName, bridgeName, template.node ?? '')
      if (!node) return res.status(400).json({ error: 'No suitable provisioning node available (check RAM, storage, bridge, and maintenance status)' })
    }

    // ── Get next VMID from Proxmox + DB reservation ──────────────────────────
    let vmid: number
    try {
      const pve = makeProxmox(cluster)
      vmid = await pve.getNextVMID()

      // Verify VMID is not already in use by our DB
      const inUse = db.select().from(servers).where(eq(servers.vmid, vmid)).get()
      if (inUse) {
        vmid = await pve.getNextVMID() // try once more
      }
    } catch (err: any) {
      return res.status(502).json({ error: `Cannot get next VMID: ${err.message}` })
    }

    // ── IP pool validation + reservation ────────────────────────────────────
    let ipv4: string | undefined
    let gateway: string | undefined
    let subnetPrefix: string = '24'
    let allocatedIpId: string | undefined

    if (body.ipPoolId) {
      const pool = db.select().from(ipPools).where(eq(ipPools.id, body.ipPoolId)).get()
      if (!pool) return res.status(400).json({ error: 'IP pool not found' })
      if (!pool.isEnabled) return res.status(400).json({ error: 'IP pool is disabled' })

      const ip = db.select().from(ipAddresses)
        .where(and(eq(ipAddresses.poolId, body.ipPoolId), eq(ipAddresses.status, 'available')))
        .get()
      if (!ip) return res.status(400).json({ error: 'No available IPs in pool' })

      gateway = pool.gateway
      // Extract prefix from subnet (handles "24", "192.168.1.0/24", "/24")
      const subnetStr = pool.subnet || '24'
      const match = subnetStr.match(/\/(\d+)$/) || subnetStr.match(/^(\d{1,3})$/)
      subnetPrefix = match ? match[1] : '24'

      ipv4 = ip.address
      allocatedIpId = ip.id
      // Mark as reserved (not yet allocated — allocation happens after Proxmox success)
      db.update(ipAddresses).set({ status: 'reserved', updatedAt: new Date().toISOString() })
        .where(eq(ipAddresses.id, ip.id)).run()
    }

    // ── Create server record ─────────────────────────────────────────────────
    const now = new Date().toISOString()
    const serverId = nanoid()
    const virtType = template.virtType === 'lxc' ? 'lxc' : 'kvm'

    // Reserve VMID in our DB
    reserveVmid(cluster.id, vmid, serverId)

    db.insert(servers).values({
      id: serverId,
      userId: body.userId,
      nodeId: node.id,
      clusterId: cluster.id,
      displayName: body.displayName,
      hostname: body.hostname,
      vmid,
      virtType: virtType as 'kvm' | 'lxc',
      status: 'provisioning',
      os: template.osName ? `${template.osName} ${template.osVersion ?? ''}`.trim() : template.name,
      vcpuCores: body.cpuCores,
      ramMb: body.ramMb,
      diskGb: body.diskGb,
      primaryIpv4: ipv4 ?? null,
      createdAt: now,
      updatedAt: now,
    }).run()

    db.insert(activityLogs).values({
      id: nanoid(), userId: body.userId, actorId: req.user!.id,
      action: 'server.provision.start', targetType: 'server', targetId: serverId,
      ipAddress: req.ip, metadata: JSON.stringify({ vmid, node: node.name, template: template.name }),
      createdAt: now,
    }).run()

    const jobId = createJob({
      type: 'provision',
      serverId,
      clusterId: cluster.id,
      userId: req.user!.id,
      node: node.name,
      vmid,
      virtType: template.virtType === 'lxc' ? 'lxc' : 'qemu',
      params: {
        templateVmid: template.vmid,
        volid: template.volid,
        storage: storagePoolName,
        bridge: bridgeName,
        nameserver: body.nameserver,
        password: body.password,
        username: body.username,
        sshKeys: body.sshKeys,
        ipv4,
        gateway,
        subnetPrefix,
        ipPoolId: body.ipPoolId,
        allocatedIpId,
      },
    })

    return res.status(201).json({ serverId, jobId, vmid, message: 'Provisioning started' })
  } catch (err: any) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: 'Validation failed', details: err.errors })
    return res.status(500).json({ error: err.message })
  }
})

export default router
