import { Router } from 'express'
import { db } from '../db/index.js'
import {
  servers, proxmoxClusters, proxmoxNodes, activityLogs, jobs, snapshots,
  serverTimers, backups, ipPools, templates,
} from '../db/schema.js'
import { eq, and, desc } from 'drizzle-orm'
import { requireAuth, requireRole } from '../middleware/auth.js'
import { nanoid } from 'nanoid'
import { makeProxmox } from '../services/proxmox.js'
import { createJob, getJob } from '../services/jobs.js'

const router = Router()
router.use(requireAuth)

router.get('/', (req, res) => {
  const userServers = db.select().from(servers)
    .where(eq(servers.userId, req.user!.id))
    .all()
    .filter(s => s.status !== 'terminated')
  return res.json(userServers)
})

router.get('/dashboard', (req, res) => {
  const userServers = db.select().from(servers).where(eq(servers.userId, req.user!.id)).all()
  const total = userServers.length
  const running = userServers.filter(s => s.status === 'running').length
  const stopped = userServers.filter(s => s.status === 'stopped').length
  const suspended = userServers.filter(s => s.isSuspended).length
  const totalVcpu = userServers.reduce((a, s) => a + s.vcpuCores, 0)
  const totalRam = userServers.reduce((a, s) => a + s.ramMb, 0)
  const totalDisk = userServers.reduce((a, s) => a + s.diskGb, 0)
  return res.json({ total, running, stopped, suspended, totalVcpu, totalRam, totalDisk, servers: userServers })
})

router.get('/:id', (req, res) => {
  const server = db.select().from(servers)
    .where(and(eq(servers.id, req.params.id), eq(servers.userId, req.user!.id)))
    .get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  return res.json(server)
})

// ─── Power (real Proxmox) ─────────────────────────────────────────────────────
router.post('/:id/power', async (req, res) => {
  const { action } = req.body
  if (!['start', 'stop', 'restart', 'shutdown', 'reset'].includes(action)) {
    return res.status(400).json({ error: 'Invalid power action' })
  }

  const server = db.select().from(servers)
    .where(and(eq(servers.id, req.params.id), eq(servers.userId, req.user!.id)))
    .get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  if (server.isSuspended) return res.status(403).json({ error: 'Server is suspended' })

  // If no Proxmox node assigned, fall back to DB-only (demo mode)
  if (!server.clusterId || !server.nodeId || !server.vmid) {
    const newStatus = action === 'start' ? 'running' : ['stop', 'shutdown', 'reset'].includes(action) ? 'stopped' : server.status
    db.update(servers).set({ status: newStatus as any, updatedAt: new Date().toISOString() }).where(eq(servers.id, server.id)).run()
    db.insert(activityLogs).values({ id: nanoid(), userId: req.user!.id, actorId: req.user!.id, action: `server.power.${action}`, targetType: 'server', targetId: server.id, ipAddress: req.ip, createdAt: new Date().toISOString() }).run()
    return res.json({ success: true, status: newStatus, mode: 'demo' })
  }

  // Queue real Proxmox job
  const jobId = createJob({ type: 'power', serverId: server.id, userId: req.user!.id, action })
  db.insert(activityLogs).values({ id: nanoid(), userId: req.user!.id, actorId: req.user!.id, action: `server.power.${action}`, targetType: 'server', targetId: server.id, ipAddress: req.ip, createdAt: new Date().toISOString() }).run()
  return res.json({ success: true, jobId, message: `Power action "${action}" queued` })
})

// ─── Job status ───────────────────────────────────────────────────────────────
router.get('/:id/jobs', (req, res) => {
  const server = db.select().from(servers).where(and(eq(servers.id, req.params.id), eq(servers.userId, req.user!.id))).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  const list = db.select().from(jobs).where(eq(jobs.serverId, server.id)).orderBy(desc(jobs.createdAt)).limit(20).all()
  return res.json(list)
})

router.get('/jobs/:jobId', (req, res) => {
  const job = getJob(req.params.jobId)
  if (!job) return res.status(404).json({ error: 'Job not found' })
  return res.json(job)
})

// ─── Sync status from Proxmox ─────────────────────────────────────────────────
router.post('/:id/sync', async (req, res) => {
  const server = db.select().from(servers).where(and(eq(servers.id, req.params.id), eq(servers.userId, req.user!.id))).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  if (!server.clusterId || !server.nodeId || !server.vmid) {
    return res.json({ server, synced: false, reason: 'No Proxmox assignment' })
  }

  const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, server.clusterId)).get()
  const node = db.select().from(proxmoxNodes).where(eq(proxmoxNodes.id, server.nodeId)).get()
  if (!cluster || !node) return res.status(500).json({ error: 'Cluster/node not found' })

  try {
    const pve = makeProxmox(cluster)
    const type = (server.virtType === 'lxc' ? 'lxc' : 'qemu') as 'qemu' | 'lxc'
    const vmStatus = await pve.getVMStatus(node.name, server.vmid, type)
    db.update(servers).set({ status: vmStatus.status as any, updatedAt: new Date().toISOString() }).where(eq(servers.id, server.id)).run()
    return res.json({ server: { ...server, status: vmStatus.status }, synced: true, vmStatus })
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

// ─── Metrics (Proxmox RRD) ────────────────────────────────────────────────────
router.get('/:id/metrics', async (req, res) => {
  const server = db.select().from(servers).where(and(eq(servers.id, req.params.id), eq(servers.userId, req.user!.id))).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  if (!server.clusterId || !server.nodeId || !server.vmid) {
    return res.json({ data: [], source: 'none' })
  }

  const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, server.clusterId)).get()
  const node = db.select().from(proxmoxNodes).where(eq(proxmoxNodes.id, server.nodeId)).get()
  if (!cluster || !node) return res.status(500).json({ error: 'Cluster/node not found' })

  const timeframe = (req.query.timeframe as string) || 'hour'
  const validFrames = ['hour', 'day', 'week', 'month', 'year']
  if (!validFrames.includes(timeframe)) return res.status(400).json({ error: 'Invalid timeframe' })

  try {
    const pve = makeProxmox(cluster)
    const type = (server.virtType === 'lxc' ? 'lxc' : 'qemu') as 'qemu' | 'lxc'
    const data = await pve.getRRDData(node.name, server.vmid, type, timeframe)
    return res.json({ data, source: 'proxmox', timeframe })
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

// ─── Snapshots ────────────────────────────────────────────────────────────────
router.get('/:id/snapshots', async (req, res) => {
  const server = db.select().from(servers).where(and(eq(servers.id, req.params.id), eq(servers.userId, req.user!.id))).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })

  // Return DB snapshots; optionally sync from Proxmox
  const dbSnaps = db.select().from(snapshots).where(eq(snapshots.serverId, server.id)).orderBy(desc(snapshots.createdAt)).all()

  if (server.clusterId && server.nodeId && server.vmid) {
    try {
      const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, server.clusterId)).get()
      const node = db.select().from(proxmoxNodes).where(eq(proxmoxNodes.id, server.nodeId)).get()
      if (cluster && node) {
        const pve = makeProxmox(cluster)
        const type = (server.virtType === 'lxc' ? 'lxc' : 'qemu') as 'qemu' | 'lxc'
        const pveSnaps = await pve.listSnapshots(node.name, server.vmid, type)
        return res.json({ snapshots: dbSnaps, proxmoxSnapshots: pveSnaps.filter(s => s.name !== 'current') })
      }
    } catch {}
  }
  return res.json({ snapshots: dbSnaps, proxmoxSnapshots: [] })
})

router.post('/:id/snapshots', async (req, res) => {
  const server = db.select().from(servers).where(and(eq(servers.id, req.params.id), eq(servers.userId, req.user!.id))).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  if (server.isSuspended) return res.status(403).json({ error: 'Server is suspended' })
  if (!server.clusterId || !server.nodeId || !server.vmid) return res.status(400).json({ error: 'Server not assigned to Proxmox' })

  const { name, description } = req.body
  if (!name) return res.status(400).json({ error: 'Snapshot name required' })

  const snapname = name.replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, 40)
  const snapId = nanoid()
  db.insert(snapshots).values({ id: snapId, serverId: server.id, name, description, proxmoxName: snapname, status: 'creating', createdAt: new Date().toISOString() }).run()

  const jobId = createJob({ type: 'snapshot', serverId: server.id, userId: req.user!.id, params: { snapname, description } })
  db.update(snapshots).set({ status: 'available' }).where(eq(snapshots.id, snapId)).run()

  return res.json({ snapId, jobId, message: 'Snapshot queued' })
})

router.delete('/:id/snapshots/:snapname', async (req, res) => {
  const server = db.select().from(servers).where(and(eq(servers.id, req.params.id), eq(servers.userId, req.user!.id))).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  if (!server.clusterId || !server.nodeId || !server.vmid) return res.status(400).json({ error: 'Server not assigned to Proxmox' })

  const jobId = createJob({ type: 'snapshot_delete', serverId: server.id, userId: req.user!.id, params: { snapname: req.params.snapname } })
  db.update(snapshots).set({ status: 'deleting' }).where(and(eq(snapshots.serverId, server.id), eq(snapshots.proxmoxName, req.params.snapname))).run()
  return res.json({ jobId })
})

router.post('/:id/snapshots/:snapname/rollback', async (req, res) => {
  const server = db.select().from(servers).where(and(eq(servers.id, req.params.id), eq(servers.userId, req.user!.id))).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  if (!server.clusterId || !server.nodeId || !server.vmid) return res.status(400).json({ error: 'Server not assigned to Proxmox' })

  const jobId = createJob({ type: 'snapshot_rollback', serverId: server.id, userId: req.user!.id, params: { snapname: req.params.snapname } })
  return res.json({ jobId, message: 'Rollback queued' })
})

// ─── Server Timer ─────────────────────────────────────────────────────────────
router.get('/:id/timer', (req, res) => {
  const server = db.select().from(servers).where(and(eq(servers.id, req.params.id), eq(servers.userId, req.user!.id))).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  const timer = db.select().from(serverTimers)
    .where(and(eq(serverTimers.serverId, server.id), eq(serverTimers.status, 'pending')))
    .orderBy(desc(serverTimers.createdAt))
    .get()
  return res.json({ timer: timer || null })
})

router.post('/:id/timer', (req, res) => {
  const server = db.select().from(servers).where(and(eq(servers.id, req.params.id), eq(servers.userId, req.user!.id))).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  if (server.isSuspended) return res.status(403).json({ error: 'Server is suspended' })

  const { action, minutes } = req.body
  if (!['start', 'stop', 'shutdown', 'restart', 'reset'].includes(action)) {
    return res.status(400).json({ error: 'Invalid action' })
  }
  const mins = parseInt(minutes)
  if (isNaN(mins) || mins < 1 || mins > 1440) {
    return res.status(400).json({ error: 'Minutes must be between 1 and 1440' })
  }

  db.update(serverTimers).set({ status: 'cancelled' })
    .where(and(eq(serverTimers.serverId, server.id), eq(serverTimers.status, 'pending'))).run()

  const triggerAt = new Date(Date.now() + mins * 60 * 1000).toISOString()
  const timerId = nanoid()
  db.insert(serverTimers).values({
    id: timerId, serverId: server.id, userId: req.user!.id,
    action, triggerAt, status: 'pending', createdAt: new Date().toISOString(),
  }).run()
  db.insert(activityLogs).values({
    id: nanoid(), userId: req.user!.id, actorId: req.user!.id,
    action: 'server.timer.set', targetType: 'server', targetId: server.id,
    ipAddress: req.ip, metadata: JSON.stringify({ action, minutes: mins, triggerAt }),
    createdAt: new Date().toISOString(),
  }).run()
  return res.json({ id: timerId, action, minutes: mins, triggerAt })
})

router.delete('/:id/timer', (req, res) => {
  const server = db.select().from(servers).where(and(eq(servers.id, req.params.id), eq(servers.userId, req.user!.id))).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  db.update(serverTimers).set({ status: 'cancelled' })
    .where(and(eq(serverTimers.serverId, server.id), eq(serverTimers.status, 'pending'))).run()
  db.insert(activityLogs).values({
    id: nanoid(), userId: req.user!.id, actorId: req.user!.id,
    action: 'server.timer.cancel', targetType: 'server', targetId: server.id,
    ipAddress: req.ip, createdAt: new Date().toISOString(),
  }).run()
  return res.json({ success: true })
})

// ─── Delete server ────────────────────────────────────────────────────────────
router.delete('/:id', async (req, res) => {
  const server = db.select().from(servers).where(and(eq(servers.id, req.params.id), eq(servers.userId, req.user!.id))).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })

  db.update(servers).set({ status: 'terminating', updatedAt: new Date().toISOString() }).where(eq(servers.id, server.id)).run()

  if (server.clusterId && server.nodeId && server.vmid) {
    const jobId = createJob({ type: 'delete', serverId: server.id, userId: req.user!.id })
    return res.json({ jobId, message: 'Deletion queued' })
  }

  db.update(servers).set({ status: 'terminated', deletedAt: new Date().toISOString(), updatedAt: new Date().toISOString() }).where(eq(servers.id, server.id)).run()
  return res.json({ success: true })
})

// ── Backups ───────────────────────────────────────────────────────────────────
router.get('/:id/backups', (req, res) => {
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  const list = db.select().from(backups).where(eq(backups.serverId, server.id)).all()
  return res.json(list)
})

router.post('/:id/backups', async (req, res) => {
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })

  const existingCount = db.select().from(backups).where(eq(backups.serverId, server.id)).all().filter(b => b.status === 'available').length
  const storage = req.body.storage || 'local'
  const now = new Date().toISOString()
  const backupId = nanoid()
  db.insert(backups).values({
    id: backupId,
    serverId: server.id,
    name: req.body.name || `backup-${Date.now()}`,
    node: req.body.node || '',
    storage,
    status: 'creating',
    backupType: req.body.mode || 'stop',
    createdAt: now,
  }).run()

  const jobId = createJob({
    type: 'backup',
    serverId: server.id,
    userId: req.user!.id,
    params: { storage, mode: req.body.mode || 'stop', notes: req.body.notes, backupId },
  })
  return res.status(201).json({ backupId, jobId, message: 'Backup started' })
})

router.delete('/:id/backups/:backupId', async (req, res) => {
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  const backup = db.select().from(backups).where(and(eq(backups.id, req.params.backupId), eq(backups.serverId, server.id))).get()
  if (!backup) return res.status(404).json({ error: 'Backup not found' })

  const jobId = createJob({
    type: 'backup_delete',
    serverId: server.id,
    userId: req.user!.id,
    params: { storage: backup.storage, volid: backup.volid, backupId: backup.id },
  })
  return res.json({ jobId, message: 'Backup deletion queued' })
})

router.post('/:id/backups/:backupId/restore', async (req, res) => {
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  const backup = db.select().from(backups).where(and(eq(backups.id, req.params.backupId), eq(backups.serverId, server.id))).get()
  if (!backup) return res.status(404).json({ error: 'Backup not found' })
  if (!backup.volid) return res.status(400).json({ error: 'Backup volid not set — backup may still be creating' })

  const jobId = createJob({
    type: 'backup_restore',
    serverId: server.id,
    userId: req.user!.id,
    params: { storage: backup.storage, volid: backup.volid },
  })
  return res.json({ jobId, message: 'Restore queued' })
})

// ── Migration ─────────────────────────────────────────────────────────────────
router.post('/:id/migrate', async (req, res) => {
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  if (!req.body.targetNode) return res.status(400).json({ error: 'targetNode is required' })

  const targetNode = db.select().from(proxmoxNodes)
    .where(and(eq(proxmoxNodes.clusterId, server.clusterId!), eq(proxmoxNodes.name, req.body.targetNode)))
    .get()
  if (!targetNode) return res.status(400).json({ error: 'Target node not found in cluster' })
  if (targetNode.status !== 'online') return res.status(400).json({ error: 'Target node is offline' })

  const jobId = createJob({
    type: 'migrate',
    serverId: server.id,
    userId: req.user!.id,
    params: {
      targetNode: req.body.targetNode,
      targetStorage: req.body.targetStorage,
    },
  })
  return res.json({ jobId, message: 'Migration queued' })
})

// ── Reinstall ─────────────────────────────────────────────────────────────────
router.post('/:id/reinstall', async (req, res) => {
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  if (!req.body.templateId) return res.status(400).json({ error: 'templateId is required' })

  const template = db.select().from(templates).where(eq(templates.id, req.body.templateId)).get()
  if (!template) return res.status(404).json({ error: 'Template not found' })
  if (template.clusterId !== server.clusterId) return res.status(400).json({ error: 'Template does not belong to this server cluster' })

  const jobId = createJob({
    type: 'reinstall',
    serverId: server.id,
    userId: req.user!.id,
    params: {
      templateVmid: template.vmid,
      storage: req.body.storage || 'local',
      password: req.body.password,
      username: req.body.username,
      sshKeys: req.body.sshKeys,
      nameserver: req.body.nameserver,
      bridge: req.body.bridge,
      gateway: req.body.gateway,
      subnetPrefix: req.body.subnetPrefix || '24',
    },
  })
  return res.json({ jobId, message: 'Reinstall queued' })
})

// ── Resource resize ───────────────────────────────────────────────────────────
router.post('/:id/resize', async (req, res) => {
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })

  const { vcpuCores, ramMb, diskGb } = req.body
  if (!vcpuCores && !ramMb && !diskGb) {
    return res.status(400).json({ error: 'Specify at least one of: vcpuCores, ramMb, diskGb' })
  }
  if (diskGb && Number(diskGb) < server.diskGb) {
    return res.status(400).json({ error: 'Disk cannot be shrunk' })
  }

  const jobId = createJob({
    type: 'resize',
    serverId: server.id,
    userId: req.user!.id,
    params: { vcpuCores, ramMb, diskGb },
  })
  return res.json({ jobId, message: 'Resize queued' })
})

export default router
