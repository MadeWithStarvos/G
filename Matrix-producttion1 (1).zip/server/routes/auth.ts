import { Router } from 'express'
import bcrypt from 'bcryptjs'
import { nanoid } from 'nanoid'
import { z } from 'zod'
import { db } from '../db/index.js'
import { users, sessions, activityLogs } from '../db/schema.js'
import { eq } from 'drizzle-orm'
import { signToken, requireAuth } from '../middleware/auth.js'

const router = Router()

const registerSchema = z.object({
  email: z.string().email(),
  username: z.string().min(3).max(32).regex(/^[a-zA-Z0-9_-]+$/),
  password: z.string().min(8),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
})

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
})

router.post('/register', async (req, res) => {
  try {
    const body = registerSchema.parse(req.body)

    const existing = db.select().from(users).where(eq(users.email, body.email)).get()
    if (existing) {
      return res.status(409).json({ error: 'Email already in use' })
    }

    const existingUsername = db.select().from(users).where(eq(users.username, body.username)).get()
    if (existingUsername) {
      return res.status(409).json({ error: 'Username already taken' })
    }

    const passwordHash = await bcrypt.hash(body.password, 12)
    const userId = nanoid()
    const now = new Date().toISOString()

    db.insert(users).values({
      id: userId,
      email: body.email,
      username: body.username,
      passwordHash,
      firstName: body.firstName || null,
      lastName: body.lastName || null,
      role: 'customer',
      emailVerified: false,
      createdAt: now,
      updatedAt: now,
    }).run()

    const sessionId = nanoid()
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
    const token = signToken(userId, sessionId)

    db.insert(sessions).values({
      id: sessionId,
      userId,
      token,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      expiresAt,
      createdAt: now,
    }).run()

    db.insert(activityLogs).values({
      id: nanoid(),
      userId,
      actorId: userId,
      action: 'user.registered',
      ipAddress: req.ip,
      createdAt: now,
    }).run()

    const user = db.select().from(users).where(eq(users.id, userId)).get()!

    return res.status(201).json({
      token,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        emailVerified: user.emailVerified,
      },
    })
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: 'Validation failed', details: err.errors })
    }
    console.error('Register error:', err)
    return res.status(500).json({ error: 'Internal server error' })
  }
})

router.post('/login', async (req, res) => {
  try {
    const body = loginSchema.parse(req.body)

    const user = db.select().from(users).where(eq(users.email, body.email)).get()
    const now = new Date().toISOString()

    if (!user) {
      db.insert(activityLogs).values({
        id: nanoid(),
        action: 'auth.login_failed',
        ipAddress: req.ip,
        metadata: JSON.stringify({ email: body.email, reason: 'user_not_found' }),
        createdAt: now,
      }).run()
      return res.status(401).json({ error: 'Invalid credentials' })
    }

    const valid = await bcrypt.compare(body.password, user.passwordHash)
    if (!valid) {
      db.insert(activityLogs).values({
        id: nanoid(),
        userId: user.id,
        action: 'auth.login_failed',
        ipAddress: req.ip,
        metadata: JSON.stringify({ reason: 'invalid_password' }),
        createdAt: now,
      }).run()
      return res.status(401).json({ error: 'Invalid credentials' })
    }

    if (!user.isActive) {
      return res.status(403).json({ error: 'Account is inactive' })
    }
    if (user.isSuspended) {
      return res.status(403).json({ error: 'Account is suspended' })
    }

    const sessionId = nanoid()
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
    const token = signToken(user.id, sessionId)

    db.insert(sessions).values({
      id: sessionId,
      userId: user.id,
      token,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      expiresAt,
      createdAt: now,
    }).run()

    db.insert(activityLogs).values({
      id: nanoid(),
      userId: user.id,
      actorId: user.id,
      action: 'auth.login',
      ipAddress: req.ip,
      createdAt: now,
    }).run()

    return res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        emailVerified: user.emailVerified,
        twoFactorEnabled: user.twoFactorEnabled,
      },
    })
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: 'Validation failed', details: err.errors })
    }
    console.error('Login error:', err)
    return res.status(500).json({ error: 'Internal server error' })
  }
})

router.post('/logout', requireAuth, (req, res) => {
  const token = req.headers.authorization?.slice(7) || req.cookies?.token
  if (token) {
    db.delete(sessions).where(eq(sessions.token, token)).run()
  }
  const now = new Date().toISOString()
  db.insert(activityLogs).values({
    id: nanoid(),
    userId: req.user!.id,
    actorId: req.user!.id,
    action: 'auth.logout',
    ipAddress: req.ip,
    createdAt: now,
  }).run()
  return res.json({ success: true })
})

router.get('/me', requireAuth, (req, res) => {
  const user = db.select().from(users).where(eq(users.id, req.user!.id)).get()
  if (!user) return res.status(404).json({ error: 'User not found' })
  return res.json({
    id: user.id,
    email: user.email,
    username: user.username,
    firstName: user.firstName,
    lastName: user.lastName,
    role: user.role,
    emailVerified: user.emailVerified,
    twoFactorEnabled: user.twoFactorEnabled,
    createdAt: user.createdAt,
    lastLoginAt: user.lastLoginAt,
  })
})

export default router
