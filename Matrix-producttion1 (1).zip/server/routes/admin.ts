import { Router } from 'express'
import { nanoid } from 'nanoid'
import { z } from 'zod'
import { db } from '../db/index.js'
import {
  users, servers, proxmoxClusters, proxmoxNodes, locations,
  activityLogs, jobs, templates, storagePools, networkBridges, ipPools, ipAddresses, panelSettings,
  announcements, serverGroups, alerts,
} from '../db/schema.js'
import { eq, desc, count, and } from 'drizzle-orm'
import { requireAuth, requireRole } from '../middleware/auth.js'
import { makeProxmox } from '../services/proxmox.js'
import { createJob } from '../services/jobs.js'
import { OS_TEMPLATE_LIBRARY, getOSLibraryTemplate } from '../services/templateLibrary.js'

const router = Router()
router.use(requireAuth)
router.use(requireRole('superadmin', 'admin'))

// ─── Dashboard ───────────────────────────────────────────────────────────────
router.get('/dashboard', (req, res) => {
  const totalUsers = db.select({ count: count() }).from(users).get()?.count ?? 0
  const totalServers = db.select({ count: count() }).from(servers).get()?.count ?? 0
  const runningServers = db.select({ count: count() }).from(servers).where(eq(servers.status, 'running')).get()?.count ?? 0
  const stoppedServers = db.select({ count: count() }).from(servers).where(eq(servers.status, 'stopped')).get()?.count ?? 0
  const suspendedServers = db.select({ count: count() }).from(servers).where(eq(servers.isSuspended, true)).get()?.count ?? 0
  const totalClusters = db.select({ count: count() }).from(proxmoxClusters).get()?.count ?? 0
  const totalNodes = db.select({ count: count() }).from(proxmoxNodes).get()?.count ?? 0
  const offlineNodes = db.select({ count: count() }).from(proxmoxNodes).where(eq(proxmoxNodes.status, 'offline')).get()?.count ?? 0
  const recentLogs = db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(20).all()
  return res.json({ stats: { totalUsers, totalServers, runningServers, stoppedServers, suspendedServers, totalClusters, totalNodes, offlineNodes }, recentActivity: recentLogs })
})

// ─── Users ────────────────────────────────────────────────────────────────────
router.get('/users', (req, res) => {
  const allUsers = db.select({ id: users.id, email: users.email, username: users.username, firstName: users.firstName, lastName: users.lastName, role: users.role, isActive: users.isActive, isSuspended: users.isSuspended, emailVerified: users.emailVerified, createdAt: users.createdAt, lastLoginAt: users.lastLoginAt }).from(users).orderBy(desc(users.createdAt)).all()
  return res.json(allUsers)
})
router.get('/users/:id', (req, res) => {
  const user = db.select().from(users).where(eq(users.id, req.params.id)).get()
  if (!user) return res.status(404).json({ error: 'User not found' })
  const userServers = db.select().from(servers).where(eq(servers.userId, user.id)).all()
  return res.json({ ...user, servers: userServers })
})
router.put('/users/:id/suspend', (req, res) => {
  const user = db.select().from(users).where(eq(users.id, req.params.id)).get()
  if (!user) return res.status(404).json({ error: 'User not found' })
  db.update(users).set({ isSuspended: true, updatedAt: new Date().toISOString() }).where(eq(users.id, user.id)).run()
  db.insert(activityLogs).values({ id: nanoid(), userId: user.id, actorId: req.user!.id, action: 'user.suspended', targetType: 'user', targetId: user.id, ipAddress: req.ip, createdAt: new Date().toISOString() }).run()
  return res.json({ success: true })
})
router.put('/users/:id/unsuspend', (req, res) => {
  const user = db.select().from(users).where(eq(users.id, req.params.id)).get()
  if (!user) return res.status(404).json({ error: 'User not found' })
  db.update(users).set({ isSuspended: false, updatedAt: new Date().toISOString() }).where(eq(users.id, user.id)).run()
  return res.json({ success: true })
})

// ─── Locations ────────────────────────────────────────────────────────────────
const locationSchema = z.object({ name: z.string().min(2), shortCode: z.string().min(2).max(10), country: z.string().min(2), description: z.string().optional(), isEnabled: z.boolean().optional().default(true) })
router.get('/locations', (req, res) => res.json(db.select().from(locations).all()))
router.post('/locations', (req, res) => {
  try {
    const body = locationSchema.parse(req.body)
    const id = nanoid()
    db.insert(locations).values({ id, ...body, createdAt: new Date().toISOString() }).run()
    return res.status(201).json(db.select().from(locations).where(eq(locations.id, id)).get())
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: 'Validation failed', details: err.errors })
    return res.status(500).json({ error: 'Internal server error' })
  }
})

// ─── Clusters ─────────────────────────────────────────────────────────────────
const clusterSchema = z.object({ name: z.string().min(2), hostname: z.string().min(4), port: z.number().int().min(1).max(65535).optional().default(8006), protocol: z.enum(['http', 'https']).optional().default('https'), tokenId: z.string().min(4), tokenSecret: z.string().min(4), tlsVerify: z.boolean().optional().default(true), locationId: z.string().optional() })

router.get('/clusters', (req, res) => {
  const clusters = db.select().from(proxmoxClusters).all()
  return res.json(clusters.map(c => ({ ...c, tokenSecret: '[REDACTED]' })))
})

router.post('/clusters', (req, res) => {
  try {
    const body = clusterSchema.parse(req.body)
    const id = nanoid(); const now = new Date().toISOString()
    db.insert(proxmoxClusters).values({ id, ...body, createdAt: now, updatedAt: now }).run()
    const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, id)).get()!
    return res.status(201).json({ ...cluster, tokenSecret: '[REDACTED]' })
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: 'Validation failed', details: err.errors })
    return res.status(500).json({ error: 'Internal server error' })
  }
})

router.delete('/clusters/:id', (req, res) => {
  db.update(proxmoxClusters).set({ isEnabled: false, updatedAt: new Date().toISOString() }).where(eq(proxmoxClusters.id, req.params.id)).run()
  return res.json({ success: true })
})

// Test connection
router.post('/clusters/:id/test', async (req, res) => {
  const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, req.params.id)).get()
  if (!cluster) return res.status(404).json({ error: 'Cluster not found' })
  try {
    const pve = makeProxmox(cluster)
    const version = await pve.testConnection()
    db.update(proxmoxClusters).set({ connectionStatus: 'connected', updatedAt: new Date().toISOString() }).where(eq(proxmoxClusters.id, cluster.id)).run()
    return res.json({ success: true, version })
  } catch (err: any) {
    db.update(proxmoxClusters).set({ connectionStatus: 'error', updatedAt: new Date().toISOString() }).where(eq(proxmoxClusters.id, cluster.id)).run()
    return res.status(502).json({ error: err.message || 'Connection failed' })
  }
})

// Sync cluster (async via jobs)
router.post('/clusters/:id/sync', (req, res) => {
  const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, req.params.id)).get()
  if (!cluster) return res.status(404).json({ error: 'Cluster not found' })
  const jobId = createJob({ type: 'sync_cluster', clusterId: cluster.id, userId: req.user!.id })
  return res.json({ jobId, message: 'Sync started' })
})

// ─── Nodes ────────────────────────────────────────────────────────────────────
router.get('/nodes', (req, res) => {
  return res.json(db.select().from(proxmoxNodes).all())
})

router.put('/nodes/:id', (req, res) => {
  const { isMaintenanceMode, isProvisioningEnabled } = req.body
  db.update(proxmoxNodes).set({ isMaintenanceMode, isProvisioningEnabled, updatedAt: new Date().toISOString() }).where(eq(proxmoxNodes.id, req.params.id)).run()
  return res.json(db.select().from(proxmoxNodes).where(eq(proxmoxNodes.id, req.params.id)).get())
})

// Sync single node status from Proxmox
router.post('/nodes/:id/sync', async (req, res) => {
  const node = db.select().from(proxmoxNodes).where(eq(proxmoxNodes.id, req.params.id)).get()
  if (!node) return res.status(404).json({ error: 'Node not found' })
  const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, node.clusterId)).get()
  if (!cluster) return res.status(404).json({ error: 'Cluster not found' })
  try {
    const pve = makeProxmox(cluster)
    const status = await pve.getNodeStatus(node.name)
    const now = new Date().toISOString()
    db.update(proxmoxNodes).set({
      status: 'online', cpuCores: status.cpuinfo?.cpus, cpuUsage: status.cpu,
      totalRam: status.memory?.total, usedRam: status.memory?.used,
      totalStorage: status.rootfs?.total, usedStorage: status.rootfs?.used,
      uptime: status.uptime, proxmoxVersion: status.pveversion,
      cpuModel: status.cpuinfo?.model, lastSyncAt: now, updatedAt: now,
    }).where(eq(proxmoxNodes.id, node.id)).run()
    return res.json(db.select().from(proxmoxNodes).where(eq(proxmoxNodes.id, node.id)).get())
  } catch (err: any) {
    db.update(proxmoxNodes).set({ status: 'offline', updatedAt: new Date().toISOString() }).where(eq(proxmoxNodes.id, node.id)).run()
    return res.status(502).json({ error: err.message })
  }
})

// ─── Storage Pools ────────────────────────────────────────────────────────────
router.get('/storage', (req, res) => {
  return res.json(db.select().from(storagePools).all())
})

router.post('/clusters/:id/sync-storage', async (req, res) => {
  const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, req.params.id)).get()
  if (!cluster) return res.status(404).json({ error: 'Cluster not found' })
  try {
    const pve = makeProxmox(cluster)
    const nodes = db.select().from(proxmoxNodes).where(eq(proxmoxNodes.clusterId, cluster.id)).all()
    const now = new Date().toISOString()
    let synced = 0
    for (const node of nodes) {
      try {
        const storages = await pve.getNodeStorage(node.name)
        for (const s of storages) {
          const existing = db.select().from(storagePools)
            .where(and(eq(storagePools.clusterId, cluster.id), eq(storagePools.node, node.name), eq(storagePools.storage, s.storage)))
            .get()
          const data = { clusterId: cluster.id, node: node.name, storage: s.storage, type: s.type, content: s.content, total: s.total, used: s.used, avail: s.avail, status: s.active ? 'active' : 'inactive', isActive: Boolean(s.active && s.enabled), updatedAt: now }
          if (existing) db.update(storagePools).set(data).where(eq(storagePools.id, existing.id)).run()
          else db.insert(storagePools).values({ id: nanoid(), ...data, createdAt: now }).run()
          synced++
        }
      } catch {}
    }
    return res.json({ success: true, synced })
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

// ─── Network Bridges ──────────────────────────────────────────────────────────
router.get('/bridges', (req, res) => {
  return res.json(db.select().from(networkBridges).all())
})

router.post('/clusters/:id/sync-bridges', async (req, res) => {
  const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, req.params.id)).get()
  if (!cluster) return res.status(404).json({ error: 'Cluster not found' })
  try {
    const pve = makeProxmox(cluster)
    const nodes = db.select().from(proxmoxNodes).where(eq(proxmoxNodes.clusterId, cluster.id)).all()
    const now = new Date().toISOString()
    let synced = 0
    for (const node of nodes) {
      try {
        const networks = await pve.getNodeNetwork(node.name)
        const bridges = networks.filter(n => n.type === 'bridge' || n.iface.startsWith('vmbr'))
        for (const b of bridges) {
          const existing = db.select().from(networkBridges)
            .where(and(eq(networkBridges.clusterId, cluster.id), eq(networkBridges.node, node.name), eq(networkBridges.iface, b.iface)))
            .get()
          const data = { clusterId: cluster.id, node: node.name, iface: b.iface, type: b.type, cidr: b.cidr, gateway: b.gateway, bridgePorts: b.bridge_ports, isActive: Boolean(b.active), updatedAt: now }
          if (existing) db.update(networkBridges).set(data).where(eq(networkBridges.id, existing.id)).run()
          else db.insert(networkBridges).values({ id: nanoid(), ...data, createdAt: now }).run()
          synced++
        }
      } catch {}
    }
    return res.json({ success: true, synced })
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

// ─── IP Pools ─────────────────────────────────────────────────────────────────
const ipPoolSchema = z.object({ name: z.string().min(2), clusterId: z.string().optional(), gateway: z.string().min(7), subnet: z.string().min(7), dns1: z.string().optional(), dns2: z.string().optional(), bridge: z.string().optional(), vlan: z.number().int().optional(), isIpv6: z.boolean().optional().default(false), isEnabled: z.boolean().optional().default(true) })

router.get('/ip-pools', (req, res) => res.json(db.select().from(ipPools).all()))

router.post('/ip-pools', (req, res) => {
  try {
    const body = ipPoolSchema.parse(req.body)
    const id = nanoid(); const now = new Date().toISOString()
    db.insert(ipPools).values({ id, ...body, createdAt: now, updatedAt: now }).run()
    return res.status(201).json(db.select().from(ipPools).where(eq(ipPools.id, id)).get())
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: 'Validation failed', details: err.errors })
    return res.status(500).json({ error: 'Internal server error' })
  }
})

router.get('/ip-pools/:id/addresses', (req, res) => {
  return res.json(db.select().from(ipAddresses).where(eq(ipAddresses.poolId, req.params.id)).all())
})

router.post('/ip-pools/:id/addresses', (req, res) => {
  const { addresses } = req.body
  if (!Array.isArray(addresses)) return res.status(400).json({ error: 'addresses must be an array' })
  const now = new Date().toISOString()
  let added = 0
  for (const addr of addresses) {
    try {
      db.insert(ipAddresses).values({ id: nanoid(), poolId: req.params.id, address: addr, status: 'available', createdAt: now, updatedAt: now }).run()
      added++
    } catch {}
  }
  return res.json({ added })
})

// ─── Templates ────────────────────────────────────────────────────────────────
router.get('/templates', (req, res) => res.json(db.select().from(templates).all()))

const templateSchema = z.object({
  clusterId: z.string(), node: z.string(), vmid: z.number().int().optional(),
  volid: z.string().optional(), name: z.string().min(2),
  osName: z.string().optional(), osVersion: z.string().optional(),
  virtType: z.enum(['kvm', 'lxc']), description: z.string().optional(),
  isEnabled: z.boolean().optional().default(true),
})

router.post('/templates', (req, res) => {
  try {
    const body = templateSchema.parse(req.body)
    const id = nanoid(); const now = new Date().toISOString()
    db.insert(templates).values({ id, ...body, createdAt: now, updatedAt: now }).run()
    return res.status(201).json(db.select().from(templates).where(eq(templates.id, id)).get())
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: 'Validation failed', details: err.errors })
    return res.status(500).json({ error: 'Internal server error' })
  }
})

router.put('/templates/:id', (req, res) => {
  try {
    const body = templateSchema.partial().parse(req.body)
    db.update(templates).set({ ...body, updatedAt: new Date().toISOString() }).where(eq(templates.id, req.params.id)).run()
    return res.json(db.select().from(templates).where(eq(templates.id, req.params.id)).get())
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: 'Validation failed', details: err.errors })
    return res.status(500).json({ error: 'Internal server error' })
  }
})

router.delete('/templates/:id', (req, res) => {
  db.update(templates).set({ isEnabled: false, updatedAt: new Date().toISOString() }).where(eq(templates.id, req.params.id)).run()
  return res.json({ success: true })
})

// Sync templates from Proxmox (discover VM templates & LXC templates)
router.post('/clusters/:id/sync-templates', async (req, res) => {
  const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, req.params.id)).get()
  if (!cluster) return res.status(404).json({ error: 'Cluster not found' })
  try {
    const pve = makeProxmox(cluster)
    const nodes = db.select().from(proxmoxNodes).where(eq(proxmoxNodes.clusterId, cluster.id)).all()
    const now = new Date().toISOString()
    let synced = 0
    for (const node of nodes) {
      // Scan QEMU templates
      try {
        const vms = await pve.getQemuList(node.name)
        for (const vm of vms.filter(v => v.template === 1)) {
          const existing = db.select().from(templates)
            .where(and(eq(templates.clusterId, cluster.id), eq(templates.node, node.name), eq(templates.vmid, vm.vmid)))
            .get()
          const data = { clusterId: cluster.id, node: node.name, vmid: vm.vmid, name: vm.name || `tpl-${vm.vmid}`, virtType: 'kvm' as const, updatedAt: now }
          if (!existing) { db.insert(templates).values({ id: nanoid(), ...data, isEnabled: true, createdAt: now }).run(); synced++ }
        }
      } catch {}
      // Scan LXC templates
      try {
        const ctrs = await pve.getLxcList(node.name)
        for (const ct of ctrs.filter(c => c.template === 1)) {
          const existing = db.select().from(templates)
            .where(and(eq(templates.clusterId, cluster.id), eq(templates.node, node.name), eq(templates.vmid, ct.vmid)))
            .get()
          const data = { clusterId: cluster.id, node: node.name, vmid: ct.vmid, name: ct.name || `tpl-${ct.vmid}`, virtType: 'lxc' as const, updatedAt: now }
          if (!existing) { db.insert(templates).values({ id: nanoid(), ...data, isEnabled: true, createdAt: now }).run(); synced++ }
        }
      } catch {}
      // Scan LXC template files in storage
      try {
        const storages = await pve.getNodeStorage(node.name)
        for (const st of storages) {
          if (!st.content?.includes('vztmpl')) continue
          try {
            const files = await pve.getStorageContent(node.name, st.storage, 'vztmpl')
            for (const f of files) {
              const volid = f.volid
              const existing = db.select().from(templates)
                .where(and(eq(templates.clusterId, cluster.id), eq(templates.node, node.name), eq(templates.volid, volid)))
                .get()
              if (!existing) {
                const name = volid.split('/').pop()?.replace('.tar.gz', '').replace('.tar.xz', '') || volid
                db.insert(templates).values({ id: nanoid(), clusterId: cluster.id, node: node.name, volid, name, virtType: 'lxc', isEnabled: true, createdAt: now, updatedAt: now }).run()
                synced++
              }
            }
          } catch {}
        }
      } catch {}
    }
    return res.json({ success: true, synced })
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.get('/os-library', (req, res) => {
  return res.json(OS_TEMPLATE_LIBRARY)
})

router.post('/clusters/:id/install-library-template', async (req, res) => {
  const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, req.params.id)).get()
  if (!cluster) return res.status(404).json({ error: 'Cluster not found' })

  const { node, storage, templateKey } = req.body
  if (!node || !storage || !templateKey) {
    return res.status(400).json({ error: 'node, storage, templateKey required' })
  }

  const libraryTemplate = getOSLibraryTemplate(templateKey)
  if (!libraryTemplate) return res.status(404).json({ error: 'Library template not found' })

  const targetNode = db.select().from(proxmoxNodes)
    .where(and(eq(proxmoxNodes.clusterId, cluster.id), eq(proxmoxNodes.name, node))).get()
  if (!targetNode) return res.status(404).json({ error: 'Node not found in cluster' })

  const storagePool = db.select().from(storagePools)
    .where(and(eq(storagePools.clusterId, cluster.id), eq(storagePools.node, node), eq(storagePools.storage, storage))).get()
  if (!storagePool) return res.status(404).json({ error: 'Storage pool not found on node' })

  if (libraryTemplate.virtType !== 'lxc') {
    return res.status(400).json({ error: 'Only LXC library templates are supported for automated install' })
  }

  try {
    const pve = makeProxmox(cluster)
    const upid = await pve.downloadUrlToStorage(node, storage, libraryTemplate.filename, libraryTemplate.url, libraryTemplate.content)
    const taskStatus = await pve.waitForTask(node, upid, () => {})
    if (taskStatus !== 'OK') throw new Error(`Download task failed: ${taskStatus}`)

    const now = new Date().toISOString()
    const template = {
      id: nanoid(),
      clusterId: cluster.id,
      node,
      volid: `${storage}:${libraryTemplate.filename}`,
      name: libraryTemplate.name,
      virtType: libraryTemplate.virtType,
      osName: libraryTemplate.osName,
      osVersion: libraryTemplate.osVersion,
      description: libraryTemplate.description,
      isEnabled: true,
      createdAt: now,
      updatedAt: now,
    }

    db.insert(templates).values(template).run()
    return res.status(201).json(template)
  } catch (err: any) {
    return res.status(502).json({ error: err.message || 'Template install failed' })
  }
})

// ─── Servers ──────────────────────────────────────────────────────────────────
router.get('/servers', (req, res) => res.json(db.select().from(servers).all()))

// Admin server power actions
router.post('/servers/:id/power', async (req, res) => {
  const { action } = req.body
  if (!['start', 'stop', 'restart', 'shutdown', 'reset'].includes(action)) return res.status(400).json({ error: 'Invalid action' })
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  const jobId = createJob({ type: 'power', serverId: server.id, userId: req.user!.id, action })
  return res.json({ jobId, message: `Power action "${action}" queued` })
})

// Admin suspend/unsuspend server
router.put('/servers/:id/suspend', (req, res) => {
  const { reason } = req.body
  db.update(servers).set({ isSuspended: true, suspendReason: reason, updatedAt: new Date().toISOString() }).where(eq(servers.id, req.params.id)).run()
  return res.json({ success: true })
})
router.put('/servers/:id/unsuspend', (req, res) => {
  db.update(servers).set({ isSuspended: false, suspendReason: null, updatedAt: new Date().toISOString() }).where(eq(servers.id, req.params.id)).run()
  return res.json({ success: true })
})

// ─── Jobs (Task Center) ───────────────────────────────────────────────────────
router.get('/jobs', (req, res) => {
  const limit = parseInt(req.query.limit as string) || 200
  const type = req.query.type as string | undefined
  const status = req.query.status as string | undefined
  const list = db.select().from(jobs).orderBy(desc(jobs.createdAt)).limit(limit).all()
    .filter(j => (!type || j.type === type) && (!status || j.status === status))
  return res.json(list)
})

// ─── Activity ─────────────────────────────────────────────────────────────────
router.get('/activity', (req, res) => {
  const logs = db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(100).all()
  return res.json(logs)
})

// ─── Server Ownership Transfer ────────────────────────────────────────────────
router.post('/servers/:id/transfer', (req, res) => {
  const { newUserId } = req.body
  if (!newUserId) return res.status(400).json({ error: 'newUserId required' })
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  const targetUser = db.select().from(users).where(eq(users.id, newUserId)).get()
  if (!targetUser) return res.status(404).json({ error: 'Target user not found' })
  const now = new Date().toISOString()
  db.update(servers).set({ userId: newUserId, updatedAt: now }).where(eq(servers.id, server.id)).run()
  db.insert(activityLogs).values({ id: nanoid(), userId: newUserId, actorId: req.user!.id, action: 'server.transferred', targetType: 'server', targetId: server.id, ipAddress: req.ip, metadata: JSON.stringify({ fromUserId: server.userId, toUserId: newUserId }), createdAt: now }).run()
  return res.json({ success: true })
})

// ─── Server Clone ─────────────────────────────────────────────────────────────
router.post('/servers/:id/clone', async (req, res) => {
  const { newUserId, displayName, hostname } = req.body
  if (!newUserId || !displayName || !hostname) return res.status(400).json({ error: 'newUserId, displayName, hostname required' })
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  if (!server.nodeId || !server.clusterId || !server.vmid) return res.status(400).json({ error: 'Server has no Proxmox resource' })
  const targetUser = db.select().from(users).where(eq(users.id, newUserId)).get()
  if (!targetUser) return res.status(404).json({ error: 'Target user not found' })
  const newServerId = nanoid()
  const now = new Date().toISOString()
  db.insert(servers).values({
    id: newServerId, userId: newUserId, nodeId: server.nodeId, clusterId: server.clusterId,
    locationId: server.locationId, displayName, hostname, vmid: null,
    virtType: server.virtType, status: 'provisioning', os: server.os,
    vcpuCores: server.vcpuCores, ramMb: server.ramMb, diskGb: server.diskGb,
    createdAt: now, updatedAt: now,
  }).run()
  const jobId = createJob({ type: 'clone_server', serverId: newServerId, userId: req.user!.id,
    sourceServerId: server.id, displayName, hostname } as any)
  db.insert(activityLogs).values({ id: nanoid(), userId: newUserId, actorId: req.user!.id, action: 'server.cloned', targetType: 'server', targetId: newServerId, ipAddress: req.ip, metadata: JSON.stringify({ sourceServerId: server.id }), createdAt: now }).run()
  return res.json({ serverId: newServerId, jobId })
})

// ─── Bulk Server Actions ───────────────────────────────────────────────────────
router.post('/servers/bulk', (req, res) => {
  const { serverIds, action } = req.body
  if (!Array.isArray(serverIds) || serverIds.length === 0) return res.status(400).json({ error: 'serverIds array required' })
  if (!['start', 'stop', 'shutdown', 'suspend', 'unsuspend'].includes(action)) return res.status(400).json({ error: 'Invalid action' })
  const jobIds: string[] = []
  for (const serverId of serverIds) {
    const server = db.select().from(servers).where(eq(servers.id, serverId)).get()
    if (!server) continue
    if (action === 'suspend') {
      db.update(servers).set({ isSuspended: true, updatedAt: new Date().toISOString() }).where(eq(servers.id, serverId)).run()
    } else if (action === 'unsuspend') {
      db.update(servers).set({ isSuspended: false, updatedAt: new Date().toISOString() }).where(eq(servers.id, serverId)).run()
    } else {
      const jobId = createJob({ type: 'power', serverId, userId: req.user!.id, action })
      jobIds.push(jobId)
    }
  }
  return res.json({ success: true, jobIds })
})

// ─── Server Meta (notes, tags, expiry, group) ─────────────────────────────────
router.patch('/servers/:id/meta', (req, res) => {
  const { notes, tags, expiresAt, groupId } = req.body
  const server = db.select().from(servers).where(eq(servers.id, req.params.id)).get()
  if (!server) return res.status(404).json({ error: 'Server not found' })
  const now = new Date().toISOString()
  db.update(servers).set({
    ...(notes !== undefined ? { notes } : {}),
    ...(tags !== undefined ? { tags } : {}),
    ...(expiresAt !== undefined ? { expiresAt } : {}),
    ...(groupId !== undefined ? { groupId: groupId || null } : {}),
    updatedAt: now,
  }).where(eq(servers.id, req.params.id)).run()
  return res.json(db.select().from(servers).where(eq(servers.id, req.params.id)).get())
})

// ─── Import Existing VMs ───────────────────────────────────────────────────────
router.get('/import-candidates', async (req, res) => {
  const { clusterId } = req.query as { clusterId: string }
  if (!clusterId) return res.status(400).json({ error: 'clusterId required' })
  const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, clusterId)).get()
  if (!cluster) return res.status(404).json({ error: 'Cluster not found' })
  try {
    const pve = makeProxmox(cluster)
    const resources = await pve.getClusterResources()
    const panelVmids = new Set(db.select().from(servers).where(eq(servers.clusterId, clusterId)).all().map(s => s.vmid).filter(Boolean))
    const candidates = resources
      .filter(r => (r.type === 'qemu' || r.type === 'lxc') && r.vmid && !panelVmids.has(r.vmid))
      .map(r => ({ vmid: r.vmid, name: r.name, type: r.type, node: r.node, status: r.status, cpu: r.cpu, mem: r.mem, maxmem: r.maxmem }))
    return res.json(candidates)
  } catch (err: any) {
    return res.status(502).json({ error: err.message })
  }
})

router.post('/import-server', (req, res) => {
  const { clusterId, nodeId, vmid, virtType, displayName, hostname, userId, vcpuCores, ramMb, diskGb } = req.body
  if (!clusterId || !nodeId || !vmid || !virtType || !displayName || !hostname || !userId) {
    return res.status(400).json({ error: 'Missing required fields' })
  }
  const targetUser = db.select().from(users).where(eq(users.id, userId)).get()
  if (!targetUser) return res.status(404).json({ error: 'User not found' })
  const now = new Date().toISOString()
  const id = nanoid()
  db.insert(servers).values({
    id, userId, clusterId, nodeId, vmid, virtType, displayName, hostname,
    status: 'stopped', vcpuCores: vcpuCores || 1, ramMb: ramMb || 512, diskGb: diskGb || 10,
    createdAt: now, updatedAt: now,
  }).run()
  db.insert(activityLogs).values({ id: nanoid(), userId, actorId: req.user!.id, action: 'server.imported', targetType: 'server', targetId: id, ipAddress: req.ip, metadata: JSON.stringify({ vmid, clusterId }), createdAt: now }).run()
  return res.status(201).json(db.select().from(servers).where(eq(servers.id, id)).get())
})

// ─── Server Groups ─────────────────────────────────────────────────────────────
router.get('/server-groups', (req, res) => res.json(db.select().from(serverGroups).all()))

router.post('/server-groups', (req, res) => {
  const { name, color, description } = req.body
  if (!name) return res.status(400).json({ error: 'name required' })
  const now = new Date().toISOString()
  const id = nanoid()
  db.insert(serverGroups).values({ id, name, color: color || '#6366f1', description, createdAt: now, updatedAt: now }).run()
  return res.status(201).json(db.select().from(serverGroups).where(eq(serverGroups.id, id)).get())
})

router.put('/server-groups/:id', (req, res) => {
  const { name, color, description } = req.body
  db.update(serverGroups).set({ name, color, description, updatedAt: new Date().toISOString() }).where(eq(serverGroups.id, req.params.id)).run()
  return res.json(db.select().from(serverGroups).where(eq(serverGroups.id, req.params.id)).get())
})

router.delete('/server-groups/:id', (req, res) => {
  db.update(servers).set({ groupId: null, updatedAt: new Date().toISOString() }).where(eq(servers.groupId, req.params.id)).run()
  db.delete(serverGroups).where(eq(serverGroups.id, req.params.id)).run()
  return res.json({ success: true })
})

// ─── Announcements ─────────────────────────────────────────────────────────────
router.get('/announcements', (req, res) => res.json(db.select().from(announcements).orderBy(desc(announcements.createdAt)).all()))

router.post('/announcements', (req, res) => {
  const { title, content, type, isActive, targetRole, startsAt, endsAt } = req.body
  if (!title || !content) return res.status(400).json({ error: 'title and content required' })
  const now = new Date().toISOString()
  const id = nanoid()
  db.insert(announcements).values({ id, title, content, type: type || 'info', isActive: isActive !== false, targetRole: targetRole || 'all', startsAt, endsAt, createdBy: req.user!.id, createdAt: now, updatedAt: now }).run()
  return res.status(201).json(db.select().from(announcements).where(eq(announcements.id, id)).get())
})

router.put('/announcements/:id', (req, res) => {
  const { title, content, type, isActive, targetRole, startsAt, endsAt } = req.body
  db.update(announcements).set({ title, content, type, isActive, targetRole, startsAt, endsAt, updatedAt: new Date().toISOString() }).where(eq(announcements.id, req.params.id)).run()
  return res.json(db.select().from(announcements).where(eq(announcements.id, req.params.id)).get())
})

router.delete('/announcements/:id', (req, res) => {
  db.delete(announcements).where(eq(announcements.id, req.params.id)).run()
  return res.json({ success: true })
})

// ─── Alerts ─────────────────────────────────────────────────────────────────────
router.get('/alerts', (req, res) => {
  const list = db.select().from(alerts).orderBy(desc(alerts.createdAt)).limit(100).all()
  return res.json(list)
})

router.post('/alerts/:id/resolve', (req, res) => {
  db.update(alerts).set({ isResolved: true, resolvedAt: new Date().toISOString() }).where(eq(alerts.id, req.params.id)).run()
  return res.json({ success: true })
})

// ─── IP Address Management ─────────────────────────────────────────────────────
router.put('/ip-addresses/:id', (req, res) => {
  const { status, note } = req.body
  db.update(ipAddresses).set({ ...(status ? { status } : {}), ...(note !== undefined ? { note } : {}), updatedAt: new Date().toISOString() }).where(eq(ipAddresses.id, req.params.id)).run()
  return res.json(db.select().from(ipAddresses).where(eq(ipAddresses.id, req.params.id)).get())
})

router.delete('/ip-addresses/:id', (req, res) => {
  const ip = db.select().from(ipAddresses).where(eq(ipAddresses.id, req.params.id)).get()
  if (!ip) return res.status(404).json({ error: 'Not found' })
  if (ip.serverId) return res.status(400).json({ error: 'IP is currently allocated to a server' })
  db.delete(ipAddresses).where(eq(ipAddresses.id, req.params.id)).run()
  return res.json({ success: true })
})

router.delete('/ip-pools/:id', (req, res) => {
  const allocated = db.select().from(ipAddresses).where(and(eq(ipAddresses.poolId, req.params.id), eq(ipAddresses.status, 'allocated'))).all()
  if (allocated.length > 0) return res.status(400).json({ error: `Cannot delete pool with ${allocated.length} allocated IPs` })
  db.delete(ipAddresses).where(eq(ipAddresses.poolId, req.params.id)).run()
  db.delete(ipPools).where(eq(ipPools.id, req.params.id)).run()
  return res.json({ success: true })
})

// ─── Active Announcements (public to authenticated users) ─────────────────────
router.get('/active-announcements', (req, res) => {
  const now = new Date().toISOString()
  const all = db.select().from(announcements).where(eq(announcements.isActive, true)).all()
  const active = all.filter(a => {
    if (a.startsAt && a.startsAt > now) return false
    if (a.endsAt && a.endsAt < now) return false
    return true
  })
  return res.json(active)
})

// ─── Panel Settings ───────────────────────────────────────────────────────────
const DEFAULT_SETTINGS = { panelName: 'MatrixHost', hostname: '', faviconUrl: '/favicon.ico' }

router.get('/settings', (req, res) => {
  const rows = db.select().from(panelSettings).all()
  const s: Record<string, string> = {}
  for (const row of rows) s[row.key] = row.value
  return res.json({ ...DEFAULT_SETTINGS, ...s })
})

router.put('/settings', (req, res) => {
  const { panelName, hostname, faviconUrl } = req.body
  const now = new Date().toISOString()
  const upsert = (key: string, value: string) =>
    db.insert(panelSettings).values({ key, value, updatedAt: now })
      .onConflictDoUpdate({ target: panelSettings.key, set: { value, updatedAt: now } }).run()
  if (panelName !== undefined) upsert('panelName', String(panelName))
  if (hostname !== undefined) upsert('hostname', String(hostname))
  if (faviconUrl !== undefined) upsert('faviconUrl', String(faviconUrl))
  db.insert(activityLogs).values({
    id: nanoid(), userId: req.user!.id, actorId: req.user!.id,
    action: 'admin.settings.update', targetType: 'settings', targetId: 'panel',
    ipAddress: req.ip, createdAt: now,
  }).run()
  return res.json({ success: true })
})

export default router
