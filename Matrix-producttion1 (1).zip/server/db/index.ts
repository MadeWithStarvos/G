import Database from 'better-sqlite3'
import { drizzle } from 'drizzle-orm/better-sqlite3'
import bcrypt from 'bcryptjs'
import { nanoid } from 'nanoid'
import * as schema from './schema.js'

const sqlite = new Database('matrixhost.db')
sqlite.exec(`PRAGMA journal_mode = WAL;`)
sqlite.exec(`PRAGMA foreign_keys = ON;`)

export const db = drizzle(sqlite, { schema })

export async function seedAdmin() {
  const existing = sqlite.prepare('SELECT id FROM users WHERE email = ?').get('admin@matrixhost.in')
  if (existing) return
  const passwordHash = await bcrypt.hash('iconicggs1234', 12)
  const now = new Date().toISOString()
  sqlite.prepare(`
    INSERT INTO users (id,email,username,password_hash,first_name,last_name,role,is_active,is_suspended,email_verified,two_factor_enabled,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,1,0,1,0,?,?)
  `).run(nanoid(), 'admin@matrixhost.in', 'admin', passwordHash, 'Admin', 'MatrixHost', 'superadmin', now, now)
  console.log('✓ Admin account seeded: admin@matrixhost.in')
}

export function initDb() {
  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL, first_name TEXT, last_name TEXT,
      role TEXT NOT NULL DEFAULT 'customer', is_active INTEGER NOT NULL DEFAULT 1,
      is_suspended INTEGER NOT NULL DEFAULT 0, email_verified INTEGER NOT NULL DEFAULT 0,
      two_factor_enabled INTEGER NOT NULL DEFAULT 0, two_factor_secret TEXT,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
      last_login_at TEXT, last_login_ip TEXT
    );
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
      token TEXT NOT NULL UNIQUE, ip_address TEXT, user_agent TEXT,
      expires_at TEXT NOT NULL, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS api_tokens (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
      name TEXT NOT NULL, token_hash TEXT NOT NULL UNIQUE,
      last_used_at TEXT, expires_at TEXT, is_active INTEGER NOT NULL DEFAULT 1,
      scopes TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS locations (
      id TEXT PRIMARY KEY, name TEXT NOT NULL, short_code TEXT NOT NULL UNIQUE,
      country TEXT NOT NULL, description TEXT, is_enabled INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS proxmox_clusters (
      id TEXT PRIMARY KEY, name TEXT NOT NULL, hostname TEXT NOT NULL,
      port INTEGER NOT NULL DEFAULT 8006, token_id TEXT NOT NULL, token_secret TEXT NOT NULL,
      tls_verify INTEGER NOT NULL DEFAULT 1, location_id TEXT REFERENCES locations(id),
      is_enabled INTEGER NOT NULL DEFAULT 1,
      connection_status TEXT NOT NULL DEFAULT 'unknown',
      last_sync_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS proxmox_nodes (
      id TEXT PRIMARY KEY, cluster_id TEXT NOT NULL REFERENCES proxmox_clusters(id),
      name TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'unknown',
      cpu_model TEXT, cpu_cores INTEGER, cpu_usage REAL,
      total_ram INTEGER, used_ram INTEGER, total_storage INTEGER, used_storage INTEGER,
      uptime INTEGER, proxmox_version TEXT, guest_count INTEGER NOT NULL DEFAULT 0,
      is_maintenance_mode INTEGER NOT NULL DEFAULT 0,
      is_provisioning_enabled INTEGER NOT NULL DEFAULT 1,
      last_sync_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS server_groups (
      id TEXT PRIMARY KEY, name TEXT NOT NULL,
      color TEXT NOT NULL DEFAULT '#6366f1',
      description TEXT,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS servers (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
      node_id TEXT REFERENCES proxmox_nodes(id),
      cluster_id TEXT REFERENCES proxmox_clusters(id),
      location_id TEXT REFERENCES locations(id),
      group_id TEXT REFERENCES server_groups(id),
      display_name TEXT NOT NULL, hostname TEXT NOT NULL, vmid INTEGER,
      virt_type TEXT NOT NULL DEFAULT 'kvm',
      status TEXT NOT NULL DEFAULT 'provisioning', os TEXT,
      vcpu_cores INTEGER NOT NULL, ram_mb INTEGER NOT NULL, disk_gb INTEGER NOT NULL,
      primary_ipv4 TEXT, primary_ipv6 TEXT,
      is_suspended INTEGER NOT NULL DEFAULT 0, suspend_reason TEXT,
      notes TEXT, tags TEXT, expires_at TEXT,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL, deleted_at TEXT
    );
    CREATE TABLE IF NOT EXISTS jobs (
      id TEXT PRIMARY KEY, type TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      server_id TEXT REFERENCES servers(id),
      cluster_id TEXT REFERENCES proxmox_clusters(id),
      user_id TEXT REFERENCES users(id),
      node TEXT, vmid INTEGER, upid TEXT,
      progress INTEGER NOT NULL DEFAULT 0,
      message TEXT, error TEXT, input TEXT, output TEXT,
      created_at TEXT NOT NULL, started_at TEXT, completed_at TEXT
    );
    CREATE TABLE IF NOT EXISTS templates (
      id TEXT PRIMARY KEY,
      cluster_id TEXT NOT NULL REFERENCES proxmox_clusters(id),
      node TEXT NOT NULL, vmid INTEGER, volid TEXT,
      name TEXT NOT NULL, os_name TEXT, os_version TEXT,
      virt_type TEXT NOT NULL DEFAULT 'kvm',
      description TEXT, is_enabled INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS storage_pools (
      id TEXT PRIMARY KEY,
      cluster_id TEXT NOT NULL REFERENCES proxmox_clusters(id),
      node TEXT NOT NULL, storage TEXT NOT NULL, type TEXT,
      content TEXT, total INTEGER, used INTEGER, avail INTEGER,
      status TEXT NOT NULL DEFAULT 'active',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS network_bridges (
      id TEXT PRIMARY KEY,
      cluster_id TEXT NOT NULL REFERENCES proxmox_clusters(id),
      node TEXT NOT NULL, iface TEXT NOT NULL, type TEXT,
      cidr TEXT, gateway TEXT, bridge_ports TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS ip_pools (
      id TEXT PRIMARY KEY, name TEXT NOT NULL,
      cluster_id TEXT REFERENCES proxmox_clusters(id),
      gateway TEXT NOT NULL, subnet TEXT NOT NULL,
      dns1 TEXT, dns2 TEXT, bridge TEXT, vlan INTEGER,
      is_ipv6 INTEGER NOT NULL DEFAULT 0, is_enabled INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS ip_addresses (
      id TEXT PRIMARY KEY, pool_id TEXT NOT NULL REFERENCES ip_pools(id),
      address TEXT NOT NULL UNIQUE,
      status TEXT NOT NULL DEFAULT 'available',
      server_id TEXT REFERENCES servers(id),
      note TEXT,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS snapshots (
      id TEXT PRIMARY KEY, server_id TEXT NOT NULL REFERENCES servers(id),
      name TEXT NOT NULL, description TEXT, proxmox_name TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'available',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS vmid_reservations (
      id TEXT PRIMARY KEY,
      cluster_id TEXT NOT NULL,
      vmid INTEGER NOT NULL,
      server_id TEXT,
      status TEXT NOT NULL DEFAULT 'reserved',
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(cluster_id, vmid, status)
    );
    CREATE TABLE IF NOT EXISTS backups (
      id TEXT PRIMARY KEY,
      server_id TEXT NOT NULL REFERENCES servers(id),
      name TEXT NOT NULL,
      node TEXT NOT NULL,
      storage TEXT NOT NULL,
      volid TEXT,
      size INTEGER,
      backup_type TEXT NOT NULL DEFAULT 'stop',
      status TEXT NOT NULL DEFAULT 'creating',
      proxmox_upid TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS webhooks (
      id TEXT PRIMARY KEY,
      url TEXT NOT NULL,
      events TEXT NOT NULL,
      secret TEXT,
      is_enabled INTEGER NOT NULL DEFAULT 1,
      last_delivery TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS server_timers (
      id TEXT PRIMARY KEY,
      server_id TEXT NOT NULL REFERENCES servers(id),
      user_id TEXT REFERENCES users(id),
      action TEXT NOT NULL,
      trigger_at TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS panel_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS activity_logs (
      id TEXT PRIMARY KEY, user_id TEXT REFERENCES users(id),
      actor_id TEXT REFERENCES users(id), action TEXT NOT NULL,
      target_type TEXT, target_id TEXT, ip_address TEXT,
      metadata TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
      title TEXT NOT NULL, message TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'info', is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS announcements (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'info',
      is_active INTEGER NOT NULL DEFAULT 1,
      target_role TEXT NOT NULL DEFAULT 'all',
      starts_at TEXT,
      ends_at TEXT,
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS alerts (
      id TEXT PRIMARY KEY,
      node_id TEXT REFERENCES proxmox_nodes(id),
      cluster_id TEXT REFERENCES proxmox_clusters(id),
      type TEXT NOT NULL,
      severity TEXT NOT NULL DEFAULT 'warning',
      message TEXT NOT NULL,
      is_resolved INTEGER NOT NULL DEFAULT 0,
      resolved_at TEXT,
      created_at TEXT NOT NULL
    );
  `)

  const alterCols = [
    `ALTER TABLE servers ADD COLUMN group_id TEXT`,
    `ALTER TABLE servers ADD COLUMN notes TEXT`,
    `ALTER TABLE servers ADD COLUMN tags TEXT`,
    `ALTER TABLE servers ADD COLUMN expires_at TEXT`,
    `ALTER TABLE ip_addresses ADD COLUMN note TEXT`,
  ]
  for (const sql of alterCols) {
    try { sqlite.exec(sql) } catch {}
  }
}

export { schema }
