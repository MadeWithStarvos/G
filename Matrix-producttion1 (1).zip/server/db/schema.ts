import { sqliteTable, text, integer, real, uniqueIndex } from 'drizzle-orm/sqlite-core'

export const users = sqliteTable('users', {
  id: text('id').primaryKey(),
  email: text('email').notNull().unique(),
  username: text('username').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  firstName: text('first_name'),
  lastName: text('last_name'),
  role: text('role', { enum: ['superadmin', 'admin', 'support', 'customer'] }).notNull().default('customer'),
  isActive: integer('is_active', { mode: 'boolean' }).notNull().default(true),
  isSuspended: integer('is_suspended', { mode: 'boolean' }).notNull().default(false),
  emailVerified: integer('email_verified', { mode: 'boolean' }).notNull().default(false),
  twoFactorEnabled: integer('two_factor_enabled', { mode: 'boolean' }).notNull().default(false),
  twoFactorSecret: text('two_factor_secret'),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
  lastLoginAt: text('last_login_at'),
  lastLoginIp: text('last_login_ip'),
})

export const sessions = sqliteTable('sessions', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id),
  token: text('token').notNull().unique(),
  ipAddress: text('ip_address'),
  userAgent: text('user_agent'),
  expiresAt: text('expires_at').notNull(),
  createdAt: text('created_at').notNull(),
})

export const apiTokens = sqliteTable('api_tokens', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id),
  name: text('name').notNull(),
  tokenHash: text('token_hash').notNull().unique(),
  lastUsedAt: text('last_used_at'),
  expiresAt: text('expires_at'),
  isActive: integer('is_active', { mode: 'boolean' }).notNull().default(true),
  scopes: text('scopes').notNull().default('[]'),
  createdAt: text('created_at').notNull(),
})

export const locations = sqliteTable('locations', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  shortCode: text('short_code').notNull().unique(),
  country: text('country').notNull(),
  description: text('description'),
  isEnabled: integer('is_enabled', { mode: 'boolean' }).notNull().default(true),
  createdAt: text('created_at').notNull(),
})

export const proxmoxClusters = sqliteTable('proxmox_clusters', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  hostname: text('hostname').notNull(),
  port: integer('port').notNull().default(8006),
  protocol: text('protocol', { enum: ['http', 'https'] }).notNull().default('https'),
  tokenId: text('token_id').notNull(),
  tokenSecret: text('token_secret').notNull(),
  tlsVerify: integer('tls_verify', { mode: 'boolean' }).notNull().default(true),
  locationId: text('location_id').references(() => locations.id),
  isEnabled: integer('is_enabled', { mode: 'boolean' }).notNull().default(true),
  connectionStatus: text('connection_status').notNull().default('unknown'),
  lastSyncAt: text('last_sync_at'),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
})

export const proxmoxNodes = sqliteTable('proxmox_nodes', {
  id: text('id').primaryKey(),
  clusterId: text('cluster_id').notNull().references(() => proxmoxClusters.id),
  name: text('name').notNull(),
  status: text('status').notNull().default('unknown'),
  cpuModel: text('cpu_model'),
  cpuCores: integer('cpu_cores'),
  cpuUsage: real('cpu_usage'),
  totalRam: integer('total_ram'),
  usedRam: integer('used_ram'),
  totalStorage: integer('total_storage'),
  usedStorage: integer('used_storage'),
  uptime: integer('uptime'),
  proxmoxVersion: text('proxmox_version'),
  guestCount: integer('guest_count').notNull().default(0),
  isMaintenanceMode: integer('is_maintenance_mode', { mode: 'boolean' }).notNull().default(false),
  isProvisioningEnabled: integer('is_provisioning_enabled', { mode: 'boolean' }).notNull().default(true),
  lastSyncAt: text('last_sync_at'),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
})

export const serverGroups = sqliteTable('server_groups', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  color: text('color').notNull().default('#6366f1'),
  description: text('description'),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
})

export const servers = sqliteTable('servers', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id),
  nodeId: text('node_id').references(() => proxmoxNodes.id),
  clusterId: text('cluster_id').references(() => proxmoxClusters.id),
  locationId: text('location_id').references(() => locations.id),
  groupId: text('group_id').references(() => serverGroups.id),
  displayName: text('display_name').notNull(),
  hostname: text('hostname').notNull(),
  vmid: integer('vmid'),
  virtType: text('virt_type', { enum: ['kvm', 'lxc'] }).notNull().default('kvm'),
  status: text('status', { enum: ['provisioning', 'running', 'stopped', 'suspended', 'failed', 'terminating', 'terminated'] }).notNull().default('provisioning'),
  os: text('os'),
  vcpuCores: integer('vcpu_cores').notNull(),
  ramMb: integer('ram_mb').notNull(),
  diskGb: integer('disk_gb').notNull(),
  primaryIpv4: text('primary_ipv4'),
  primaryIpv6: text('primary_ipv6'),
  isSuspended: integer('is_suspended', { mode: 'boolean' }).notNull().default(false),
  suspendReason: text('suspend_reason'),
  notes: text('notes'),
  tags: text('tags'),
  expiresAt: text('expires_at'),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
  deletedAt: text('deleted_at'),
})

export const jobs = sqliteTable('jobs', {
  id: text('id').primaryKey(),
  type: text('type').notNull(),
  status: text('status', { enum: ['pending', 'running', 'completed', 'failed'] }).notNull().default('pending'),
  serverId: text('server_id').references(() => servers.id),
  clusterId: text('cluster_id').references(() => proxmoxClusters.id),
  userId: text('user_id').references(() => users.id),
  node: text('node'),
  vmid: integer('vmid'),
  upid: text('upid'),
  progress: integer('progress').notNull().default(0),
  message: text('message'),
  error: text('error'),
  input: text('input'),
  output: text('output'),
  createdAt: text('created_at').notNull(),
  startedAt: text('started_at'),
  completedAt: text('completed_at'),
})

export const templates = sqliteTable('templates', {
  id: text('id').primaryKey(),
  clusterId: text('cluster_id').notNull().references(() => proxmoxClusters.id),
  node: text('node').notNull(),
  vmid: integer('vmid'),
  volid: text('volid'),
  name: text('name').notNull(),
  osName: text('os_name'),
  osVersion: text('os_version'),
  virtType: text('virt_type', { enum: ['kvm', 'lxc'] }).notNull().default('kvm'),
  description: text('description'),
  isEnabled: integer('is_enabled', { mode: 'boolean' }).notNull().default(true),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
})

export const storagePools = sqliteTable('storage_pools', {
  id: text('id').primaryKey(),
  clusterId: text('cluster_id').notNull().references(() => proxmoxClusters.id),
  node: text('node').notNull(),
  storage: text('storage').notNull(),
  type: text('type'),
  content: text('content'),
  total: integer('total'),
  used: integer('used'),
  avail: integer('avail'),
  status: text('status').notNull().default('active'),
  isActive: integer('is_active', { mode: 'boolean' }).notNull().default(true),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
})

export const networkBridges = sqliteTable('network_bridges', {
  id: text('id').primaryKey(),
  clusterId: text('cluster_id').notNull().references(() => proxmoxClusters.id),
  node: text('node').notNull(),
  iface: text('iface').notNull(),
  type: text('type'),
  cidr: text('cidr'),
  gateway: text('gateway'),
  bridgePorts: text('bridge_ports'),
  isActive: integer('is_active', { mode: 'boolean' }).notNull().default(true),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
})

export const ipPools = sqliteTable('ip_pools', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  clusterId: text('cluster_id').references(() => proxmoxClusters.id),
  gateway: text('gateway').notNull(),
  subnet: text('subnet').notNull(),
  dns1: text('dns1'),
  dns2: text('dns2'),
  bridge: text('bridge'),
  vlan: integer('vlan'),
  isIpv6: integer('is_ipv6', { mode: 'boolean' }).notNull().default(false),
  isEnabled: integer('is_enabled', { mode: 'boolean' }).notNull().default(true),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
})

export const ipAddresses = sqliteTable('ip_addresses', {
  id: text('id').primaryKey(),
  poolId: text('pool_id').notNull().references(() => ipPools.id),
  address: text('address').notNull().unique(),
  status: text('status', { enum: ['available', 'reserved', 'allocated', 'disabled'] }).notNull().default('available'),
  serverId: text('server_id').references(() => servers.id),
  note: text('note'),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
})

export const snapshots = sqliteTable('snapshots', {
  id: text('id').primaryKey(),
  serverId: text('server_id').notNull().references(() => servers.id),
  name: text('name').notNull(),
  description: text('description'),
  proxmoxName: text('proxmox_name').notNull(),
  status: text('status', { enum: ['creating', 'available', 'deleting', 'failed'] }).notNull().default('available'),
  createdAt: text('created_at').notNull(),
})

export const vmidReservations = sqliteTable('vmid_reservations', {
  id: text('id').primaryKey(),
  clusterId: text('cluster_id').notNull(),
  vmid: integer('vmid').notNull(),
  serverId: text('server_id'),
  status: text('status', { enum: ['reserved', 'confirmed', 'released'] }).notNull().default('reserved'),
  expiresAt: text('expires_at').notNull(),
  createdAt: text('created_at').notNull(),
})

export const backups = sqliteTable('backups', {
  id: text('id').primaryKey(),
  serverId: text('server_id').notNull().references(() => servers.id),
  name: text('name').notNull(),
  node: text('node').notNull(),
  storage: text('storage').notNull(),
  volid: text('volid'),
  size: integer('size'),
  backupType: text('backup_type').notNull().default('stop'),
  status: text('status', { enum: ['creating', 'available', 'restoring', 'deleting', 'failed'] }).notNull().default('creating'),
  proxmoxUpid: text('proxmox_upid'),
  createdAt: text('created_at').notNull(),
})

export const webhooks = sqliteTable('webhooks', {
  id: text('id').primaryKey(),
  url: text('url').notNull(),
  events: text('events').notNull(),
  secret: text('secret'),
  isEnabled: integer('is_enabled', { mode: 'boolean' }).notNull().default(true),
  lastDelivery: text('last_delivery'),
  createdAt: text('created_at').notNull(),
})

export const serverTimers = sqliteTable('server_timers', {
  id: text('id').primaryKey(),
  serverId: text('server_id').notNull().references(() => servers.id),
  userId: text('user_id').references(() => users.id),
  action: text('action').notNull(),
  triggerAt: text('trigger_at').notNull(),
  status: text('status', { enum: ['pending', 'executed', 'cancelled', 'failed'] }).notNull().default('pending'),
  createdAt: text('created_at').notNull().default(new Date().toISOString()),
})

export const panelSettings = sqliteTable('panel_settings', {
  key: text('key').primaryKey(),
  value: text('value').notNull(),
  updatedAt: text('updated_at').notNull().default(new Date().toISOString()),
})

export const activityLogs = sqliteTable('activity_logs', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => users.id),
  actorId: text('actor_id').references(() => users.id),
  action: text('action').notNull(),
  targetType: text('target_type'),
  targetId: text('target_id'),
  ipAddress: text('ip_address'),
  metadata: text('metadata'),
  createdAt: text('created_at').notNull().default(new Date().toISOString()),
})

export const notifications = sqliteTable('notifications', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id),
  title: text('title').notNull(),
  message: text('message').notNull(),
  type: text('type', { enum: ['info', 'success', 'warning', 'error'] }).notNull().default('info'),
  isRead: integer('is_read', { mode: 'boolean' }).notNull().default(false),
  createdAt: text('created_at').notNull().default(new Date().toISOString()),
})

export const announcements = sqliteTable('announcements', {
  id: text('id').primaryKey(),
  title: text('title').notNull(),
  content: text('content').notNull(),
  type: text('type', { enum: ['info', 'success', 'warning', 'error'] }).notNull().default('info'),
  isActive: integer('is_active', { mode: 'boolean' }).notNull().default(true),
  targetRole: text('target_role').notNull().default('all'),
  startsAt: text('starts_at'),
  endsAt: text('ends_at'),
  createdBy: text('created_by').references(() => users.id),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
})

export const alerts = sqliteTable('alerts', {
  id: text('id').primaryKey(),
  nodeId: text('node_id').references(() => proxmoxNodes.id),
  clusterId: text('cluster_id').references(() => proxmoxClusters.id),
  type: text('type').notNull(),
  severity: text('severity', { enum: ['info', 'warning', 'critical'] }).notNull().default('warning'),
  message: text('message').notNull(),
  isResolved: integer('is_resolved', { mode: 'boolean' }).notNull().default(false),
  resolvedAt: text('resolved_at'),
  createdAt: text('created_at').notNull(),
})
