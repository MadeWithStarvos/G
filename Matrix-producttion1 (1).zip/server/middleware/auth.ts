import type { Request, Response, NextFunction } from 'express'
import jwt from 'jsonwebtoken'
import { db } from '../db/index.js'
import { users, sessions } from '../db/schema.js'
import { eq } from 'drizzle-orm'

const JWT_SECRET = process.env.JWT_SECRET || 'matrixhost-dev-secret-change-in-production'

export interface AuthUser {
  id: string
  email: string
  username: string
  role: string
  firstName: string | null
  lastName: string | null
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser
      sessionId?: string
    }
  }
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const token = extractToken(req)
  if (!token) {
    return res.status(401).json({ error: 'Authentication required' })
  }

  try {
    const payload = jwt.verify(token, JWT_SECRET) as { userId: string; sessionId: string }
    const session = db.select().from(sessions).where(eq(sessions.token, token)).get()

    if (!session || new Date(session.expiresAt) < new Date()) {
      return res.status(401).json({ error: 'Session expired or invalid' })
    }

    const user = db.select().from(users).where(eq(users.id, payload.userId)).get()

    if (!user || !user.isActive || user.isSuspended) {
      return res.status(401).json({ error: 'Account inactive or suspended' })
    }

    req.user = {
      id: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
      firstName: user.firstName,
      lastName: user.lastName,
    }
    req.sessionId = session.id
    next()
  } catch {
    return res.status(401).json({ error: 'Invalid token' })
  }
}

export function requireRole(...roles: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' })
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions' })
    }
    next()
  }
}

function extractToken(req: Request): string | null {
  const auth = req.headers.authorization
  if (auth?.startsWith('Bearer ')) {
    return auth.slice(7)
  }
  const cookieToken = req.cookies?.token
  if (cookieToken) return cookieToken
  return null
}

export function signToken(userId: string, sessionId: string): string {
  return jwt.sign({ userId, sessionId }, JWT_SECRET, { expiresIn: '7d' })
}

export { JWT_SECRET }
