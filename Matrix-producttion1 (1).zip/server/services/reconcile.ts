import { db } from '../db/index.js'
import { servers, proxmoxClusters, proxmoxNodes, activityLogs } from '../db/schema.js'
import { eq, and, notInArray } from 'drizzle-orm'
import { makeProxmox } from './proxmox.js'
import { nanoid } from 'nanoid'

const MISMATCH_STATUSES = ['running', 'stopped', 'provisioning', 'failed']

export async function reconcileAll() {
  const activeServers = db.select().from(servers)
    .where(notInArray(servers.status, ['terminated', 'terminating']))
    .all()
    .filter(s => s.clusterId && s.nodeId && s.vmid)

  if (!activeServers.length) return

  const clusters = db.select().from(proxmoxClusters).all()
  const nodes = db.select().from(proxmoxNodes).all()

  for (const server of activeServers) {
    try {
      const cluster = clusters.find(c => c.id === server.clusterId)
      const node = nodes.find(n => n.id === server.nodeId)
      if (!cluster || !node) continue

      const pve = makeProxmox(cluster)
      const type = (server.virtType === 'lxc' ? 'lxc' : 'qemu') as 'qemu' | 'lxc'

      let actualStatus: string | null = null
      try {
        const vmStatus = await pve.getVMStatus(node.name, server.vmid!, type)
        actualStatus = vmStatus.status
      } catch (e: any) {
        if (e.message?.includes('does not exist') || e.message?.includes('500') || e.message?.includes('not found')) {
          // VM doesn't exist on Proxmox
          if (!['provisioning', 'terminating', 'terminated'].includes(server.status)) {
            const now = new Date().toISOString()
            db.update(servers).set({
              status: 'failed' as any,
              updatedAt: now,
            }).where(eq(servers.id, server.id)).run()
            db.insert(activityLogs).values({
              id: nanoid(),
              userId: server.userId,
              actorId: null,
              action: 'server.reconcile.mismatch',
              targetType: 'server',
              targetId: server.id,
              metadata: JSON.stringify({ reason: 'VM not found on Proxmox', vmid: server.vmid, node: node.name }),
              createdAt: now,
            }).run()
            console.warn(`[reconcile] VMID ${server.vmid} on ${node.name} not found — server ${server.id} flagged`)
          }
          continue
        }
        continue
      }

      const normalizedStatus = actualStatus === 'running' ? 'running' : 'stopped'
      if (normalizedStatus !== server.status && MISMATCH_STATUSES.includes(server.status)) {
        db.update(servers).set({
          status: normalizedStatus as any,
          updatedAt: new Date().toISOString(),
        }).where(eq(servers.id, server.id)).run()
        console.log(`[reconcile] ${server.id}: ${server.status} → ${normalizedStatus}`)
      }
    } catch (err: any) {
      console.error(`[reconcile] server ${server.id}:`, err.message)
    }
  }
}

export function startReconciler(intervalMs = 5 * 60 * 1000) {
  console.log(`[reconcile] Starting — interval ${intervalMs / 1000}s`)
  setInterval(() => {
    reconcileAll().catch(e => console.error('[reconcile] error:', e.message))
  }, intervalMs)
}
