export interface OsLibraryTemplate {
  key: string
  name: string
  description: string
  virtType: 'kvm' | 'lxc'
  osName: string
  osVersion: string
  url: string
  filename: string
  content: 'vztmpl' | 'iso' | 'backup' | string
}

export const OS_TEMPLATE_LIBRARY: OsLibraryTemplate[] = [
  {
    key: 'ubuntu-2404-lxc',
    name: 'Ubuntu 24.04 LXC',
    description: 'Ubuntu 24.04 LTS container template for LXC deployments.',
    virtType: 'lxc',
    osName: 'Ubuntu',
    osVersion: '24.04 LTS',
    url: 'https://images.linuxcontainers.org/images/ubuntu/jammy/amd64/default/20240516_07:42/rootfs.tar.xz',
    filename: 'ubuntu-24.04-standard_24.04-1_amd64.tar.xz',
    content: 'vztmpl',
  },
  {
    key: 'debian-12-lxc',
    name: 'Debian 12 LXC',
    description: 'Debian 12 container template imported from the public LXC image server.',
    virtType: 'lxc',
    osName: 'Debian',
    osVersion: '12',
    url: 'https://images.linuxcontainers.org/images/debian/12/amd64/default/20240409_10:39/rootfs.tar.xz',
    filename: 'debian-12-standard_12.0-1_amd64.tar.xz',
    content: 'vztmpl',
  },
  {
    key: 'alpine-3.19-lxc',
    name: 'Alpine 3.19 LXC',
    description: 'Alpine Linux 3.19 container template for lightweight instances.',
    virtType: 'lxc',
    osName: 'Alpine',
    osVersion: '3.19',
    url: 'https://images.linuxcontainers.org/images/alpine/3.19/amd64/default/20240205_15:57/rootfs.tar.xz',
    filename: 'alpine-3.19-standard_3.19-1_amd64.tar.xz',
    content: 'vztmpl',
  },
]

export function getOSLibraryTemplate(key: string) {
  return OS_TEMPLATE_LIBRARY.find((item) => item.key === key)
}
