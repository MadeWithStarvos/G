import { db } from '../db/index.js'
import {
  jobs, servers, proxmoxClusters, proxmoxNodes,
  ipAddresses, vmidReservations, backups, snapshots,
  networkBridges,
} from '../db/schema.js'
import { eq, and } from 'drizzle-orm'
import { nanoid } from 'nanoid'
import { makeProxmox } from './proxmox.js'
import { fireWebhook } from './webhooks.js'

export type JobType =
  | 'provision' | 'power' | 'delete' | 'snapshot' | 'snapshot_delete'
  | 'snapshot_rollback' | 'sync_cluster' | 'reinstall' | 'resize'
  | 'backup' | 'backup_delete' | 'backup_restore' | 'migrate'

export interface JobInput {
  type: JobType
  serverId?: string
  clusterId?: string
  userId?: string
  node?: string
  vmid?: number
  virtType?: 'qemu' | 'lxc'
  action?: string
  params?: Record<string, unknown>
}

export function createJob(input: JobInput): string {
  const id = nanoid()
  const now = new Date().toISOString()
  db.insert(jobs).values({
    id,
    type: input.type,
    status: 'pending',
    serverId: input.serverId,
    clusterId: input.clusterId,
    userId: input.userId,
    node: input.node,
    vmid: input.vmid,
    upid: null,
    progress: 0,
    message: 'Queued',
    error: null,
    input: JSON.stringify(input),
    output: null,
    createdAt: now,
    startedAt: null,
    completedAt: null,
  }).run()
  processJob(id).catch(console.error)
  return id
}

export function getJob(id: string) {
  return db.select().from(jobs).where(eq(jobs.id, id)).get()
}

function updateJob(id: string, update: Partial<typeof jobs.$inferInsert>) {
  db.update(jobs).set(update).where(eq(jobs.id, id)).run()
}

async function processJob(jobId: string) {
  const job = getJob(jobId)
  if (!job) return

  updateJob(jobId, { status: 'running', startedAt: new Date().toISOString(), message: 'Starting…' })

  try {
    const input: JobInput = JSON.parse(job.input || '{}')

    switch (input.type) {
      case 'power':          await runPowerJob(jobId, input); break
      case 'sync_cluster':   await runSyncJob(jobId, input); break
      case 'provision':      await runProvisionJob(jobId, input); break
      case 'snapshot':       await runSnapshotJob(jobId, input); break
      case 'snapshot_delete':await runSnapshotDeleteJob(jobId, input); break
      case 'snapshot_rollback': await runSnapshotRollbackJob(jobId, input); break
      case 'delete':         await runDeleteJob(jobId, input); break
      case 'backup':         await runBackupJob(jobId, input); break
      case 'backup_delete':  await runBackupDeleteJob(jobId, input); break
      case 'backup_restore': await runBackupRestoreJob(jobId, input); break
      case 'migrate':        await runMigrateJob(jobId, input); break
      case 'reinstall':      await runReinstallJob(jobId, input); break
      case 'resize':         await runResizeJob(jobId, input); break
      default:
        throw new Error(`Unknown job type: ${(input as any).type}`)
    }

    updateJob(jobId, { status: 'completed', progress: 100, completedAt: new Date().toISOString(), message: 'Completed' })
  } catch (err: any) {
    updateJob(jobId, {
      status: 'failed',
      error: err.message || 'Unknown error',
      completedAt: new Date().toISOString(),
      message: `Failed: ${err.message}`,
    })
    const job2 = getJob(jobId)
    if (job2?.serverId) {
      const input: JobInput = JSON.parse(job2.input || '{}')
      if (input.type === 'provision') {
        db.update(servers).set({ status: 'failed', updatedAt: new Date().toISOString() })
          .where(eq(servers.id, job2.serverId)).run()
        fireWebhook('server.failed', { serverId: job2.serverId }).catch(() => {})
      }
    }
  }
}

async function getClusterForServer(serverId: string) {
  const server = db.select().from(servers).where(eq(servers.id, serverId)).get()
  if (!server) throw new Error('Server not found')
  if (!server.clusterId) throw new Error('Server has no cluster assigned')
  const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, server.clusterId)).get()
  if (!cluster) throw new Error('Cluster not found')
  const node = server.nodeId ? db.select().from(proxmoxNodes).where(eq(proxmoxNodes.id, server.nodeId)).get() : null
  return { server, cluster, nodeName: node?.name }
}

function releaseVmid(clusterId: string, vmid: number) {
  try {
    db.update(vmidReservations).set({ status: 'released' })
      .where(and(eq(vmidReservations.clusterId, clusterId), eq(vmidReservations.vmid, vmid), eq(vmidReservations.status, 'reserved')))
      .run()
  } catch {}
}

function releaseIp(ipId?: string) {
  if (!ipId) return
  try {
    db.update(ipAddresses).set({ status: 'available', serverId: null, updatedAt: new Date().toISOString() })
      .where(eq(ipAddresses.id, ipId)).run()
  } catch {}
}

async function detectRootDisk(pve: ProxmoxService, nodeName: string, vmid: number, type: 'qemu' | 'lxc'): Promise<string> {
  if (type === 'lxc') return 'rootfs'
  try {
    const cfg = await pve.getVMConfig(nodeName, vmid, 'qemu')
    if (typeof cfg.bootdisk === 'string' && cfg.bootdisk.trim()) {
      return cfg.bootdisk.trim()
    }
    if (typeof cfg.boot === 'string' && cfg.boot.trim()) {
      for (const part of cfg.boot.split(/;|,/).map(p => p.trim()).filter(Boolean)) {
        if (part.startsWith('order=')) {
          const order = part.substring('order='.length)
          const first = order.split(',').map(x => x.trim()).find(Boolean)
          if (first && /^(scsi|sata|virtio|ide|efidisk)\d+$/.test(first)) return first
        }
        if (/^(scsi|sata|virtio|ide|efidisk)\d+$/.test(part)) return part
      }
    }
    const diskKey = Object.keys(cfg).find(k => /^(scsi|sata|virtio|ide|efidisk)\d+$/.test(k))
    return diskKey ?? 'scsi0'
  } catch {
    return 'scsi0'
  }
}

// ─── Power ────────────────────────────────────────────────────────────────────
async function runPowerJob(jobId: string, input: JobInput) {
  if (!input.serverId || !input.action) throw new Error('Missing serverId or action')
  const { server, cluster, nodeName } = await getClusterForServer(input.serverId)
  if (!nodeName) throw new Error('Server has no node assigned')
  if (!server.vmid) throw new Error('Server has no VMID assigned')

  const pve = makeProxmox(cluster)
  const type = (server.virtType === 'lxc' ? 'lxc' : 'qemu') as 'qemu' | 'lxc'

  updateJob(jobId, { message: `Sending ${input.action} to Proxmox…`, upid: null })

  let upid: string
  switch (input.action) {
    case 'start':    upid = await pve.startVM(nodeName, server.vmid, type); break
    case 'stop':     upid = await pve.stopVM(nodeName, server.vmid, type); break
    case 'shutdown': upid = await pve.shutdownVM(nodeName, server.vmid, type); break
    case 'reboot':
    case 'restart':  upid = await pve.rebootVM(nodeName, server.vmid, type); break
    case 'reset':    upid = await pve.resetVM(nodeName, server.vmid); break
    default: throw new Error(`Unknown power action: ${input.action}`)
  }

  updateJob(jobId, { upid, message: 'Task submitted, waiting for completion…', progress: 30 })
  const exitStatus = await pve.waitForTask(nodeName, upid, (msg) => updateJob(jobId, { message: msg, progress: 60 }))
  if (exitStatus !== 'OK') throw new Error(`Power action failed: ${exitStatus}`)

  const newStatus = input.action === 'start' ? 'running'
    : ['stop', 'shutdown', 'reset'].includes(input.action) ? 'stopped'
    : server.status

  db.update(servers).set({ status: newStatus as any, updatedAt: new Date().toISOString() })
    .where(eq(servers.id, server.id)).run()

  try {
    const vmStatus = await pve.getVMStatus(nodeName, server.vmid, type)
    db.update(servers).set({ status: vmStatus.status as any, updatedAt: new Date().toISOString() })
      .where(eq(servers.id, server.id)).run()
  } catch {}
}

// ─── Sync cluster ─────────────────────────────────────────────────────────────
async function runSyncJob(jobId: string, input: JobInput) {
  if (!input.clusterId) throw new Error('Missing clusterId')
  const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, input.clusterId)).get()
  if (!cluster) throw new Error('Cluster not found')

  const pve = makeProxmox(cluster)
  updateJob(jobId, { message: 'Connecting to Proxmox…', progress: 10 })

  const version = await pve.testConnection()
  updateJob(jobId, { message: `Connected: PVE ${version.version}`, progress: 20 })

  const nodes = await pve.getNodes()
  updateJob(jobId, { message: `Found ${nodes.length} node(s)`, progress: 40 })

  const now = new Date().toISOString()
  for (const n of nodes) {
    let nodeStatus: Awaited<ReturnType<typeof pve.getNodeStatus>> | null = null
    try { nodeStatus = await pve.getNodeStatus(n.node) } catch {}

    const existing = db.select().from(proxmoxNodes)
      .where(eq(proxmoxNodes.clusterId, cluster.id)).all()
      .find(x => x.name === n.node)

    const nodeData = {
      clusterId: cluster.id,
      name: n.node,
      status: (n.status === 'online' ? 'online' : 'offline') as 'online' | 'offline' | 'unknown',
      cpuCores: nodeStatus?.cpuinfo?.cpus ?? n.maxcpu,
      cpuUsage: n.cpu,
      totalRam: nodeStatus?.memory?.total ?? n.maxmem,
      usedRam: nodeStatus?.memory?.used ?? n.mem,
      totalStorage: n.maxdisk,
      usedStorage: n.disk,
      uptime: n.uptime,
      proxmoxVersion: nodeStatus?.pveversion ?? version.version,
      cpuModel: nodeStatus?.cpuinfo?.model ?? null,
      lastSyncAt: now,
      updatedAt: now,
    }

    if (existing) {
      db.update(proxmoxNodes).set(nodeData).where(eq(proxmoxNodes.id, existing.id)).run()
    } else {
      db.insert(proxmoxNodes).values({ id: nanoid(), ...nodeData, createdAt: now }).run()
    }
  }

  db.update(proxmoxClusters).set({
    connectionStatus: 'connected', lastSyncAt: now, updatedAt: now,
  }).where(eq(proxmoxClusters.id, cluster.id)).run()

  updateJob(jobId, { message: `Synced ${nodes.length} node(s)`, progress: 90 })
}

// ─── Provision ────────────────────────────────────────────────────────────────
async function runProvisionJob(jobId: string, input: JobInput) {
  const params = (input.params || {}) as Record<string, any>
  if (!input.serverId) throw new Error('Missing serverId')

  const server = db.select().from(servers).where(eq(servers.id, input.serverId)).get()
  if (!server) throw new Error('Server not found')
  if (!server.clusterId || !server.nodeId || !server.vmid) throw new Error('Server missing cluster/node/vmid')

  const cluster = db.select().from(proxmoxClusters).where(eq(proxmoxClusters.id, server.clusterId)).get()
  if (!cluster) throw new Error('Cluster not found')
  const node = db.select().from(proxmoxNodes).where(eq(proxmoxNodes.id, server.nodeId)).get()
  if (!node) throw new Error('Node not found')

  const pve = makeProxmox(cluster)
  const type = server.virtType === 'lxc' ? 'lxc' : 'qemu'
  const subnetPrefix = params.subnetPrefix || '24'

  let cloneCompleted = false

  try {
    updateJob(jobId, { progress: 10, message: 'Verifying VMID availability…' })
    // Double-check VMID not in use on Proxmox before cloning
    const vmAlreadyExists = await pve.vmExists(node.name, server.vmid, type as 'qemu' | 'lxc')
    if (vmAlreadyExists) throw new Error(`VMID ${server.vmid} already exists on ${node.name}`)

    updateJob(jobId, { progress: 15, message: 'Cloning template…' })

    let upid: string
    if (type === 'qemu') {
      if (!params.templateVmid) throw new Error('templateVmid required for KVM provisioning')
      upid = await pve.cloneVM(node.name, Number(params.templateVmid), server.vmid, {
        name: server.hostname, full: true, storage: params.storage,
      })
    } else {
      if (!params.templateVmid) throw new Error('templateVmid required for LXC provisioning')
      upid = await pve.cloneLXC(node.name, Number(params.templateVmid), server.vmid, {
        hostname: server.hostname, storage: params.storage,
      })
    }

    updateJob(jobId, { upid, progress: 20, message: 'Waiting for clone…' })
    const cloneExit = await pve.waitForTask(node.name, upid, (m) => updateJob(jobId, { message: m }))
    if (cloneExit !== 'OK') throw new Error(`Clone failed: ${cloneExit}`)
    cloneCompleted = true

    updateJob(jobId, { progress: 50, message: 'Applying resources and Cloud-Init…' })

    if (type === 'qemu') {
      const vmCfg: Record<string, unknown> = {
        cores: server.vcpuCores,
        memory: server.ramMb,
        onboot: 0,
      }
      if (params.ipv4 && params.gateway) {
        vmCfg.ipconfig0 = `ip=${params.ipv4}/${subnetPrefix},gw=${params.gateway}`
      } else {
        vmCfg.ipconfig0 = 'ip=dhcp'
      }
      if (params.nameserver) vmCfg.nameserver = params.nameserver
      if (server.hostname) vmCfg.searchdomain = server.hostname
      if (params.password) vmCfg.cipassword = params.password
      if (params.username) vmCfg.ciuser = params.username
      if (params.sshKeys?.trim()) vmCfg.sshkeys = params.sshKeys.trim()
      await pve.configureVM(node.name, server.vmid, vmCfg)
    } else {
      // LXC configuration
      const lxcCfg: Record<string, unknown> = {
        cores: server.vcpuCores,
        memory: server.ramMb,
        hostname: server.hostname,
        onboot: 0,
      }
      if (params.ipv4 && params.gateway) {
        lxcCfg.net0 = `name=eth0,bridge=${params.bridge || 'vmbr0'},ip=${params.ipv4}/${subnetPrefix},gw=${params.gateway}`
      } else {
        lxcCfg.net0 = `name=eth0,bridge=${params.bridge || 'vmbr0'},ip=dhcp`
      }
      if (params.nameserver) lxcCfg.nameserver = params.nameserver
      if (params.password) lxcCfg.password = params.password
      if (params.username) lxcCfg.ciuser = params.username
      if (params.sshKeys?.trim()) lxcCfg.sshkeys = params.sshKeys.trim()
      await pve.configureLXC(node.name, server.vmid, lxcCfg)
    }

    updateJob(jobId, { progress: 70, message: 'Resizing disk…' })
    try {
      const disk = await detectRootDisk(pve, node.name, server.vmid, type as 'qemu' | 'lxc')
      await pve.resizeDisk(node.name, server.vmid, type as 'qemu' | 'lxc', disk, `${server.diskGb}G`)
    } catch (e: any) {
      console.warn('[provision] Disk resize warning:', e.message)
    }

    updateJob(jobId, { progress: 85, message: 'Starting VM…' })
    const startUpid = await pve.startVM(node.name, server.vmid, type as 'qemu' | 'lxc')
    const startExit = await pve.waitForTask(node.name, startUpid, (m) => updateJob(jobId, { message: m }))
    if (startExit !== 'OK') throw new Error(`Start failed: ${startExit}`)

    // Allocate IP now that Proxmox succeeded
    if (params.allocatedIpId) {
      db.update(ipAddresses).set({ status: 'allocated', serverId: server.id, updatedAt: new Date().toISOString() })
        .where(eq(ipAddresses.id, params.allocatedIpId)).run()
    }

    // Confirm VMID reservation
    if (server.clusterId && server.vmid) {
      db.update(vmidReservations).set({ status: 'confirmed' })
        .where(and(eq(vmidReservations.clusterId, server.clusterId), eq(vmidReservations.vmid, server.vmid)))
        .run()
    }

    db.update(servers).set({ status: 'running', updatedAt: new Date().toISOString() })
      .where(eq(servers.id, server.id)).run()

    updateJob(jobId, { progress: 95, message: 'Provisioning complete' })
    fireWebhook('server.provisioned', { serverId: server.id, vmid: server.vmid, ip: params.ipv4 }).catch(() => {})

  } catch (err: any) {
    // ── Rollback ─────────────────────────────────────────────────────────────
    if (cloneCompleted && server.vmid) {
      try {
        updateJob(jobId, { message: 'Rolling back — deleting partial VM…' })
        const delUpid = await pve.deleteVM(node.name, server.vmid, type as 'qemu' | 'lxc', true)
        if (delUpid) await pve.waitForTask(node.name, delUpid, () => {}).catch(() => {})
      } catch (cleanErr: any) {
        console.error('[provision rollback] delete failed:', cleanErr.message)
      }
    }

    // Release IP reservation
    if (params.allocatedIpId) {
      releaseIp(params.allocatedIpId)
    }

    // Release VMID reservation
    if (server.clusterId && server.vmid) {
      releaseVmid(server.clusterId, server.vmid)
    }

    throw err
  }
}

// ─── Snapshot ─────────────────────────────────────────────────────────────────
async function runSnapshotJob(jobId: string, input: JobInput) {
  if (!input.serverId) throw new Error('Missing serverId')
  const { server, cluster, nodeName } = await getClusterForServer(input.serverId)
  if (!nodeName || !server.vmid) throw new Error('Server has no node/vmid')
  const params = (input.params || {}) as Record<string, any>

  const pve = makeProxmox(cluster)
  const type = server.virtType === 'lxc' ? 'lxc' : 'qemu'
  const upid = await pve.createSnapshot(nodeName, server.vmid, type as 'qemu' | 'lxc', params.snapname, params.description)
  updateJob(jobId, { upid, message: 'Waiting for snapshot…', progress: 30 })
  const exit = await pve.waitForTask(nodeName, upid, (m) => updateJob(jobId, { message: m }))
  if (exit !== 'OK') throw new Error(`Snapshot failed: ${exit}`)
  db.update(snapshots).set({ status: 'available' })
    .where(and(eq(snapshots.serverId, server.id), eq(snapshots.proxmoxName, params.snapname))).run()
}

async function runSnapshotDeleteJob(jobId: string, input: JobInput) {
  if (!input.serverId) throw new Error('Missing serverId')
  const { server, cluster, nodeName } = await getClusterForServer(input.serverId)
  if (!nodeName || !server.vmid) throw new Error('Server has no node/vmid')
  const params = (input.params || {}) as Record<string, any>

  const pve = makeProxmox(cluster)
  const type = server.virtType === 'lxc' ? 'lxc' : 'qemu'
  const upid = await pve.deleteSnapshot(nodeName, server.vmid, type as 'qemu' | 'lxc', params.snapname)
  if (upid) await pve.waitForTask(nodeName, upid, (m) => updateJob(jobId, { message: m }))
  db.update(snapshots).set({ status: 'deleting' })
    .where(and(eq(snapshots.serverId, server.id), eq(snapshots.proxmoxName, params.snapname))).run()
}

async function runSnapshotRollbackJob(jobId: string, input: JobInput) {
  if (!input.serverId) throw new Error('Missing serverId')
  const { server, cluster, nodeName } = await getClusterForServer(input.serverId)
  if (!nodeName || !server.vmid) throw new Error('Server has no node/vmid')
  const params = (input.params || {}) as Record<string, any>

  const pve = makeProxmox(cluster)
  const type = server.virtType === 'lxc' ? 'lxc' : 'qemu'
  const upid = await pve.rollbackSnapshot(nodeName, server.vmid, type as 'qemu' | 'lxc', params.snapname)
  if (upid) await pve.waitForTask(nodeName, upid, (m) => updateJob(jobId, { message: m }))
  db.update(servers).set({ status: 'stopped', updatedAt: new Date().toISOString() })
    .where(eq(servers.id, server.id)).run()
}

// ─── Delete ───────────────────────────────────────────────────────────────────
async function runDeleteJob(jobId: string, input: JobInput) {
  if (!input.serverId) throw new Error('Missing serverId')
  const { server, cluster, nodeName } = await getClusterForServer(input.serverId)
  if (!nodeName || !server.vmid) throw new Error('Server has no node/vmid')

  const pve = makeProxmox(cluster)
  const type = server.virtType === 'lxc' ? 'lxc' : 'qemu'

  updateJob(jobId, { message: 'Stopping VM before deletion…', progress: 10 })
  try {
    const stopUpid = await pve.stopVM(nodeName, server.vmid, type as 'qemu' | 'lxc')
    await pve.waitForTask(nodeName, stopUpid, () => {})
  } catch {}

  updateJob(jobId, { message: 'Deleting VM…', progress: 40 })
  const upid = await pve.deleteVM(nodeName, server.vmid, type as 'qemu' | 'lxc')
  if (upid) {
    updateJob(jobId, { upid, progress: 60, message: 'Waiting for deletion…' })
    await pve.waitForTask(nodeName, upid, (m) => updateJob(jobId, { message: m }))
  }

  // Release IP addresses
  db.update(ipAddresses).set({ status: 'available', serverId: null, updatedAt: new Date().toISOString() })
    .where(eq(ipAddresses.serverId, server.id)).run()

  // Release VMID reservation
  if (server.clusterId && server.vmid) {
    releaseVmid(server.clusterId, server.vmid)
  }

  const now = new Date().toISOString()
  db.update(servers).set({ status: 'terminated', deletedAt: now, updatedAt: now })
    .where(eq(servers.id, server.id)).run()

  fireWebhook('server.terminated', { serverId: server.id }).catch(() => {})
}

// ─── Backup ───────────────────────────────────────────────────────────────────
async function runBackupJob(jobId: string, input: JobInput) {
  if (!input.serverId) throw new Error('Missing serverId')
  const { server, cluster, nodeName } = await getClusterForServer(input.serverId)
  if (!nodeName || !server.vmid) throw new Error('Server has no node/vmid')
  const params = (input.params || {}) as Record<string, any>
  const storage = params.storage || 'local'

  const pve = makeProxmox(cluster)
  updateJob(jobId, { progress: 10, message: 'Starting backup…' })

  const upid = await pve.createBackup(nodeName, server.vmid, storage, {
    mode: params.mode || 'stop',
    compress: 'zstd',
    notes: params.notes,
  })
  updateJob(jobId, { upid, progress: 20, message: 'Backup running…' })

  const exit = await pve.waitForTask(nodeName, upid, (m) => updateJob(jobId, { message: m, progress: 60 }), 3600)
  if (exit !== 'OK') throw new Error(`Backup failed: ${exit}`)

  // Try to find the volid in storage
  let volid: string | undefined
  let size: number | undefined
  try {
    const contents = await pve.listBackups(nodeName, storage, server.vmid)
    const latest = contents.sort((a, b) => (b.ctime || 0) - (a.ctime || 0))[0]
    volid = latest?.volid
    size = latest?.size
  } catch {}

  // Update backup record
  if (input.params?.backupId) {
    db.update(backups).set({
      status: 'available',
      volid: volid ?? null,
      size: size ?? null,
      proxmoxUpid: upid,
    }).where(eq(backups.id, String(input.params.backupId))).run()
  }

  fireWebhook('backup.created', { serverId: server.id, volid }).catch(() => {})
}

async function runBackupDeleteJob(jobId: string, input: JobInput) {
  if (!input.serverId) throw new Error('Missing serverId')
  const { server, cluster, nodeName } = await getClusterForServer(input.serverId)
  if (!nodeName) throw new Error('Server has no node assigned')
  const params = (input.params || {}) as Record<string, any>

  const pve = makeProxmox(cluster)
  updateJob(jobId, { progress: 10, message: 'Deleting backup…' })

  const upid = await pve.deleteBackup(nodeName, params.storage, params.volid)
  if (upid) {
    updateJob(jobId, { upid, progress: 30, message: 'Waiting for deletion…' })
    await pve.waitForTask(nodeName, upid, (m) => updateJob(jobId, { message: m }))
  }

  if (params.backupId) {
    db.update(backups).set({ status: 'deleting' }).where(eq(backups.id, String(params.backupId))).run()
  }
}

async function runBackupRestoreJob(jobId: string, input: JobInput) {
  if (!input.serverId) throw new Error('Missing serverId')
  const { server, cluster, nodeName } = await getClusterForServer(input.serverId)
  if (!nodeName || !server.vmid) throw new Error('Server has no node/vmid')
  const params = (input.params || {}) as Record<string, any>

  const pve = makeProxmox(cluster)
  const type = server.virtType === 'lxc' ? 'lxc' : 'qemu'

  updateJob(jobId, { progress: 10, message: 'Stopping VM before restore…' })
  try {
    const stopUpid = await pve.stopVM(nodeName, server.vmid, type as 'qemu' | 'lxc')
    await pve.waitForTask(nodeName, stopUpid, () => {}).catch(() => {})
  } catch {}

  updateJob(jobId, { progress: 20, message: 'Restoring backup…' })
  const upid = await pve.restoreBackup(nodeName, server.vmid, type as 'qemu' | 'lxc', params.storage, params.volid, {
    hostname: server.hostname, force: true,
  })
  updateJob(jobId, { upid, progress: 40, message: 'Waiting for restore…' })
  const exit = await pve.waitForTask(nodeName, upid, (m) => updateJob(jobId, { message: m, progress: 70 }), 3600)
  if (exit !== 'OK') throw new Error(`Restore failed: ${exit}`)

  // Start VM after restore
  updateJob(jobId, { progress: 85, message: 'Starting VM after restore…' })
  try {
    const startUpid = await pve.startVM(nodeName, server.vmid, type as 'qemu' | 'lxc')
    await pve.waitForTask(nodeName, startUpid, () => {})
    db.update(servers).set({ status: 'running', updatedAt: new Date().toISOString() })
      .where(eq(servers.id, server.id)).run()
  } catch (e: any) {
    console.warn('[restore] Start after restore failed:', e.message)
  }
}

// ─── Migrate ──────────────────────────────────────────────────────────────────
async function runMigrateJob(jobId: string, input: JobInput) {
  if (!input.serverId) throw new Error('Missing serverId')
  const { server, cluster, nodeName } = await getClusterForServer(input.serverId)
  if (!nodeName || !server.vmid) throw new Error('Server has no node/vmid')
  const params = (input.params || {}) as Record<string, any>
  if (!params.targetNode) throw new Error('targetNode required for migration')

  const targetNode = db.select().from(proxmoxNodes)
    .where(and(eq(proxmoxNodes.clusterId, server.clusterId!), eq(proxmoxNodes.name, params.targetNode)))
    .get()
  if (!targetNode) throw new Error('Target node not found in cluster')
  if (targetNode.status !== 'online') throw new Error('Target node is offline')

  const pve = makeProxmox(cluster)
  const type = server.virtType === 'lxc' ? 'lxc' : 'qemu'

  updateJob(jobId, { progress: 10, message: `Validating migration target ${params.targetNode}…` })

  const vmCfg = await pve.getVMConfig(nodeName, server.vmid, type)

  if (params.targetStorage) {
    const targetStorageList = await pve.getNodeStorage(params.targetNode)
    const storageItem = targetStorageList.find(s => s.storage === params.targetStorage)
    if (!storageItem) throw new Error(`Target storage "${params.targetStorage}" is not available on ${params.targetNode}`)
    if (storageItem.enabled === 0 || storageItem.status !== 'active') throw new Error(`Target storage "${params.targetStorage}" is not active on ${params.targetNode}`)
    if (typeof storageItem.avail === 'number' && storageItem.avail < server.diskGb * 1024 * 1024 * 1024) {
      throw new Error(`Not enough space on storage "${params.targetStorage}" on ${params.targetNode}`)
    }
  }

  const bridgeMatches = Object.keys(vmCfg)
    .filter(k => /^net\d+$/.test(k))
    .flatMap(k => {
      const value = String(vmCfg[k] ?? '')
      const match = value.match(/bridge=([^,]+)/)
      return match ? [match[1]] : []
    })
  for (const bridge of bridgeMatches) {
    const bridgeExists = db.select().from(networkBridges)
      .where(and(eq(networkBridges.node, params.targetNode), eq(networkBridges.iface, bridge)))
      .get()
    if (!bridgeExists) throw new Error(`Required bridge "${bridge}" is not configured on target node ${params.targetNode}`)
  }

  const freeRam = (targetNode.totalRam ?? 0) - (targetNode.usedRam ?? 0)
  if (freeRam < server.ramMb * 1024 * 1024) {
    throw new Error(`Target node ${params.targetNode} does not have enough free RAM`)
  }

  updateJob(jobId, { progress: 25, message: 'Migration starting…' })

  const upid = await pve.migrateVM(nodeName, server.vmid, type as 'qemu' | 'lxc', params.targetNode, {
    online: server.status === 'running',
    targetstorage: params.targetStorage,
  })
  updateJob(jobId, { upid, progress: 35, message: 'Migration in progress…' })

  const exit = await pve.waitForTask(nodeName, upid, (m) => updateJob(jobId, { message: m }), 1800)
  if (exit !== 'OK') throw new Error(`Migration failed: ${exit}`)

  db.update(servers).set({ nodeId: targetNode.id, updatedAt: new Date().toISOString() })
    .where(eq(servers.id, server.id)).run()

  updateJob(jobId, { progress: 95, message: `Migration complete to ${params.targetNode}` })
}

// ─── Reinstall ────────────────────────────────────────────────────────────────
async function runReinstallJob(jobId: string, input: JobInput) {
  if (!input.serverId) throw new Error('Missing serverId')
  const { server, cluster, nodeName } = await getClusterForServer(input.serverId)
  if (!nodeName || !server.vmid) throw new Error('Server has no node/vmid')
  const params = (input.params || {}) as Record<string, any>
  if (!params.templateVmid) throw new Error('templateVmid required for reinstall')

  const pve = makeProxmox(cluster)
  const type = server.virtType === 'lxc' ? 'lxc' : 'qemu'
  const subnetPrefix = params.subnetPrefix || '24'

  updateJob(jobId, { progress: 5, message: 'Stopping VM for reinstall…' })
  try {
    const stopUpid = await pve.stopVM(nodeName, server.vmid, type as 'qemu' | 'lxc')
    await pve.waitForTask(nodeName, stopUpid, () => {}).catch(() => {})
  } catch {}

  const templateVmid = Number(params.templateVmid)
  if (!templateVmid || Number.isNaN(templateVmid)) throw new Error('Invalid templateVmid for reinstall')

  updateJob(jobId, { progress: 15, message: 'Validating reinstall template…' })
  const templateExists = await pve.vmExists(nodeName, templateVmid, type)
  if (!templateExists) throw new Error(`Template ${templateVmid} not found on ${nodeName}`)

  const targetStorage = params.storage || 'local'
  const nodeStorage = await pve.getNodeStorage(nodeName)
  const storageItem = nodeStorage.find(s => s.storage === targetStorage)
  if (!storageItem) throw new Error(`Storage "${targetStorage}" is not available on ${nodeName}`)
  if (storageItem.enabled === 0 || storageItem.status !== 'active') {
    throw new Error(`Storage "${targetStorage}" is not active on ${nodeName}`)
  }
  if (typeof storageItem.avail === 'number' && storageItem.avail < server.diskGb * 1024 * 1024 * 1024) {
    throw new Error(`Not enough free space on storage "${targetStorage}" for reinstall`)
  }

  let tempVmid = await pve.getNextVMID()
  while (await pve.vmExists(nodeName, tempVmid, type)) {
    tempVmid = await pve.getNextVMID()
  }

  if (!reserveVmid(cluster.id, tempVmid, server.id)) {
    throw new Error('Unable to reserve temporary VMID for reinstall')
  }

  const tempName = `reinstall-${server.hostname}-${tempVmid}`
  let tempVmCreated = false

  updateJob(jobId, { progress: 30, message: 'Cloning template for reinstall…' })
  let upid: string
  try {
    if (type === 'qemu') {
      upid = await pve.cloneVM(nodeName, templateVmid, tempVmid, {
        name: tempName, full: true, storage: targetStorage,
      })
    } else {
      upid = await pve.cloneLXC(nodeName, templateVmid, tempVmid, {
        hostname: tempName, storage: targetStorage,
      })
    }

    tempVmCreated = true
  } catch (err: any) {
    releaseVmid(cluster.id, tempVmid)
    throw err
  }

  updateJob(jobId, { upid, progress: 40, message: 'Waiting for clone…' })
  const cloneExit = await pve.waitForTask(nodeName, upid, (m) => updateJob(jobId, { message: m }))
  if (cloneExit !== 'OK') {
    if (tempVmCreated) {
      try {
        const delUpid = await pve.deleteVM(nodeName, tempVmid, type as 'qemu' | 'lxc', true)
        if (delUpid) await pve.waitForTask(nodeName, delUpid, () => {}).catch(() => {})
      } catch (cleanupError) {
        console.warn('[reinstall cleanup] failed to remove temp VM:', cleanupError)
      }
    }
    releaseVmid(cluster.id, tempVmid)
    throw new Error(`Clone failed: ${cloneExit}`)
  }

  updateJob(jobId, { progress: 55, message: 'Applying configuration to replacement VM…' })
  if (type === 'qemu') {
    const vmCfg: Record<string, unknown> = {
      cores: server.vcpuCores, memory: server.ramMb, onboot: 0,
    }
    if (server.primaryIpv4 && params.gateway) {
      vmCfg.ipconfig0 = `ip=${server.primaryIpv4}/${subnetPrefix},gw=${params.gateway}`
    } else {
      vmCfg.ipconfig0 = 'ip=dhcp'
    }
    if (params.password) vmCfg.cipassword = params.password
    if (params.username) vmCfg.ciuser = params.username
    if (params.sshKeys?.trim()) vmCfg.sshkeys = params.sshKeys.trim()
    if (params.nameserver) vmCfg.nameserver = params.nameserver
    await pve.configureVM(nodeName, tempVmid, vmCfg)
  } else {
    const lxcCfg: Record<string, unknown> = {
      cores: server.vcpuCores, memory: server.ramMb, hostname: tempName, onboot: 0,
    }
    if (server.primaryIpv4 && params.gateway) {
      lxcCfg.net0 = `name=eth0,bridge=${params.bridge || 'vmbr0'},ip=${server.primaryIpv4}/${subnetPrefix},gw=${params.gateway}`
    }
    if (params.password) lxcCfg.password = params.password
    if (params.username) lxcCfg.ciuser = params.username
    if (params.sshKeys?.trim()) lxcCfg.sshkeys = params.sshKeys.trim()
    if (params.nameserver) lxcCfg.nameserver = params.nameserver
    await pve.configureLXC(nodeName, tempVmid, lxcCfg)
  }

  updateJob(jobId, { progress: 70, message: 'Replacing existing VM…' })
  try {
    const stopUpid = await pve.stopVM(nodeName, server.vmid, type as 'qemu' | 'lxc')
    await pve.waitForTask(nodeName, stopUpid, () => {}).catch(() => {})
  } catch {}

  try {
    const delUpid = await pve.deleteVM(nodeName, server.vmid, type as 'qemu' | 'lxc', true)
    if (delUpid) await pve.waitForTask(nodeName, delUpid, () => {})
  } catch (e: any) {
    console.warn('[reinstall] delete warning:', e.message)
  }

  if (type === 'qemu') {
    await pve.configureVM(nodeName, tempVmid, { name: server.hostname })
  } else {
    await pve.configureLXC(nodeName, tempVmid, { hostname: server.hostname })
  }

  updateJob(jobId, { progress: 80, message: 'Resizing replacement disk…' })
  try {
    const disk = await detectRootDisk(pve, nodeName, tempVmid, type as 'qemu' | 'lxc')
    await pve.resizeDisk(nodeName, tempVmid, type as 'qemu' | 'lxc', disk, `${server.diskGb}G`)
  } catch (e: any) {
    console.warn('[reinstall] resize warning:', e.message)
  }

  updateJob(jobId, { progress: 85, message: 'Starting replacement VM…' })
  const startUpid = await pve.startVM(nodeName, tempVmid, type as 'qemu' | 'lxc')
  const startExit = await pve.waitForTask(nodeName, startUpid, (m) => updateJob(jobId, { message: m }))
  if (startExit !== 'OK') throw new Error(`Start after reinstall failed: ${startExit}`)

  db.update(servers).set({ vmid: tempVmid, status: 'running', updatedAt: new Date().toISOString() })
    .where(eq(servers.id, server.id)).run()

  releaseVmid(cluster.id, server.vmid)
  db.update(vmidReservations).set({ status: 'confirmed' })
    .where(and(eq(vmidReservations.clusterId, cluster.id), eq(vmidReservations.vmid, tempVmid))).run()

  updateJob(jobId, { progress: 95, message: 'Reinstall complete' })
}

// ─── Resize ───────────────────────────────────────────────────────────────────
async function runResizeJob(jobId: string, input: JobInput) {
  if (!input.serverId) throw new Error('Missing serverId')
  const { server, cluster, nodeName } = await getClusterForServer(input.serverId)
  if (!nodeName || !server.vmid) throw new Error('Server has no node/vmid')
  const params = (input.params || {}) as Record<string, any>

  const pve = makeProxmox(cluster)
  const type = server.virtType === 'lxc' ? 'lxc' : 'qemu'

  const updates: Record<string, unknown> = {}
  const dbUpdates: Partial<typeof servers.$inferInsert> = {}

  if (params.vcpuCores) {
    updates.cores = Number(params.vcpuCores)
    dbUpdates.vcpuCores = Number(params.vcpuCores)
  }
  if (params.ramMb) {
    updates.memory = Number(params.ramMb)
    dbUpdates.ramMb = Number(params.ramMb)
  }

  if (Object.keys(updates).length > 0) {
    updateJob(jobId, { progress: 20, message: 'Applying CPU/RAM changes…' })
    await pve.resizeConfig(nodeName, server.vmid, type as 'qemu' | 'lxc', {
      cores: updates.cores as number | undefined,
      memory: updates.memory as number | undefined,
    })
  }

  if (params.diskGb) {
    const newDiskGb = Number(params.diskGb)
    if (newDiskGb <= server.diskGb) throw new Error('Disk can only be expanded, not shrunk')
    updateJob(jobId, { progress: 50, message: `Expanding disk to ${newDiskGb}GB…` })
    const disk = await detectRootDisk(pve, nodeName, server.vmid, type as 'qemu' | 'lxc')
    await pve.resizeDisk(nodeName, server.vmid, type as 'qemu' | 'lxc', disk, `${newDiskGb}G`)
    dbUpdates.diskGb = newDiskGb
  }

  dbUpdates.updatedAt = new Date().toISOString()
  db.update(servers).set(dbUpdates).where(eq(servers.id, server.id)).run()

  const needsRestart = Boolean(params.vcpuCores || params.ramMb) && server.status === 'running'
  updateJob(jobId, { progress: 90, message: needsRestart ? 'Resize complete — restart required' : 'Resize complete' })
}
