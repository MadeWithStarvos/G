import https from 'https'
import http from 'http'

export interface ProxmoxConfig {
  hostname: string
  port: number
  protocol: 'https' | 'http'
  tokenId: string
  tokenSecret: string
  tlsVerify: boolean
}

export class ProxmoxService {
  constructor(private cfg: ProxmoxConfig) {}

  private request<T>(method: string, path: string, body?: Record<string, unknown>): Promise<T> {
    return new Promise((resolve, reject) => {
      const bodyStr = body && Object.keys(body).length > 0
        ? Object.entries(body)
            .filter(([, v]) => v !== undefined && v !== null)
            .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`)
            .join('&')
        : undefined

      const options: https.RequestOptions = {
        hostname: this.cfg.hostname,
        port: this.cfg.port,
        path: `/api2/json${path}`,
        method,
        headers: {
          Authorization: `PVEAPIToken=${this.cfg.tokenId}=${this.cfg.tokenSecret}`,
          Accept: 'application/json',
          ...(bodyStr ? {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength(bodyStr),
          } : {}),
        },
        rejectUnauthorized: this.cfg.tlsVerify,
      }

      const mod = this.cfg.protocol === 'http' ? http : https
      const req = (mod as typeof https).request(options, (res) => {
        let data = ''
        res.on('data', c => { data += c })
        res.on('end', () => {
          try {
            const parsed = JSON.parse(data)
            if (res.statusCode && res.statusCode >= 400) {
              const msg = parsed?.errors ? JSON.stringify(parsed.errors) : (parsed?.message || data)
              reject(new Error(`Proxmox ${res.statusCode}: ${msg}`))
              return
            }
            resolve(parsed.data as T)
          } catch {
            reject(new Error(`Parse error: ${data.slice(0, 200)}`))
          }
        })
      })
      req.on('error', reject)
      req.setTimeout(15000, () => { req.destroy(); reject(new Error('Request timed out')) })
      if (bodyStr) req.write(bodyStr)
      req.end()
    })
  }

  async testConnection() {
    return this.request<{ version: string; release: string; repoid: string }>('GET', '/version')
  }

  async getNodes() {
    return this.request<Array<{
      node: string; status: string; cpu: number; maxcpu: number
      mem: number; maxmem: number; disk: number; maxdisk: number; uptime: number
    }>>('GET', '/nodes')
  }

  async getNodeStatus(node: string) {
    return this.request<{
      cpuinfo: { cpus: number; model: string; cores: number; sockets: number }
      memory: { used: number; total: number; free: number }
      swap: { used: number; total: number; free: number }
      rootfs: { used: number; total: number; avail: number }
      uptime: number; cpu: number; pveversion: string
      loadavg: string[]
    }>('GET', `/nodes/${node}/status`)
  }

  async getNodeStorage(node: string) {
    return this.request<Array<{
      storage: string; type: string; status: string; active: number; enabled: number
      total: number; used: number; avail: number; content: string; shared: number
    }>>('GET', `/nodes/${node}/storage`)
  }

  async getNodeNetwork(node: string) {
    return this.request<Array<{
      iface: string; type: string; active: number; method?: string
      bridge_ports?: string; cidr?: string; gateway?: string
      address?: string; netmask?: string; autostart?: number
    }>>('GET', `/nodes/${node}/network`)
  }

  async getQemuList(node: string) {
    return this.request<Array<{
      vmid: number; name: string; status: string; cpus: number
      maxmem: number; maxdisk: number; uptime: number; cpu: number; mem: number
      template?: number
    }>>('GET', `/nodes/${node}/qemu`)
  }

  async getLxcList(node: string) {
    return this.request<Array<{
      vmid: number; name: string; status: string; cpus: number
      maxmem: number; maxdisk: number; uptime: number; cpu: number; mem: number
      template?: number
    }>>('GET', `/nodes/${node}/lxc`)
  }

  async getStorageContent(node: string, storage: string, content?: string) {
    const qs = content ? `?content=${content}` : ''
    return this.request<Array<{
      volid: string; format: string; size: number; content: string; vmid?: number
      ctime?: number; notes?: string
    }>>('GET', `/nodes/${node}/storage/${storage}/content${qs}`)
  }

  async deleteStorageContent(node: string, storage: string, volid: string) {
    const enc = encodeURIComponent(volid)
    return this.request<string>('DELETE', `/nodes/${node}/storage/${storage}/content/${enc}`)
  }

  async downloadUrlToStorage(node: string, storage: string, filename: string, url: string, content: string) {
    return this.request<string>('POST', `/nodes/${node}/storage/${storage}/download-url`, { filename, url, content } as any)
  }

  async getNextVMID() {
    return this.request<number>('GET', '/cluster/nextid')
  }

  async getVMStatus(node: string, vmid: number, type: 'qemu' | 'lxc' = 'qemu') {
    return this.request<{
      status: string; cpu: number; cpus: number; mem: number; maxmem: number
      uptime: number; netin: number; netout: number; diskread: number; diskwrite: number
      maxdisk: number; disk: number; pid?: number
    }>('GET', `/nodes/${node}/${type}/${vmid}/status/current`)
  }

  async startVM(node: string, vmid: number, type: 'qemu' | 'lxc' = 'qemu') {
    return this.request<string>('POST', `/nodes/${node}/${type}/${vmid}/status/start`, {})
  }

  async stopVM(node: string, vmid: number, type: 'qemu' | 'lxc' = 'qemu') {
    return this.request<string>('POST', `/nodes/${node}/${type}/${vmid}/status/stop`, {})
  }

  async shutdownVM(node: string, vmid: number, type: 'qemu' | 'lxc' = 'qemu') {
    return this.request<string>('POST', `/nodes/${node}/${type}/${vmid}/status/shutdown`, {})
  }

  async rebootVM(node: string, vmid: number, type: 'qemu' | 'lxc' = 'qemu') {
    return this.request<string>('POST', `/nodes/${node}/${type}/${vmid}/status/reboot`, {})
  }

  async resetVM(node: string, vmid: number) {
    return this.request<string>('POST', `/nodes/${node}/qemu/${vmid}/status/reset`, {})
  }

  async getTaskStatus(node: string, upid: string) {
    const enc = encodeURIComponent(upid)
    return this.request<{
      status: string; exitstatus?: string; type: string; starttime: number; upid: string
    }>('GET', `/nodes/${node}/tasks/${enc}/status`)
  }

  async waitForTask(node: string, upid: string, onProgress?: (msg: string) => void, timeout = 600): Promise<string> {
    const deadline = Date.now() + timeout * 1000
    while (Date.now() < deadline) {
      const s = await this.getTaskStatus(node, upid)
      if (s.status === 'stopped') {
        return s.exitstatus || 'unknown'
      }
      if (onProgress) onProgress(`Task running: ${s.type}`)
      await new Promise(r => setTimeout(r, 3000))
    }
    throw new Error(`Task timed out after ${timeout}s`)
  }

  async cloneVM(node: string, templateVmid: number, newVmid: number, opts: {
    name: string; full?: boolean; storage?: string; description?: string
  }) {
    return this.request<string>('POST', `/nodes/${node}/qemu/${templateVmid}/clone`, {
      newid: newVmid, name: opts.name,
      full: opts.full !== false ? 1 : 0,
      ...(opts.storage ? { storage: opts.storage } : {}),
      ...(opts.description ? { description: opts.description } : {}),
    })
  }

  async cloneLXC(node: string, templateVmid: number, newVmid: number, opts: {
    hostname: string; storage?: string; full?: boolean
  }) {
    return this.request<string>('POST', `/nodes/${node}/lxc/${templateVmid}/clone`, {
      newid: newVmid, hostname: opts.hostname,
      full: opts.full !== false ? 1 : 0,
      ...(opts.storage ? { storage: opts.storage } : {}),
    })
  }

  async configureVM(node: string, vmid: number, cfg: Record<string, unknown>) {
    return this.request<null>('POST', `/nodes/${node}/qemu/${vmid}/config`, cfg)
  }

  async configureLXC(node: string, vmid: number, cfg: Record<string, unknown>) {
    return this.request<null>('PUT', `/nodes/${node}/lxc/${vmid}/config`, cfg)
  }

  async getVMConfig(node: string, vmid: number, type: 'qemu' | 'lxc') {
    return this.request<Record<string, unknown>>('GET', `/nodes/${node}/${type}/${vmid}/config`)
  }

  async resizeDisk(node: string, vmid: number, type: 'qemu' | 'lxc', disk: string, size: string) {
    return this.request<null>('PUT', `/nodes/${node}/${type}/${vmid}/resize`, { disk, size })
  }

  async deleteVM(node: string, vmid: number, type: 'qemu' | 'lxc', purge = true) {
    const qs = purge ? '?purge=1&destroy-unreferenced-disks=1' : ''
    return this.request<string>('DELETE', `/nodes/${node}/${type}/${vmid}${qs}`)
  }

  async getRRDData(node: string, vmid: number, type: 'qemu' | 'lxc', timeframe: string) {
    return this.request<Array<{
      time: number; cpu?: number; mem?: number; netin?: number; netout?: number
      diskread?: number; diskwrite?: number; maxmem?: number; maxdisk?: number
    }>>('GET', `/nodes/${node}/${type}/${vmid}/rrddata?timeframe=${timeframe}&cf=AVERAGE`)
  }

  async getNodeRRD(node: string, timeframe: string) {
    return this.request<Array<{
      time: number; cpu?: number; memused?: number; memtotal?: number
      netin?: number; netout?: number
    }>>('GET', `/nodes/${node}/rrddata?timeframe=${timeframe}&cf=AVERAGE`)
  }

  async createSnapshot(node: string, vmid: number, type: 'qemu' | 'lxc', snapname: string, desc?: string) {
    return this.request<string>('POST', `/nodes/${node}/${type}/${vmid}/snapshot`,
      { snapname, ...(desc ? { description: desc } : {}) })
  }

  async listSnapshots(node: string, vmid: number, type: 'qemu' | 'lxc') {
    return this.request<Array<{
      name: string; description: string; parent: string; snaptime: number; running: number
    }>>('GET', `/nodes/${node}/${type}/${vmid}/snapshot`)
  }

  async deleteSnapshot(node: string, vmid: number, type: 'qemu' | 'lxc', snapname: string) {
    return this.request<string>('DELETE', `/nodes/${node}/${type}/${vmid}/snapshot/${snapname}`)
  }

  async rollbackSnapshot(node: string, vmid: number, type: 'qemu' | 'lxc', snapname: string) {
    return this.request<string>('POST', `/nodes/${node}/${type}/${vmid}/snapshot/${snapname}/rollback`, {})
  }

  async createLXCFromTemplate(node: string, cfg: Record<string, unknown>) {
    return this.request<string>('POST', `/nodes/${node}/lxc`, cfg)
  }

  async migrateVM(node: string, vmid: number, type: 'qemu' | 'lxc', target: string, opts: {
    online?: boolean; withLocalDisks?: boolean; targetstorage?: string
  } = {}) {
    return this.request<string>('POST', `/nodes/${node}/${type}/${vmid}/migrate`, {
      target,
      online: opts.online ? 1 : 0,
      ...(opts.withLocalDisks ? { 'with-local-disks': 1 } : {}),
      ...(opts.targetstorage ? { targetstorage: opts.targetstorage } : {}),
    })
  }

  async createBackup(node: string, vmid: number, storage: string, opts: {
    mode?: 'stop' | 'suspend' | 'snapshot'
    compress?: 'lzo' | 'gzip' | 'zstd'
    notes?: string
  } = {}) {
    return this.request<string>('POST', `/nodes/${node}/vzdump`, {
      vmid,
      storage,
      mode: opts.mode || 'stop',
      compress: opts.compress || 'zstd',
      ...(opts.notes ? { notes: opts.notes } : {}),
    })
  }

  async listBackups(node: string, storage: string, vmid?: number) {
    const qs = vmid ? `?content=backup&vmid=${vmid}` : '?content=backup'
    return this.request<Array<{
      volid: string; format: string; size: number; content: string
      vmid?: number; ctime?: number; notes?: string
    }>>('GET', `/nodes/${node}/storage/${storage}/content${qs}`)
  }

  async deleteBackup(node: string, storage: string, volid: string) {
    const enc = encodeURIComponent(volid)
    return this.request<string>('DELETE', `/nodes/${node}/storage/${storage}/content/${enc}`)
  }

  async restoreBackup(node: string, vmid: number, type: 'qemu' | 'lxc', storage: string, archive: string, opts: {
    hostname?: string; force?: boolean
  } = {}) {
    if (type === 'qemu') {
      return this.request<string>('POST', `/nodes/${node}/qemu`, {
        vmid, archive, storage, force: opts.force ? 1 : 0,
      })
    } else {
      return this.request<string>('POST', `/nodes/${node}/lxc`, {
        vmid, ostemplate: archive, storage, force: opts.force ? 1 : 0,
        restore: 1, hostname: opts.hostname || 'restored',
      })
    }
  }

  async resizeConfig(node: string, vmid: number, type: 'qemu' | 'lxc', cfg: {
    cores?: number; memory?: number; sockets?: number
  }) {
    const method = type === 'qemu' ? 'POST' : 'PUT'
    return this.request<null>(method, `/nodes/${node}/${type}/${vmid}/config`, cfg as any)
  }

  async getClusterResources() {
    return this.request<Array<{
      id: string; type: string; status: string; node: string; vmid?: number
      name?: string; uptime?: number; cpu?: number; mem?: number; maxmem?: number
      maxcpu?: number; maxdisk?: number; disk?: number
    }>>('GET', '/cluster/resources')
  }

  async vmExists(node: string, vmid: number, type: 'qemu' | 'lxc'): Promise<boolean> {
    try {
      await this.getVMStatus(node, vmid, type)
      return true
    } catch {
      return false
    }
  }

  async getNodeServices(node: string) {
    return this.request<Array<{
      name: string; desc?: string; state: string; unit_state?: string; active_state?: string
    }>>('GET', `/nodes/${node}/services`)
  }

  async controlNodeService(node: string, service: string, action: 'start' | 'stop' | 'restart' | 'reload') {
    return this.request<string>('POST', `/nodes/${node}/services/${service}/${action}`, {})
  }

  async getNodeDisks(node: string) {
    return this.request<Array<{
      devpath: string; type: string; size: number; model?: string; serial?: string
      vendor?: string; rpm?: number; gpt?: number; health?: string; wearout?: number
    }>>('GET', `/nodes/${node}/disks/list`)
  }

  async getDiskSmart(node: string, disk: string) {
    return this.request<{
      health: string; text?: string; type?: string
      attributes?: Array<{ name: string; value: number; worst: number; threshold: number; raw: string; flags: string }>
    }>('GET', `/nodes/${node}/disks/smart?disk=${encodeURIComponent(disk)}`)
  }

  async getNodeSyslog(node: string, opts: { start?: number; limit?: number; since?: string; until?: string } = {}) {
    const qs = new URLSearchParams()
    if (opts.start !== undefined) qs.set('start', String(opts.start))
    if (opts.limit) qs.set('limit', String(opts.limit))
    if (opts.since) qs.set('since', opts.since)
    if (opts.until) qs.set('until', opts.until)
    const q = qs.toString()
    return this.request<Array<{ n: number; t: string }>>('GET', `/nodes/${node}/syslog${q ? '?' + q : ''}`)
  }

  async getNodeTasks(node: string, opts: { limit?: number; errors?: number } = {}) {
    const qs = new URLSearchParams()
    qs.set('limit', String(opts.limit ?? 50))
    if (opts.errors !== undefined) qs.set('errors', String(opts.errors))
    return this.request<Array<{
      upid: string; id: string; type: string; user: string; status: string
      starttime: number; endtime?: number; node: string
    }>>('GET', `/nodes/${node}/tasks?${qs.toString()}`)
  }

  async getNodeTaskLog(node: string, upid: string) {
    const enc = encodeURIComponent(upid)
    return this.request<Array<{ n: number; t: string }>>('GET', `/nodes/${node}/tasks/${enc}/log`)
  }

  async getNodeAptUpdates(node: string) {
    return this.request<Array<{
      Package: string; Version: string; OldVersion: string; Priority?: string; Description?: string
    }>>('GET', `/nodes/${node}/apt/update`)
  }

  async triggerAptFetch(node: string) {
    return this.request<string>('POST', `/nodes/${node}/apt/update`, {})
  }

  async getFirewallRules(node?: string) {
    const path = node ? `/nodes/${node}/firewall/rules` : '/cluster/firewall/rules'
    return this.request<Array<{
      pos: number; type: string; action: string; enable?: number; source?: string; dest?: string
      dport?: string; sport?: string; proto?: string; comment?: string; iface?: string
    }>>('GET', path)
  }

  async createFirewallRule(node: string | null, rule: Record<string, unknown>) {
    const path = node ? `/nodes/${node}/firewall/rules` : '/cluster/firewall/rules'
    return this.request<null>('POST', path, rule)
  }

  async deleteFirewallRule(node: string | null, pos: number) {
    const path = node ? `/nodes/${node}/firewall/rules/${pos}` : `/cluster/firewall/rules/${pos}`
    return this.request<null>('DELETE', path)
  }
}

export function makeProxmox(cluster: {
  hostname: string; port: number; protocol?: 'https' | 'http'; tokenId: string; tokenSecret: string; tlsVerify: boolean | number
}): ProxmoxService {
  let hostname = cluster.hostname.trim()
  let protocol: 'https' | 'http' = cluster.protocol ?? 'https'
  let port = cluster.port

  if (/^https?:\/\//i.test(hostname)) {
    const parsed = new URL(hostname)
    protocol = parsed.protocol === 'http:' ? 'http' : 'https'
    hostname = parsed.hostname
    if (parsed.port) port = Number(parsed.port)
  } else if (!cluster.protocol && cluster.port === 80) {
    protocol = 'http'
  }

  return new ProxmoxService({
    hostname,
    port,
    protocol,
    tokenId: cluster.tokenId,
    tokenSecret: cluster.tokenSecret,
    tlsVerify: Boolean(cluster.tlsVerify),
  })
}
