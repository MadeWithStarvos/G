import { db } from '../db/index.js'
import { serverTimers, servers, activityLogs } from '../db/schema.js'
import { eq, and, lte } from 'drizzle-orm'
import { nanoid } from 'nanoid'
import { createJob } from './jobs.js'

export function processTimers() {
  const now = new Date().toISOString()
  const due = db.select().from(serverTimers)
    .where(and(eq(serverTimers.status, 'pending'), lte(serverTimers.triggerAt, now)))
    .all()

  for (const timer of due) {
    try {
      const server = db.select().from(servers).where(eq(servers.id, timer.serverId)).get()
      if (!server || server.isSuspended) {
        db.update(serverTimers).set({ status: 'cancelled' }).where(eq(serverTimers.id, timer.id)).run()
        continue
      }

      db.update(serverTimers).set({ status: 'executed' }).where(eq(serverTimers.id, timer.id)).run()

      if (!server.clusterId || !server.nodeId || !server.vmid) {
        const newStatus = timer.action === 'start' ? 'running' : ['stop', 'shutdown', 'reset'].includes(timer.action) ? 'stopped' : server.status
        db.update(servers).set({ status: newStatus as any, updatedAt: new Date().toISOString() }).where(eq(servers.id, server.id)).run()
      } else {
        createJob({ type: 'power', serverId: server.id, userId: timer.userId || undefined, action: timer.action })
      }

      db.insert(activityLogs).values({
        id: nanoid(), userId: timer.userId, actorId: timer.userId,
        action: `server.timer.executed`, targetType: 'server', targetId: server.id,
        metadata: JSON.stringify({ action: timer.action }),
        createdAt: new Date().toISOString(),
      }).run()
    } catch (err) {
      console.error(`[timerService] failed to execute timer ${timer.id}:`, err)
      db.update(serverTimers).set({ status: 'failed' }).where(eq(serverTimers.id, timer.id)).run()
    }
  }
}
