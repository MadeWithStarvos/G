import { db } from '../db/index.js'
import { webhooks } from '../db/schema.js'
import { eq } from 'drizzle-orm'
import https from 'https'
import http from 'http'
import crypto from 'crypto'

export type WebhookEvent =
  | 'server.provisioned' | 'server.failed' | 'server.suspended'
  | 'server.unsuspended' | 'server.terminated' | 'server.power'
  | 'backup.created' | 'backup.failed'

export async function fireWebhook(event: WebhookEvent, payload: Record<string, unknown>) {
  const allWebhooks = db.select().from(webhooks).where(eq(webhooks.isEnabled, true)).all()
  for (const wh of allWebhooks) {
    const events: string[] = JSON.parse(wh.events || '[]')
    if (!events.includes(event) && !events.includes('*')) continue
    deliverWebhook(wh, event, payload).catch(err =>
      console.error(`[webhook] delivery failed to ${wh.url}:`, err.message)
    )
  }
}

async function deliverWebhook(wh: typeof webhooks.$inferSelect, event: string, payload: Record<string, unknown>) {
  const body = JSON.stringify({ event, timestamp: new Date().toISOString(), data: payload })
  const signature = wh.secret
    ? 'sha256=' + crypto.createHmac('sha256', wh.secret).update(body).digest('hex')
    : undefined

  return new Promise<void>((resolve, reject) => {
    const url = new URL(wh.url)
    const mod = url.protocol === 'https:' ? https : http
    const req = (mod as typeof https).request({
      hostname: url.hostname,
      port: url.port || (url.protocol === 'https:' ? 443 : 80),
      path: url.pathname + url.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
        'X-MatrixHost-Event': event,
        ...(signature ? { 'X-MatrixHost-Signature': signature } : {}),
      },
    }, (res) => {
      res.resume()
      db.update(webhooks).set({ lastDelivery: new Date().toISOString() }).where(eq(webhooks.id, wh.id)).run()
      res.statusCode && res.statusCode < 400 ? resolve() : reject(new Error(`HTTP ${res.statusCode}`))
    })
    req.setTimeout(10000, () => { req.destroy(); reject(new Error('Timeout')) })
    req.on('error', reject)
    req.write(body)
    req.end()
  })
}
