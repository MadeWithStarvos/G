import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import cookieParser from 'cookie-parser'
import rateLimit from 'express-rate-limit'
import path from 'path'
import { fileURLToPath } from 'url'
import { initDb, seedAdmin } from './db/index.js'
import authRouter from './routes/auth.js'
import adminRouter from './routes/admin.js'
import serversRouter from './routes/servers.js'
import profileRouter from './routes/profile.js'
import provisionRouter from './routes/provision.js'
import externalRouter from './routes/external.js'
import nodesRouter from './routes/nodes.js'
import { processTimers } from './services/timerService.js'
import { startReconciler } from './services/reconcile.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

initDb()
seedAdmin()

// Process scheduled server timers every 30 seconds
setInterval(() => { try { processTimers() } catch (e) { console.error('[timers]', e) } }, 30_000)

// Start reconciliation worker every 5 minutes
startReconciler(5 * 60 * 1000)

const app = express()
const PORT = process.env.PORT || 3001

app.set('trust proxy', 1)

app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
}))

app.use(cors({
  origin: process.env.CORS_ORIGIN || true,
  credentials: true,
}))

app.use(express.json())
app.use(cookieParser())

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
})

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
})

app.use('/api', limiter)
app.use('/api/auth/login', authLimiter)
app.use('/api/auth/register', authLimiter)

app.use('/api/auth', authRouter)
app.use('/api/admin', adminRouter)
app.use('/api/servers', serversRouter)
app.use('/api/profile', profileRouter)
app.use('/api/provision', provisionRouter)
app.use('/api/external', externalRouter)
app.use('/api/admin/nodes', nodesRouter)

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', version: '1.0.0', name: 'MatrixHost' })
})

const distPath = path.resolve(__dirname, '../dist')
const publicPath = path.resolve(__dirname, '../public')

app.use(express.static(publicPath))

if (process.env.NODE_ENV === 'production') {
  app.use(express.static(distPath))
  app.get('*', (req, res) => {
    res.sendFile(path.join(distPath, 'index.html'))
  })
}

app.listen(PORT, () => {
  console.log(`MatrixHost API running on port ${PORT}`)
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`)
})

export default app
