import { useState, useEffect, useCallback } from 'react'
import { AuthCtx } from './lib/auth'
import { api } from './lib/api'
import type { User } from './lib/api'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'
import DashboardLayout from './components/layout/DashboardLayout'
import DashboardPage from './pages/DashboardPage'
import ServersPage from './pages/ServersPage'
import ServerDetailPage from './pages/ServerDetailPage'
import ProfilePage from './pages/ProfilePage'
import APITokensPage from './pages/APITokensPage'
import AdminDashboardPage from './pages/admin/AdminDashboardPage'
import AdminUsersPage from './pages/admin/AdminUsersPage'
import AdminClustersPage from './pages/admin/AdminClustersPage'
import AdminNodesPage from './pages/admin/AdminNodesPage'
import AdminNodeDetailPage from './pages/admin/AdminNodeDetailPage'
import AdminLocationsPage from './pages/admin/AdminLocationsPage'
import AdminActivityPage from './pages/admin/AdminActivityPage'
import AdminServersPage from './pages/admin/AdminServersPage'
import AdminTemplatesPage from './pages/admin/AdminTemplatesPage'
import AdminSettingsPage from './pages/admin/AdminSettingsPage'

type Route =
  | { page: 'login' }
  | { page: 'register' }
  | { page: 'dashboard' }
  | { page: 'servers' }
  | { page: 'server-detail'; id: string }
  | { page: 'profile' }
  | { page: 'api-tokens' }
  | { page: 'admin-dashboard' }
  | { page: 'admin-users' }
  | { page: 'admin-servers' }
  | { page: 'admin-clusters' }
  | { page: 'admin-nodes' }
  | { page: 'admin-node-detail'; id: string }
  | { page: 'admin-locations' }
  | { page: 'admin-activity' }
  | { page: 'admin-templates' }
  | { page: 'admin-settings' }

export default function App() {
  const [user, setUser] = useState<User | null>(null)
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('token'))
  const [isLoading, setIsLoading] = useState(true)
  const [route, setRoute] = useState<Route>({ page: 'dashboard' })

  useEffect(() => {
    if (token) {
      api.auth.me()
        .then(u => setUser(u))
        .catch(() => { localStorage.removeItem('token'); setToken(null) })
        .finally(() => setIsLoading(false))
    } else {
      setIsLoading(false)
    }
  }, [token])

  const login = useCallback(async (email: string, password: string) => {
    const res = await api.auth.login(email, password)
    localStorage.setItem('token', res.token)
    setToken(res.token); setUser(res.user)
    setRoute({ page: 'dashboard' })
  }, [])

  const register = useCallback(async (data: Parameters<typeof api.auth.register>[0]) => {
    const res = await api.auth.register(data)
    localStorage.setItem('token', res.token)
    setToken(res.token); setUser(res.user)
    setRoute({ page: 'dashboard' })
  }, [])

  const logout = useCallback(() => {
    api.auth.logout().catch(() => {})
    localStorage.removeItem('token')
    setToken(null); setUser(null)
    setRoute({ page: 'login' })
  }, [])

  const navigate = useCallback((r: Route) => setRoute(r), [])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-zinc-500 text-sm">Loading MatrixHost…</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <AuthCtx.Provider value={{ user, token, isLoading, login, register, logout }}>
        {route.page === 'register'
          ? <RegisterPage onNavigate={navigate} />
          : <LoginPage onNavigate={navigate} />}
      </AuthCtx.Provider>
    )
  }

  const isAdmin = user.role === 'superadmin' || user.role === 'admin'

  return (
    <AuthCtx.Provider value={{ user, token, isLoading, login, register, logout }}>
      <DashboardLayout navigate={navigate} currentPage={route.page}>
        {route.page === 'dashboard' && <DashboardPage navigate={navigate} />}
        {route.page === 'servers' && <ServersPage navigate={navigate} />}
        {route.page === 'server-detail' && <ServerDetailPage id={route.id} navigate={navigate} />}
        {route.page === 'profile' && <ProfilePage />}
        {route.page === 'api-tokens' && <APITokensPage />}
        {isAdmin && route.page === 'admin-dashboard' && <AdminDashboardPage navigate={navigate} />}
        {isAdmin && route.page === 'admin-users' && <AdminUsersPage />}
        {isAdmin && route.page === 'admin-servers' && <AdminServersPage />}
        {isAdmin && route.page === 'admin-clusters' && <AdminClustersPage />}
        {isAdmin && route.page === 'admin-nodes' && <AdminNodesPage navigate={navigate} />}
        {isAdmin && route.page === 'admin-node-detail' && <AdminNodeDetailPage nodeId={route.id} navigate={navigate} />}
        {isAdmin && route.page === 'admin-locations' && <AdminLocationsPage />}
        {isAdmin && route.page === 'admin-activity' && <AdminActivityPage />}
        {isAdmin && route.page === 'admin-templates' && <AdminTemplatesPage />}
        {isAdmin && route.page === 'admin-settings' && <AdminSettingsPage />}
      </DashboardLayout>
    </AuthCtx.Provider>
  )
}
