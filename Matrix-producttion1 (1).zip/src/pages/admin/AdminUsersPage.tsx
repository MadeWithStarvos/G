import { useState, useEffect } from 'react'
import { api } from '../../lib/api'
import type { User } from '../../lib/api'

export default function AdminUsersPage() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [acting, setActing] = useState('')
  const [toast, setToast] = useState('')

  useEffect(() => {
    api.admin.users().then(setUsers).finally(() => setLoading(false))
  }, [])

  const filtered = users.filter(u =>
    u.email.toLowerCase().includes(search.toLowerCase()) ||
    u.username.toLowerCase().includes(search.toLowerCase()) ||
    (u.firstName || '').toLowerCase().includes(search.toLowerCase())
  )

  async function toggleSuspend(user: User) {
    setActing(user.id)
    try {
      if (user.isSuspended) {
        await api.admin.unsuspendUser(user.id)
        setUsers(us => us.map(u => u.id === user.id ? { ...u, isSuspended: false } : u))
        setToast('User unsuspended')
      } else {
        await api.admin.suspendUser(user.id)
        setUsers(us => us.map(u => u.id === user.id ? { ...u, isSuspended: true } : u))
        setToast('User suspended')
      }
    } catch (e: any) {
      setToast(`Error: ${e.message}`)
    } finally {
      setActing('')
      setTimeout(() => setToast(''), 3000)
    }
  }

  const roleColors: Record<string, string> = {
    superadmin: 'text-violet-400 bg-violet-500/10 border-violet-500/20',
    admin: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
    support: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20',
    customer: 'text-zinc-400 bg-zinc-700/30 border-zinc-600/20',
  }

  return (
    <div className="max-w-6xl mx-auto animate-fade-in">
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-zinc-800 border border-white/10 text-white text-sm px-4 py-3 rounded-xl shadow-2xl animate-slide-up">{toast}</div>
      )}

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-white">Users</h1>
          <p className="text-zinc-500 text-sm mt-0.5">{users.length} registered accounts</p>
        </div>
      </div>

      <div className="relative mb-4">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600">
          <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
        </svg>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search users…"
          className="w-full bg-white/[0.04] border border-white/[0.06] rounded-lg pl-10 pr-4 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/40 transition-all" />
      </div>

      <div className="glass rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="skeleton h-14 rounded-lg" />)}</div>
        ) : !filtered.length ? (
          <div className="py-16 text-center text-zinc-500 text-sm">No users found</div>
        ) : (
          <>
            <div className="hidden lg:grid grid-cols-[1fr_auto_auto_auto_auto] gap-4 px-5 py-3 border-b border-white/[0.06] text-xs font-medium text-zinc-600 uppercase tracking-wider">
              <span>User</span><span>Role</span><span>Verified</span><span>Joined</span><span>Actions</span>
            </div>
            <div className="divide-y divide-white/[0.04]">
              {filtered.map(user => (
                <div key={user.id} className="grid grid-cols-1 lg:grid-cols-[1fr_auto_auto_auto_auto] gap-4 items-center px-5 py-3.5">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-zinc-700 to-zinc-800 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                      {((user.firstName?.[0] || user.username[0]) || 'U').toUpperCase()}
                    </div>
                    <div>
                      <div className="text-white text-sm font-medium">
                        {user.firstName ? `${user.firstName} ${user.lastName || ''}`.trim() : user.username}
                      </div>
                      <div className="text-zinc-500 text-xs">{user.email}</div>
                    </div>
                  </div>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border uppercase tracking-wide ${roleColors[user.role] || roleColors.customer}`}>
                    {user.role}
                  </span>
                  <span className={`text-xs ${user.emailVerified ? 'text-emerald-400' : 'text-zinc-600'}`}>
                    {user.emailVerified ? '✓ Verified' : 'Unverified'}
                  </span>
                  <span className="text-zinc-600 text-xs">{user.createdAt ? new Date(user.createdAt).toLocaleDateString() : '—'}</span>
                  <button
                    onClick={() => toggleSuspend(user)}
                    disabled={acting === user.id}
                    className={`text-xs font-medium px-3 py-1.5 rounded-lg border transition-all disabled:opacity-40
                      ${user.isSuspended
                        ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20'
                        : 'bg-amber-500/10 border-amber-500/20 text-amber-400 hover:bg-amber-500/20'
                      }`}
                  >
                    {acting === user.id ? '…' : user.isSuspended ? 'Unsuspend' : 'Suspend'}
                  </button>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  )
}
