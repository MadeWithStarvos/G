import { useState, useEffect } from 'react'
import { api } from '../../lib/api'
import type { Template, Cluster, CreateTemplateData, OsLibraryTemplate, Node, StoragePool } from '../../lib/api'

export default function AdminTemplatesPage() {
  const [templates, setTemplates] = useState<Template[]>([])
  const [clusters, setClusters] = useState<Cluster[]>([])
  const [nodes, setNodes] = useState<Node[]>([])
  const [storagePools, setStoragePools] = useState<StoragePool[]>([])
  const [osLibrary, setOsLibrary] = useState<OsLibraryTemplate[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [installing, setInstalling] = useState(false)
  const [toast, setToast] = useState('')
  const [installForm, setInstallForm] = useState({ clusterId: '', node: '', storage: '', templateKey: '' })
  const [form, setForm] = useState<CreateTemplateData>({
    clusterId: '', node: '', name: '', virtType: 'kvm', vmid: undefined,
    volid: '', osName: '', osVersion: '', description: '', isEnabled: true,
  })

  useEffect(() => {
    Promise.all([
      api.admin.templates(), api.admin.clusters(), api.admin.osLibrary(), api.admin.nodes(), api.admin.storage(),
    ])
      .then(([t, c, lib, n, s]) => {
        setTemplates(t); setClusters(c); setOsLibrary(lib); setNodes(n); setStoragePools(s)
      })
      .finally(() => setLoading(false))
  }, [])

  function showToast(msg: string) { setToast(msg); setTimeout(() => setToast(''), 4000) }

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault(); setSaving(true)
    try {
      const payload: CreateTemplateData = {
        ...form,
        vmid: form.vmid ? Number(form.vmid) : undefined,
        volid: form.volid || undefined,
        osName: form.osName || undefined,
        osVersion: form.osVersion || undefined,
        description: form.description || undefined,
      }
      const tpl = await api.admin.createTemplate(payload)
      setTemplates(t => [...t, tpl])
      setShowForm(false)
      setForm({ clusterId: '', node: '', name: '', virtType: 'kvm', vmid: undefined, volid: '', osName: '', osVersion: '', description: '', isEnabled: true })
      showToast('Template added')
    } catch (e: any) { showToast(`Error: ${e.message}`) }
    finally { setSaving(false) }
  }

  async function handleInstallLibrary(e: React.FormEvent) {
    e.preventDefault()
    if (!installForm.clusterId || !installForm.node || !installForm.storage || !installForm.templateKey) {
      showToast('Cluster, node, storage, and template are required')
      return
    }

    setInstalling(true)
    try {
      const tpl = await api.admin.installOsLibraryTemplate(installForm.clusterId, {
        node: installForm.node,
        storage: installForm.storage,
        templateKey: installForm.templateKey,
      })
      setTemplates(t => [...t, tpl])
      setInstallForm({ clusterId: '', node: '', storage: '', templateKey: '' })
      showToast(`Installed ${tpl.name}`)
    } catch (e: any) {
      showToast(`Error: ${e.message}`)
    } finally {
      setInstalling(false)
    }
  }

  async function toggleTemplate(id: string, isEnabled: boolean) {
    try {
      await api.admin.updateTemplate(id, { isEnabled: !isEnabled })
      setTemplates(t => t.map(tpl => tpl.id === id ? { ...tpl, isEnabled: !isEnabled } : tpl))
    } catch (e: any) { showToast(`Error: ${e.message}`) }
  }

  async function syncTemplatesForCluster(clusterId: string) {
    const name = clusters.find(c => c.id === clusterId)?.name || clusterId
    try {
      const res = await api.admin.syncTemplates(clusterId)
      showToast(`Synced ${res.synced} templates from ${name}`)
      const updated = await api.admin.templates()
      setTemplates(updated)
    } catch (e: any) { showToast(`Error: ${e.message}`) }
  }

  const clusterName = (id: string) => clusters.find(c => c.id === id)?.name || id
  const clusterNodes = installForm.clusterId ? nodes.filter(n => n.clusterId === installForm.clusterId) : []
  const clusterStorages = installForm.clusterId
    ? storagePools.filter(s => s.clusterId === installForm.clusterId && (!installForm.node || s.node === installForm.node))
    : []
  const selectedLibrary = osLibrary.find(t => t.key === installForm.templateKey)

  return (
    <div className="max-w-5xl mx-auto animate-fade-in">
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-zinc-800 border border-white/10 text-white text-sm px-4 py-3 rounded-xl shadow-2xl animate-slide-up">{toast}</div>
      )}

      <div className="flex flex-col gap-4 mb-6">
        <div>
          <h1 className="text-xl font-bold text-white">OS Templates</h1>
          <p className="text-zinc-500 text-sm mt-0.5">{templates.filter(t => t.isEnabled).length} active templates</p>
        </div>
        <div className="glass rounded-xl p-5 border border-white/[0.08]">
          <div className="flex items-center justify-between mb-4 gap-4">
            <div>
              <h2 className="text-sm font-semibold text-white">OS Template Library</h2>
              <p className="text-zinc-500 text-sm mt-1">Import a library template directly into a selected cluster node and storage.</p>
            </div>
          </div>
          <form onSubmit={handleInstallLibrary} className="grid gap-4 md:grid-cols-4">
            <div className="col-span-1 md:col-span-1">
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Cluster</label>
              <select value={installForm.clusterId} onChange={e => setInstallForm(f => ({ ...f, clusterId: e.target.value, node: '', storage: '' }))}
                className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500/60">
                <option value="">Select cluster…</option>
                {clusters.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div className="col-span-1 md:col-span-1">
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Node</label>
              <select value={installForm.node} onChange={e => setInstallForm(f => ({ ...f, node: e.target.value, storage: '' }))}
                disabled={!installForm.clusterId}
                className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500/60">
                <option value="">Select node…</option>
                {clusterNodes.map(n => <option key={n.id} value={n.name}>{n.name}</option>)}
              </select>
            </div>
            <div className="col-span-1 md:col-span-1">
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Storage</label>
              <select value={installForm.storage} onChange={e => setInstallForm(f => ({ ...f, storage: e.target.value }))}
                disabled={!installForm.clusterId || !installForm.node}
                className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500/60">
                <option value="">Select storage…</option>
                {clusterStorages.map(s => <option key={s.id} value={s.storage}>{s.node} / {s.storage}</option>)}
              </select>
            </div>
            <div className="col-span-1 md:col-span-1">
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Template</label>
              <select value={installForm.templateKey} onChange={e => setInstallForm(f => ({ ...f, templateKey: e.target.value }))}
                className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500/60">
                <option value="">Select library template…</option>
                {osLibrary.map(item => (
                  <option key={item.key} value={item.key}>{item.name} · {item.osVersion}</option>
                ))}
              </select>
            </div>
            <div className="col-span-1 md:col-span-4 flex items-end gap-3">
              <button type="submit" disabled={installing}
                className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-sm font-semibold px-4 py-2.5 rounded-lg transition-all">
                {installing ? 'Installing…' : 'Install Template'}
              </button>
              {selectedLibrary && (
                <div className="text-zinc-500 text-xs leading-snug">
                  <div className="font-medium text-white">{selectedLibrary.name}</div>
                  <div>{selectedLibrary.description}</div>
                </div>
              )}
            </div>
          </form>
        </div>
      </div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-white">OS Templates</h1>
          <p className="text-zinc-500 text-sm mt-0.5">{templates.filter(t => t.isEnabled).length} active templates</p>
        </div>
        <div className="flex items-center gap-2">
          {clusters.map(c => (
            <button key={c.id} onClick={() => syncTemplatesForCluster(c.id)}
              className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg border border-violet-500/20 text-violet-400 hover:bg-violet-500/10 transition-all">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-3 h-3"><polyline points="1 4 1 10 7 10" /><polyline points="23 20 23 14 17 14" /><path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4-4.64 4.36A9 9 0 0 1 3.51 15" /></svg>
              Sync {c.name}
            </button>
          ))}
          <button onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-all">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
            Add Template
          </button>
        </div>
      </div>

      {showForm && (
        <div className="glass rounded-xl p-5 mb-6 animate-slide-up">
          <h3 className="text-white font-semibold text-sm mb-4">Add Template</h3>
          <form onSubmit={handleAdd} className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Cluster</label>
              <select value={form.clusterId} onChange={e => setForm(f => ({ ...f, clusterId: e.target.value }))} required
                className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500/60">
                <option value="">Select cluster…</option>
                {clusters.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Node Name</label>
              <input value={form.node} onChange={e => setForm(f => ({ ...f, node: e.target.value }))} required placeholder="pve" className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60" />
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Template Name</label>
              <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required placeholder="Ubuntu 24.04" className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60" />
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Type</label>
              <select value={form.virtType} onChange={e => setForm(f => ({ ...f, virtType: e.target.value as 'kvm' | 'lxc' }))}
                className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500/60">
                <option value="kvm">KVM (Full VM)</option>
                <option value="lxc">LXC (Container)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">VMID (for KVM templates)</label>
              <input type="number" value={form.vmid ?? ''} onChange={e => setForm(f => ({ ...f, vmid: e.target.value ? Number(e.target.value) : undefined }))} placeholder="9000" className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60" />
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Vol ID (for LXC templates)</label>
              <input value={form.volid ?? ''} onChange={e => setForm(f => ({ ...f, volid: e.target.value }))} placeholder="local:vztmpl/ubuntu-22.04-standard_22.04-1_amd64.tar.zst" className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60" />
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">OS Name</label>
              <input value={form.osName ?? ''} onChange={e => setForm(f => ({ ...f, osName: e.target.value }))} placeholder="Ubuntu" className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60" />
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">OS Version</label>
              <input value={form.osVersion ?? ''} onChange={e => setForm(f => ({ ...f, osVersion: e.target.value }))} placeholder="24.04 LTS" className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60" />
            </div>
            <div className="col-span-2 flex gap-3 pt-2">
              <button type="submit" disabled={saving}
                className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-semibold px-5 py-2.5 rounded-lg flex items-center gap-2">
                {saving && <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
                {saving ? 'Adding…' : 'Add Template'}
              </button>
              <button type="button" onClick={() => setShowForm(false)}
                className="text-zinc-400 hover:text-white text-sm px-4 py-2.5 rounded-lg border border-white/[0.08] hover:border-white/20">Cancel</button>
            </div>
          </form>
        </div>
      )}

      <div className="glass rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 space-y-3">{[...Array(4)].map((_, i) => <div key={i} className="skeleton h-14 rounded-lg" />)}</div>
        ) : !templates.length ? (
          <div className="flex flex-col items-center justify-center py-20">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-10 h-10 text-zinc-700 mb-4"><path d="M12 2L2 7l10 5 10-5-10-5z" /><path d="M2 17l10 5 10-5" /><path d="M2 12l10 5 10-5" /></svg>
            <p className="text-zinc-500 text-sm">No templates yet</p>
            <p className="text-zinc-700 text-xs mt-1">Add templates manually or sync from a Proxmox cluster</p>
          </div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {templates.map(t => (
              <div key={t.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-white/[0.02] transition-colors">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${t.virtType === 'kvm' ? 'bg-blue-500/10' : 'bg-violet-500/10'}`}>
                  {t.virtType === 'kvm'
                    ? <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4 text-blue-400"><rect x="2" y="2" width="20" height="8" rx="2" /><rect x="2" y="14" width="20" height="8" rx="2" /></svg>
                    : <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4 text-violet-400"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" /></svg>
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-white text-sm font-medium">{t.name}</div>
                  <div className="text-zinc-500 text-xs">{clusterName(t.clusterId)} · {t.node}{t.vmid ? ` · VMID ${t.vmid}` : ''}{t.volid ? ` · ${t.volid.split('/').pop()}` : ''}</div>
                </div>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border uppercase tracking-wide ${t.virtType === 'kvm' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' : 'bg-violet-500/10 text-violet-400 border-violet-500/20'}`}>{t.virtType}</span>
                {t.osName && <span className="text-zinc-500 text-xs hidden md:block">{t.osName} {t.osVersion}</span>}
                <button onClick={() => toggleTemplate(t.id, t.isEnabled)}
                  className={`text-[10px] font-semibold px-2 py-0.5 rounded border uppercase tracking-wide transition-all ${t.isEnabled ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-red-500/10 hover:text-red-400 hover:border-red-500/20' : 'bg-zinc-700/30 text-zinc-500 border-zinc-600/20 hover:bg-emerald-500/10 hover:text-emerald-400 hover:border-emerald-500/20'}`}>
                  {t.isEnabled ? 'Enabled' : 'Disabled'}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
