import { useState, useEffect, useCallback } from 'react'
import { apiFetch } from '../../lib/api'
import type { IpPool, IpAddress, Cluster, CreateIpPoolData } from '../../lib/api'

const STATUS_COLOR: Record<string, string> = {
  available: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
  reserved: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
  allocated: 'text-violet-400 bg-violet-500/10 border-violet-500/20',
  disabled: 'text-zinc-500 bg-zinc-800 border-zinc-700',
}

const BLANK_POOL: CreateIpPoolData = { name: '', gateway: '', subnet: '24', dns1: '8.8.8.8', dns2: '8.8.4.4', bridge: 'vmbr0', isIpv6: false }

export default function AdminIPManagerPage() {
  const [pools, setPools] = useState<IpPool[]>([])
  const [clusters, setClusters] = useState<Cluster[]>([])
  const [selectedPool, setSelectedPool] = useState<string>('')
  const [addresses, setAddresses] = useState<IpAddress[]>([])
  const [tab, setTab] = useState<'pools' | 'addresses'>('pools')
  const [poolForm, setPoolForm] = useState<CreateIpPoolData & { clusterId?: string }>(BLANK_POOL)
  const [addrInput, setAddrInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [err, setErr] = useState('')
  const [filter, setFilter] = useState('')

  useEffect(() => {
    apiFetch<IpPool[]>('/admin/ip-pools').then(setPools).catch(() => {})
    apiFetch<Cluster[]>('/admin/clusters').then(setClusters).catch(() => {})
  }, [])

  const loadAddresses = useCallback(async (poolId: string) => {
    setLoading(true)
    try {
      const data = await apiFetch<IpAddress[]>(`/admin/ip-pools/${poolId}/addresses`)
      setAddresses(data)
    } catch {}
    setLoading(false)
  }, [])

  useEffect(() => {
    if (selectedPool) { loadAddresses(selectedPool) }
    else setAddresses([])
  }, [selectedPool, loadAddresses])

  const createPool = async () => {
    if (!poolForm.name || !poolForm.gateway || !poolForm.subnet) { setErr('Name, gateway and subnet required'); return }
    setSaving(true); setErr('')
    try {
      await apiFetch<IpPool>('/admin/ip-pools', { method: 'POST', body: JSON.stringify(poolForm) })
      const data = await apiFetch<IpPool[]>('/admin/ip-pools')
      setPools(data); setPoolForm(BLANK_POOL)
    } catch (e: any) { setErr(e.message) }
    setSaving(false)
  }

  const deletePool = async (id: string) => {
    if (!confirm('Delete this IP pool and all its addresses?')) return
    try {
      await apiFetch(`/admin/ip-pools/${id}`, { method: 'DELETE' })
      setPools(p => p.filter(x => x.id !== id))
      if (selectedPool === id) { setSelectedPool(''); setAddresses([]) }
    } catch (e: any) { alert(e.message) }
  }

  const addAddresses = async () => {
    if (!selectedPool || !addrInput.trim()) return
    const lines = addrInput.split(/[\n,\s]+/).map(s => s.trim()).filter(Boolean)
    setSaving(true)
    try {
      const result = await apiFetch<{ added: number }>(`/admin/ip-pools/${selectedPool}/addresses`, {
        method: 'POST', body: JSON.stringify({ addresses: lines })
      })
      setAddrInput('')
      await loadAddresses(selectedPool)
      alert(`Added ${result.added} addresses`)
    } catch (e: any) { alert(e.message) }
    setSaving(false)
  }

  const updateAddress = async (id: string, status: string) => {
    try {
      const updated = await apiFetch<IpAddress>(`/admin/ip-addresses/${id}`, {
        method: 'PUT', body: JSON.stringify({ status })
      })
      setAddresses(a => a.map(x => x.id === id ? updated : x))
    } catch (e: any) { alert(e.message) }
  }

  const deleteAddress = async (id: string) => {
    try {
      await apiFetch(`/admin/ip-addresses/${id}`, { method: 'DELETE' })
      setAddresses(a => a.filter(x => x.id !== id))
    } catch (e: any) { alert(e.message) }
  }

  const filtered = addresses.filter(a => !filter || a.address.includes(filter) || (a.serverId || '').includes(filter))
  const poolStats = addresses.reduce((acc, a) => { acc[a.status] = (acc[a.status] || 0) + 1; return acc }, {} as Record<string, number>)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">IP Manager</h1>
        <p className="text-zinc-500 text-sm mt-1">Manage IP pools and address allocations</p>
      </div>

      <div className="flex gap-2">
        {(['pools', 'addresses'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors capitalize ${tab === t ? 'bg-blue-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-white/[0.05]'}`}>
            {t === 'pools' ? `IP Pools (${pools.length})` : `Addresses${selectedPool ? ` (${addresses.length})` : ''}`}
          </button>
        ))}
      </div>

      {tab === 'pools' && (
        <div className="space-y-4">
          <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-5 space-y-4">
            <h2 className="text-white font-semibold text-sm">New IP Pool</h2>
            {err && <div className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">{err}</div>}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-zinc-500 text-xs mb-1 block">Pool Name</label>
                <input value={poolForm.name} onChange={e => setPoolForm(f => ({ ...f, name: e.target.value }))}
                  className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" placeholder="Main Pool" />
              </div>
              <div>
                <label className="text-zinc-500 text-xs mb-1 block">Gateway</label>
                <input value={poolForm.gateway} onChange={e => setPoolForm(f => ({ ...f, gateway: e.target.value }))}
                  className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" placeholder="192.168.1.1" />
              </div>
              <div>
                <label className="text-zinc-500 text-xs mb-1 block">Subnet (CIDR prefix)</label>
                <input value={poolForm.subnet} onChange={e => setPoolForm(f => ({ ...f, subnet: e.target.value }))}
                  className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" placeholder="24" />
              </div>
              <div>
                <label className="text-zinc-500 text-xs mb-1 block">DNS1</label>
                <input value={poolForm.dns1 || ''} onChange={e => setPoolForm(f => ({ ...f, dns1: e.target.value }))}
                  className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" placeholder="8.8.8.8" />
              </div>
              <div>
                <label className="text-zinc-500 text-xs mb-1 block">DNS2</label>
                <input value={poolForm.dns2 || ''} onChange={e => setPoolForm(f => ({ ...f, dns2: e.target.value }))}
                  className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" placeholder="8.8.4.4" />
              </div>
              <div>
                <label className="text-zinc-500 text-xs mb-1 block">Bridge</label>
                <input value={poolForm.bridge || ''} onChange={e => setPoolForm(f => ({ ...f, bridge: e.target.value }))}
                  className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" placeholder="vmbr0" />
              </div>
              <div>
                <label className="text-zinc-500 text-xs mb-1 block">Cluster (optional)</label>
                <select value={(poolForm as any).clusterId || ''} onChange={e => setPoolForm(f => ({ ...f, clusterId: e.target.value || undefined }))}
                  className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-zinc-300 text-sm focus:outline-none focus:border-blue-500">
                  <option value="">Any cluster</option>
                  {clusters.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className="flex items-end">
                <label className="flex items-center gap-2 text-zinc-400 text-sm cursor-pointer pb-2">
                  <input type="checkbox" checked={poolForm.isIpv6 || false} onChange={e => setPoolForm(f => ({ ...f, isIpv6: e.target.checked }))} className="rounded accent-blue-500" />
                  IPv6 Pool
                </label>
              </div>
            </div>
            <button onClick={createPool} disabled={saving}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm rounded-lg transition-colors">
              {saving ? 'Creating…' : 'Create Pool'}
            </button>
          </div>

          <div className="space-y-3">
            {pools.map(pool => {
              const addrs = addresses.filter(a => a.poolId === pool.id)
              return (
                <div key={pool.id} className="bg-white/[0.02] border border-white/[0.06] rounded-xl p-4 flex items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-white font-medium text-sm">{pool.name}</span>
                      {pool.isIpv6 && <span className="text-xs text-blue-400 bg-blue-500/10 border border-blue-500/20 px-1.5 py-0.5 rounded-full">IPv6</span>}
                      {!pool.isEnabled && <span className="text-xs text-zinc-600 bg-zinc-800 px-1.5 py-0.5 rounded-full">disabled</span>}
                    </div>
                    <div className="text-zinc-500 text-xs mt-0.5">
                      GW: {pool.gateway} /{pool.subnet} · DNS: {pool.dns1 || '—'} {pool.dns2 ? '/ ' + pool.dns2 : ''}
                      {pool.bridge ? ` · Bridge: ${pool.bridge}` : ''}
                    </div>
                  </div>
                  <div className="flex gap-3 text-xs text-zinc-500">
                    <span className="text-emerald-400">{addrs.filter(a => a.status === 'available').length} free</span>
                    <span className="text-violet-400">{addrs.filter(a => a.status === 'allocated').length} used</span>
                  </div>
                  <button onClick={() => { setSelectedPool(pool.id); setTab('addresses') }}
                    className="px-3 py-1.5 border border-white/10 text-zinc-400 hover:text-white text-xs rounded-lg transition-colors">
                    Manage IPs
                  </button>
                  <button onClick={() => deletePool(pool.id)}
                    className="text-red-500 hover:text-red-400 text-xs px-2 py-1.5 rounded hover:bg-red-500/10 transition-colors">
                    Delete
                  </button>
                </div>
              )
            })}
            {pools.length === 0 && <div className="py-8 text-center text-zinc-500 text-sm">No IP pools configured</div>}
          </div>
        </div>
      )}

      {tab === 'addresses' && (
        <div className="space-y-4">
          <div className="flex gap-3 items-end">
            <div className="flex-1">
              <label className="text-zinc-500 text-xs mb-1 block">Select Pool</label>
              <select value={selectedPool} onChange={e => setSelectedPool(e.target.value)}
                className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-zinc-300 text-sm focus:outline-none focus:border-blue-500">
                <option value="">Select pool…</option>
                {pools.map(p => <option key={p.id} value={p.id}>{p.name} ({p.gateway}/{p.subnet})</option>)}
              </select>
            </div>
          </div>

          {selectedPool && (
            <>
              <div className="grid grid-cols-4 gap-3">
                {[
                  { label: 'Total', value: addresses.length, color: 'text-white' },
                  { label: 'Available', value: poolStats.available || 0, color: 'text-emerald-400' },
                  { label: 'Allocated', value: poolStats.allocated || 0, color: 'text-violet-400' },
                  { label: 'Disabled', value: poolStats.disabled || 0, color: 'text-zinc-500' },
                ].map(s => (
                  <div key={s.label} className="bg-white/[0.02] border border-white/[0.06] rounded-xl p-3 text-center">
                    <div className={`text-lg font-bold ${s.color}`}>{s.value}</div>
                    <div className="text-zinc-600 text-xs">{s.label}</div>
                  </div>
                ))}
              </div>

              <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-4 space-y-3">
                <h3 className="text-white text-sm font-medium">Add IP Addresses</h3>
                <textarea value={addrInput} onChange={e => setAddrInput(e.target.value)} rows={4}
                  className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm font-mono focus:outline-none focus:border-blue-500 resize-none"
                  placeholder="192.168.1.10&#10;192.168.1.11&#10;192.168.1.12&#10;(one per line or comma-separated)" />
                <button onClick={addAddresses} disabled={saving || !addrInput.trim()}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm rounded-lg transition-colors">
                  {saving ? 'Adding…' : 'Add Addresses'}
                </button>
              </div>

              <div className="flex gap-3">
                <input value={filter} onChange={e => setFilter(e.target.value)} placeholder="Filter by IP or server…"
                  className="flex-1 bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-zinc-300 text-sm focus:outline-none focus:border-blue-500" />
              </div>

              {loading ? (
                <div className="py-8 text-center text-zinc-500">Loading…</div>
              ) : (
                <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl overflow-hidden">
                  <div className="grid grid-cols-12 gap-2 px-4 py-2 border-b border-white/[0.06] text-xs text-zinc-600 font-medium uppercase tracking-wide">
                    <div className="col-span-4">Address</div>
                    <div className="col-span-3">Status</div>
                    <div className="col-span-3">Server</div>
                    <div className="col-span-2 text-right">Actions</div>
                  </div>
                  <div className="divide-y divide-white/[0.03] max-h-[500px] overflow-y-auto">
                    {filtered.map(addr => (
                      <div key={addr.id} className="grid grid-cols-12 gap-2 px-4 py-2.5 hover:bg-white/[0.02] items-center">
                        <div className="col-span-4 text-zinc-300 font-mono text-sm">{addr.address}</div>
                        <div className="col-span-3">
                          <select value={addr.status} onChange={e => updateAddress(addr.id, e.target.value)}
                            className={`text-xs px-2 py-0.5 rounded border bg-transparent cursor-pointer focus:outline-none ${STATUS_COLOR[addr.status]}`}>
                            <option value="available">available</option>
                            <option value="reserved">reserved</option>
                            <option value="allocated">allocated</option>
                            <option value="disabled">disabled</option>
                          </select>
                        </div>
                        <div className="col-span-3 text-zinc-500 text-xs truncate">{addr.serverId ? addr.serverId.slice(-8) : '—'}</div>
                        <div className="col-span-2 flex justify-end">
                          <button onClick={() => deleteAddress(addr.id)} disabled={addr.status === 'allocated'}
                            className="text-red-500 hover:text-red-400 disabled:opacity-30 disabled:cursor-not-allowed text-xs transition-colors">
                            Delete
                          </button>
                        </div>
                      </div>
                    ))}
                    {filtered.length === 0 && <div className="py-8 text-center text-zinc-500 text-sm">No addresses found</div>}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  )
}
