import { useState, useEffect } from 'react'
import { api } from '../../lib/api'
import type { Server } from '../../lib/api'

export default function AdminServersPage() {
  const [servers, setServers] = useState<Server[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    api.admin.allServers().then(setServers).finally(() => setLoading(false))
  }, [])

  const filtered = servers.filter(s =>
    s.displayName.toLowerCase().includes(search.toLowerCase()) ||
    s.hostname.toLowerCase().includes(search.toLowerCase()) ||
    (s.primaryIpv4 || '').includes(search)
  )

  return (
    <div className="max-w-6xl mx-auto animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-white">All Servers</h1>
          <p className="text-zinc-500 text-sm mt-0.5">{servers.length} total servers</p>
        </div>
      </div>

      <div className="relative mb-4">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600">
          <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
        </svg>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search servers…"
          className="w-full bg-white/[0.04] border border-white/[0.06] rounded-lg pl-10 pr-4 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/40 transition-all" />
      </div>

      <div className="glass rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="skeleton h-14 rounded-lg" />)}</div>
        ) : !filtered.length ? (
          <div className="flex flex-col items-center justify-center py-20">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-10 h-10 text-zinc-700 mb-4">
              <rect x="2" y="2" width="20" height="8" rx="2" /><rect x="2" y="14" width="20" height="8" rx="2" />
            </svg>
            <p className="text-zinc-500 text-sm">{search ? 'No servers match your search' : 'No servers in the system'}</p>
          </div>
        ) : (
          <>
            <div className="hidden lg:grid grid-cols-[1fr_auto_auto_auto_auto_auto] gap-4 px-5 py-3 border-b border-white/[0.06] text-xs font-medium text-zinc-600 uppercase tracking-wider">
              <span>Server</span><span>Owner</span><span>Type</span><span>Resources</span><span>IP</span><span>Status</span>
            </div>
            <div className="divide-y divide-white/[0.04]">
              {filtered.map(server => (
                <div key={server.id} className="grid grid-cols-1 lg:grid-cols-[1fr_auto_auto_auto_auto_auto] gap-4 items-center px-5 py-3.5">
                  <div className="flex items-center gap-3">
                    <span className={`status-dot flex-shrink-0 ${server.isSuspended ? 'suspended' : server.status}`} />
                    <div>
                      <div className="text-white text-sm font-medium">{server.displayName}</div>
                      <div className="text-zinc-600 text-xs font-mono">{server.hostname}</div>
                    </div>
                  </div>
                  <span className="text-zinc-500 text-xs font-mono">{server.userId.slice(0, 8)}…</span>
                  <span className="text-xs text-zinc-500 uppercase font-mono">{server.virtType}</span>
                  <span className="text-xs text-zinc-400">{server.vcpuCores}c / {server.ramMb >= 1024 ? `${server.ramMb / 1024}G` : `${server.ramMb}M`}</span>
                  <span className="text-xs font-mono text-zinc-500">{server.primaryIpv4 || '—'}</span>
                  <StatusBadge status={server.isSuspended ? 'suspended' : server.status} />
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    running: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    stopped: 'bg-zinc-700/40 text-zinc-400 border-zinc-600/20',
    suspended: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    provisioning: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    failed: 'bg-red-500/10 text-red-400 border-red-500/20',
  }
  return (
    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border uppercase tracking-wide ${map[status] || map.stopped}`}>
      {status}
    </span>
  )
}
