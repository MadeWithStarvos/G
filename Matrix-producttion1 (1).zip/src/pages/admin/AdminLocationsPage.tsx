import { useState, useEffect } from 'react'
import { api } from '../../lib/api'
import type { Location, CreateLocationData } from '../../lib/api'

export default function AdminLocationsPage() {
  const [locations, setLocations] = useState<Location[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState('')
  const [form, setForm] = useState<CreateLocationData>({ name: '', shortCode: '', country: '', description: '' })

  useEffect(() => {
    api.admin.locations().then(setLocations).finally(() => setLoading(false))
  }, [])

  const set = (k: keyof CreateLocationData) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }))

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    try {
      const loc = await api.admin.createLocation(form)
      setLocations(l => [...l, loc])
      setShowForm(false)
      setForm({ name: '', shortCode: '', country: '', description: '' })
      setToast('Location added')
      setTimeout(() => setToast(''), 3000)
    } catch (e: any) {
      setToast(`Error: ${e.message}`)
      setTimeout(() => setToast(''), 4000)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-zinc-800 border border-white/10 text-white text-sm px-4 py-3 rounded-xl shadow-2xl animate-slide-up">{toast}</div>
      )}

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-white">Locations</h1>
          <p className="text-zinc-500 text-sm mt-0.5">{locations.length} location{locations.length !== 1 ? 's' : ''}</p>
        </div>
        <button onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-all glow-blue">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
          Add Location
        </button>
      </div>

      {showForm && (
        <div className="glass rounded-xl p-5 mb-6 animate-slide-up">
          <h3 className="text-white font-semibold text-sm mb-4">Add Location</h3>
          <form onSubmit={handleAdd} className="grid grid-cols-2 gap-4">
            {[
              { label: 'Location Name', key: 'name', placeholder: 'Frankfurt, Germany' },
              { label: 'Short Code', key: 'shortCode', placeholder: 'FRA' },
              { label: 'Country', key: 'country', placeholder: 'Germany' },
              { label: 'Description', key: 'description', placeholder: 'EU West datacenter' },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">{f.label}</label>
                <input type="text" value={(form as any)[f.key]} onChange={set(f.key as any)}
                  placeholder={f.placeholder} required={f.key !== 'description'}
                  className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60 transition-all" />
              </div>
            ))}
            <div className="col-span-2 flex gap-3 pt-2">
              <button type="submit" disabled={saving}
                className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-semibold px-5 py-2.5 rounded-lg transition-all flex items-center gap-2">
                {saving && <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
                {saving ? 'Adding…' : 'Add Location'}
              </button>
              <button type="button" onClick={() => setShowForm(false)}
                className="text-zinc-400 hover:text-white text-sm px-4 py-2.5 rounded-lg border border-white/[0.08] hover:border-white/20 transition-all">
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="glass rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 space-y-3">{[...Array(3)].map((_, i) => <div key={i} className="skeleton h-14 rounded-lg" />)}</div>
        ) : !locations.length ? (
          <div className="flex flex-col items-center justify-center py-20">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-10 h-10 text-zinc-700 mb-4">
              <circle cx="12" cy="12" r="10" /><line x1="2" y1="12" x2="22" y2="12" />
              <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
            </svg>
            <p className="text-zinc-500 text-sm">No locations added yet</p>
          </div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {locations.map(loc => (
              <div key={loc.id} className="flex items-center gap-4 px-5 py-4">
                <div className="w-10 h-7 rounded bg-white/[0.06] border border-white/[0.08] flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-[10px] font-bold font-mono">{loc.shortCode}</span>
                </div>
                <div className="flex-1">
                  <div className="text-white text-sm font-medium">{loc.name}</div>
                  <div className="text-zinc-500 text-xs">{loc.country}{loc.description ? ` · ${loc.description}` : ''}</div>
                </div>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border uppercase tracking-wide ${loc.isEnabled ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' : 'text-zinc-500 bg-zinc-700/30 border-zinc-600/20'}`}>
                  {loc.isEnabled ? 'Enabled' : 'Disabled'}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
