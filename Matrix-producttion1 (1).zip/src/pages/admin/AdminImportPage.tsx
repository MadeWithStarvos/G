import { useState, useEffect } from 'react'
import { apiFetch } from '../../lib/api'
import type { Cluster, Node, User } from '../../lib/api'

interface Candidate {
  vmid: number; name: string; type: string; node: string; status: string
  cpu?: number; mem?: number; maxmem?: number
}

export default function AdminImportPage() {
  const [clusters, setClusters] = useState<Cluster[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [nodes, setNodes] = useState<Node[]>([])
  const [clusterId, setClusterId] = useState('')
  const [candidates, setCandidates] = useState<Candidate[]>([])
  const [loading, setLoading] = useState(false)
  const [selected, setSelected] = useState<Set<number>>(new Set())
  const [form, setForm] = useState<Record<number, { userId: string; displayName: string; hostname: string; vcpuCores: string; ramMb: string; diskGb: string }>>({})
  const [importing, setImporting] = useState(false)
  const [results, setResults] = useState<{ vmid: number; ok: boolean; msg: string }[]>([])

  useEffect(() => {
    apiFetch<Cluster[]>('/admin/clusters').then(setClusters).catch(() => {})
    apiFetch<User[]>('/admin/users').then(setUsers).catch(() => {})
    apiFetch<Node[]>('/admin/nodes').then(setNodes).catch(() => {})
  }, [])

  const scan = async () => {
    if (!clusterId) return
    setLoading(true); setCandidates([]); setSelected(new Set()); setResults([])
    try {
      const data = await apiFetch<Candidate[]>(`/admin/import-candidates?clusterId=${clusterId}`)
      setCandidates(data)
    } catch (e: any) { alert(e.message) }
    setLoading(false)
  }

  const toggleSelect = (vmid: number, candidate: Candidate) => {
    const next = new Set(selected)
    if (next.has(vmid)) { next.delete(vmid) } else {
      next.add(vmid)
      if (!form[vmid]) {
        const nodeRec = nodes.find(n => n.name === candidate.node && n.clusterId === clusterId)
        setForm(f => ({ ...f, [vmid]: {
          userId: '', displayName: candidate.name || `vm-${vmid}`,
          hostname: candidate.name?.toLowerCase().replace(/[^a-z0-9-]/g, '-') || `vm-${vmid}`,
          vcpuCores: '1', ramMb: String(Math.round((candidate.maxmem || 512000000) / 1048576)),
          diskGb: '20',
        }}))
      }
    }
    setSelected(next)
  }

  const doImport = async () => {
    setImporting(true); setResults([])
    const res: typeof results = []
    for (const vmid of selected) {
      const c = candidates.find(x => x.vmid === vmid)
      const f = form[vmid]
      if (!c || !f || !f.userId) { res.push({ vmid, ok: false, msg: 'Missing user or data' }); continue }
      const nodeRec = nodes.find(n => n.name === c.node && n.clusterId === clusterId)
      try {
        await apiFetch('/admin/import-server', { method: 'POST', body: JSON.stringify({
          clusterId, nodeId: nodeRec?.id, vmid, virtType: c.type, displayName: f.displayName,
          hostname: f.hostname, userId: f.userId, vcpuCores: parseInt(f.vcpuCores),
          ramMb: parseInt(f.ramMb), diskGb: parseInt(f.diskGb),
        })})
        res.push({ vmid, ok: true, msg: 'Imported successfully' })
      } catch (e: any) { res.push({ vmid, ok: false, msg: e.message }) }
    }
    setResults(res)
    setImporting(false)
    if (res.every(r => r.ok)) { setCandidates([]); setSelected(new Set()) }
  }

  const clusterNodes = nodes.filter(n => n.clusterId === clusterId)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Import Existing VMs</h1>
        <p className="text-zinc-500 text-sm mt-1">Find unmanaged VMs/LXCs in Proxmox and assign them to panel users</p>
      </div>

      <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-5">
        <div className="flex gap-3 items-end">
          <div className="flex-1">
            <label className="text-zinc-400 text-xs mb-1 block">Proxmox Cluster</label>
            <select value={clusterId} onChange={e => setClusterId(e.target.value)}
              className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-zinc-300 text-sm focus:outline-none focus:border-blue-500">
              <option value="">Select cluster…</option>
              {clusters.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <button onClick={scan} disabled={!clusterId || loading}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm rounded-lg transition-colors">
            {loading ? 'Scanning…' : 'Scan for VMs'}
          </button>
        </div>
      </div>

      {results.length > 0 && (
        <div className="space-y-2">
          {results.map(r => (
            <div key={r.vmid} className={`px-4 py-3 rounded-lg border text-sm ${r.ok ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400'}`}>
              VMID {r.vmid}: {r.msg}
            </div>
          ))}
        </div>
      )}

      {candidates.length > 0 && (
        <>
          <div className="flex items-center justify-between">
            <p className="text-zinc-400 text-sm">{candidates.length} unmanaged VMs found — {selected.size} selected</p>
            <button onClick={doImport} disabled={selected.size === 0 || importing}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-sm rounded-lg transition-colors">
              {importing ? 'Importing…' : `Import ${selected.size} Selected`}
            </button>
          </div>

          <div className="space-y-3">
            {candidates.map(c => {
              const isSelected = selected.has(c.vmid)
              const f = form[c.vmid]
              return (
                <div key={c.vmid} className={`bg-white/[0.02] border rounded-xl overflow-hidden transition-colors ${isSelected ? 'border-blue-500/30' : 'border-white/[0.06]'}`}>
                  <div className="flex items-center gap-4 px-5 py-3">
                    <input type="checkbox" checked={isSelected} onChange={() => toggleSelect(c.vmid, c)} className="rounded accent-blue-500" />
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <span className={`text-xs px-2 py-0.5 rounded border ${c.type === 'qemu' ? 'text-blue-400 bg-blue-500/10 border-blue-500/20' : 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20'}`}>
                        {c.type === 'qemu' ? 'KVM' : 'LXC'}
                      </span>
                      <span className="text-white font-medium text-sm">{c.name || `VMID ${c.vmid}`}</span>
                      <span className="text-zinc-500 text-xs">#{c.vmid}</span>
                    </div>
                    <span className="text-zinc-500 text-xs">{c.node}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${c.status === 'running' ? 'text-emerald-400 bg-emerald-500/10' : 'text-zinc-500 bg-zinc-800'}`}>{c.status}</span>
                    {c.maxmem && <span className="text-zinc-600 text-xs">{Math.round(c.maxmem / 1073741824)}GB RAM</span>}
                  </div>
                  {isSelected && f && (
                    <div className="px-5 pb-4 border-t border-white/[0.06] pt-3 grid grid-cols-2 sm:grid-cols-3 gap-3">
                      <div className="sm:col-span-2">
                        <label className="text-zinc-500 text-xs mb-1 block">Assign to User</label>
                        <select value={f.userId} onChange={e => setForm(fm => ({ ...fm, [c.vmid]: { ...f, userId: e.target.value } }))}
                          className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-zinc-300 text-sm focus:outline-none focus:border-blue-500">
                          <option value="">Select user…</option>
                          {users.map(u => <option key={u.id} value={u.id}>{u.email} ({u.username})</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="text-zinc-500 text-xs mb-1 block">Display Name</label>
                        <input value={f.displayName} onChange={e => setForm(fm => ({ ...fm, [c.vmid]: { ...f, displayName: e.target.value } }))}
                          className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" />
                      </div>
                      <div>
                        <label className="text-zinc-500 text-xs mb-1 block">Hostname</label>
                        <input value={f.hostname} onChange={e => setForm(fm => ({ ...fm, [c.vmid]: { ...f, hostname: e.target.value } }))}
                          className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" />
                      </div>
                      <div>
                        <label className="text-zinc-500 text-xs mb-1 block">vCPU</label>
                        <input type="number" value={f.vcpuCores} onChange={e => setForm(fm => ({ ...fm, [c.vmid]: { ...f, vcpuCores: e.target.value } }))}
                          className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" />
                      </div>
                      <div>
                        <label className="text-zinc-500 text-xs mb-1 block">RAM (MB)</label>
                        <input type="number" value={f.ramMb} onChange={e => setForm(fm => ({ ...fm, [c.vmid]: { ...f, ramMb: e.target.value } }))}
                          className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" />
                      </div>
                      <div>
                        <label className="text-zinc-500 text-xs mb-1 block">Disk (GB)</label>
                        <input type="number" value={f.diskGb} onChange={e => setForm(fm => ({ ...fm, [c.vmid]: { ...f, diskGb: e.target.value } }))}
                          className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" />
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </>
      )}

      {!loading && candidates.length === 0 && clusterId && (
        <div className="py-12 text-center text-zinc-500">Scan a cluster to find unmanaged VMs</div>
      )}
    </div>
  )
}
