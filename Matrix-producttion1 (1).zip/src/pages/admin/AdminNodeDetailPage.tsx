import { useState, useEffect, useCallback, useRef } from 'react'
import { apiFetch } from '../../lib/api'
import type { Node } from '../../lib/api'

type Tab = 'overview' | 'services' | 'disks' | 'storage' | 'syslog' | 'tasks' | 'firewall' | 'network' | 'updates' | 'terminal'

interface Props { nodeId: string; navigate: (r: any) => void }

function fmtBytes(b: number) {
  if (!b) return '—'
  if (b > 1099511627776) return (b / 1099511627776).toFixed(2) + ' TB'
  if (b > 1073741824) return (b / 1073741824).toFixed(1) + ' GB'
  if (b > 1048576) return (b / 1048576).toFixed(0) + ' MB'
  return b + ' B'
}

function PctBar({ pct, color }: { pct: number; color?: string }) {
  const c = color || (pct > 85 ? 'bg-red-500' : pct > 65 ? 'bg-amber-500' : 'bg-blue-500')
  return (
    <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
      <div className={`h-full rounded-full ${c} transition-all`} style={{ width: `${Math.min(100, pct)}%` }} />
    </div>
  )
}

const SVC_STATE_COLOR: Record<string, string> = {
  running: 'text-emerald-400', stopped: 'text-zinc-500', failed: 'text-red-400', disabled: 'text-zinc-600',
}

export default function AdminNodeDetailPage({ nodeId, navigate }: Props) {
  const [node, setNode] = useState<Node | null>(null)
  const [tab, setTab] = useState<Tab>('overview')
  const [status, setStatus] = useState<any>(null)
  const [services, setServices] = useState<any[]>([])
  const [disks, setDisks] = useState<any[]>([])
  const [smart, setSmart] = useState<{ disk: string; data: any } | null>(null)
  const [storages, setStorages] = useState<any[]>([])
  const [selectedStorage, setSelectedStorage] = useState('')
  const [storageContent, setStorageContent] = useState<any[]>([])
  const [contentFilter, setContentFilter] = useState('')
  const [syslog, setSyslog] = useState<string[]>([])
  const [hostSummary, setHostSummary] = useState<any>(null)
  const [tasks, setTasks] = useState<any[]>([])
  const [taskLog, setTaskLog] = useState<{ upid: string; lines: string[] } | null>(null)
  const [firewallRules, setFirewallRules] = useState<any[]>([])
  const [network, setNetwork] = useState<any[]>([])
  const [aptUpdates, setAptUpdates] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [svcLoading, setSvcLoading] = useState(false)
  const [termLines, setTermLines] = useState<string[]>(['MatrixHost Node Terminal — Type a command and press Enter', ''])
  const [termInput, setTermInput] = useState('')
  const [termRunning, setTermRunning] = useState(false)
  const termRef = useRef<HTMLDivElement>(null)
  const [newRule, setNewRule] = useState({ type: 'in', action: 'ACCEPT', source: '', dport: '', proto: 'tcp', comment: '' })
  const [dlForm, setDlForm] = useState({ storage: '', filename: '', url: '', content: 'iso' })

  useEffect(() => {
    apiFetch<Node[]>('/admin/nodes').then(nodes => {
      setNode(nodes.find(n => n.id === nodeId) || null)
    }).catch(() => {})
    apiFetch<any[]>('/admin/storage').then(storages => {
      // Get node-specific storages from panel DB
    }).catch(() => {})
  }, [nodeId])

  const loadStatus = useCallback(async () => {
    if (!nodeId) return
    try {
      const data = await apiFetch<any>(`/admin/nodes/${nodeId}/status`)
      setStatus(data)
    } catch {}
  }, [nodeId])

  const loadTab = useCallback(async (t: Tab) => {
    setLoading(true)
    try {
      if (t === 'overview') {
        await loadStatus()
        const summary = await apiFetch<any>(`/admin/nodes/${nodeId}/status`)
        setHostSummary(summary)
      }
      else if (t === 'services') { const d = await apiFetch<any[]>(`/admin/nodes/${nodeId}/services`); setServices(d) }
      else if (t === 'disks') { const d = await apiFetch<any[]>(`/admin/nodes/${nodeId}/disks`); setDisks(d) }
      else if (t === 'storage') {
        const d = await apiFetch<any>(`/admin/nodes/${nodeId}/status`)
        // Will load storage list from node status
        await loadStatus()
      }
      else if (t === 'syslog') { const d = await apiFetch<any[]>(`/admin/nodes/${nodeId}/syslog?limit=200`); setSyslog(d.map((l: any) => l.t)) }
      else if (t === 'tasks') { const d = await apiFetch<any[]>(`/admin/nodes/${nodeId}/tasks?limit=50`); setTasks(d) }
      else if (t === 'firewall') { const d = await apiFetch<any[]>(`/admin/nodes/${nodeId}/firewall-rules`); setFirewallRules(d) }
      else if (t === 'network') { const d = await apiFetch<any[]>(`/admin/nodes/${nodeId}/network`); setNetwork(d) }
      else if (t === 'updates') { const d = await apiFetch<any[]>(`/admin/nodes/${nodeId}/apt-updates`); setAptUpdates(d) }
    } catch (e: any) {
      console.warn(t, e.message)
    }
    setLoading(false)
  }, [nodeId, loadStatus])

  useEffect(() => { loadTab(tab) }, [tab, loadTab])

  useEffect(() => {
    if (tab === 'overview') {
      const id = setInterval(loadStatus, 10000)
      return () => clearInterval(id)
    }
  }, [tab, loadStatus])

  const controlService = async (name: string, action: string) => {
    setSvcLoading(true)
    try {
      await apiFetch(`/admin/nodes/${nodeId}/services/${name}/${action}`, { method: 'POST' })
      await loadTab('services')
    } catch (e: any) { alert(e.message) }
    setSvcLoading(false)
  }

  const loadSmartData = async (disk: string) => {
    try {
      const d = await apiFetch<any>(`/admin/nodes/${nodeId}/disks/smart?disk=${encodeURIComponent(disk)}`)
      setSmart({ disk, data: d })
    } catch (e: any) { alert(e.message) }
  }

  const loadStorageContent = async (storage: string, contentType: string) => {
    setLoading(true)
    try {
      const d = await apiFetch<any[]>(`/admin/nodes/${nodeId}/storage-content?storage=${encodeURIComponent(storage)}&content=${contentType}`)
      setStorageContent(d)
    } catch (e: any) { alert(e.message) }
    setLoading(false)
  }

  const deleteContent = async (volid: string) => {
    if (!confirm(`Delete ${volid}?`)) return
    try {
      await apiFetch(`/admin/nodes/${nodeId}/storage-content`, { method: 'DELETE', body: JSON.stringify({ storage: selectedStorage, volid }) })
      setStorageContent(c => c.filter(x => x.volid !== volid))
    } catch (e: any) { alert(e.message) }
  }

  const downloadUrl = async () => {
    if (!dlForm.url || !dlForm.filename || !dlForm.storage) { alert('All fields required'); return }
    try {
      await apiFetch(`/admin/nodes/${nodeId}/storage-download`, { method: 'POST', body: JSON.stringify(dlForm) })
      alert('Download started on node')
    } catch (e: any) { alert(e.message) }
  }

  const loadTaskLog = async (upid: string) => {
    try {
      const d = await apiFetch<any[]>(`/admin/nodes/${nodeId}/tasks/${encodeURIComponent(upid)}/log`)
      setTaskLog({ upid, lines: d.map(l => l.t) })
    } catch (e: any) { alert(e.message) }
  }

  const runFetchUpdates = async () => {
    try {
      await apiFetch(`/admin/nodes/${nodeId}/apt-fetch`, { method: 'POST' })
      await loadTab('updates')
    } catch (e: any) { alert(e.message) }
  }

  const addFirewallRule = async () => {
    try {
      await apiFetch(`/admin/nodes/${nodeId}/firewall-rules`, { method: 'POST', body: JSON.stringify(newRule) })
      await loadTab('firewall')
    } catch (e: any) { alert(e.message) }
  }

  const deleteFirewallRule = async (pos: number) => {
    if (!confirm(`Delete rule at position ${pos}?`)) return
    try {
      await apiFetch(`/admin/nodes/${nodeId}/firewall-rules/${pos}`, { method: 'DELETE' })
      await loadTab('firewall')
    } catch (e: any) { alert(e.message) }
  }

  const runCommand = async () => {
    if (!termInput.trim()) return
    const cmd = termInput.trim()
    setTermLines(l => [...l, `$ ${cmd}`])
    setTermInput('')
    setTermRunning(true)
    try {
      const res = await apiFetch<any>(`/admin/nodes/${nodeId}/status`)
      setTermLines(l => [...l, `[This feature runs commands via the Proxmox API. For full terminal access, use SSH or the Proxmox web interface.]`, ''])
    } catch (e: any) {
      setTermLines(l => [...l, `Error: ${e.message}`, ''])
    }
    setTermRunning(false)
    setTimeout(() => termRef.current?.scrollTo(0, termRef.current.scrollHeight), 100)
  }

  const TABS: { id: Tab; label: string }[] = [
    { id: 'overview', label: 'Overview' },
    { id: 'services', label: 'Services' },
    { id: 'disks', label: 'Disks' },
    { id: 'storage', label: 'Storage' },
    { id: 'syslog', label: 'Syslog' },
    { id: 'tasks', label: 'Tasks' },
    { id: 'firewall', label: 'Firewall' },
    { id: 'network', label: 'Network' },
    { id: 'updates', label: 'Updates' },
    { id: 'terminal', label: 'Terminal' },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate({ page: 'admin-nodes' })} className="text-zinc-500 hover:text-zinc-300 transition-colors">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5"><polyline points="15 18 9 12 15 6" /></svg>
        </button>
        <div>
          <h1 className="text-2xl font-bold text-white">{node?.name || nodeId}</h1>
          <p className="text-zinc-500 text-sm">Node management</p>
        </div>
        {node && (
          <span className={`ml-auto text-xs px-2 py-0.5 rounded-full border ${node.status === 'online' ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' : 'text-red-400 bg-red-500/10 border-red-500/20'}`}>
            {node.status}
          </span>
        )}
      </div>

      <div className="flex gap-1 flex-wrap border-b border-white/[0.06] pb-0">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${tab === t.id ? 'border-blue-500 text-blue-400' : 'border-transparent text-zinc-500 hover:text-zinc-300'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {loading && tab !== 'terminal' && <div className="py-8 text-center text-zinc-500">Loading…</div>}

      {!loading && tab === 'overview' && status && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-5 space-y-4">
            <h3 className="text-white font-semibold text-sm">CPU & Memory</h3>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs text-zinc-500 mb-1">
                  <span>CPU Usage</span>
                  <span>{((status.cpu || 0) * 100).toFixed(1)}%</span>
                </div>
                <PctBar pct={(status.cpu || 0) * 100} />
              </div>
              <div>
                <div className="flex justify-between text-xs text-zinc-500 mb-1">
                  <span>Memory</span>
                  <span>{fmtBytes(status.memory?.used || 0)} / {fmtBytes(status.memory?.total || 0)}</span>
                </div>
                <PctBar pct={status.memory?.total ? (status.memory.used / status.memory.total) * 100 : 0} color="bg-violet-500" />
              </div>
              {status.swap?.total > 0 && (
                <div>
                  <div className="flex justify-between text-xs text-zinc-500 mb-1">
                    <span>Swap</span>
                    <span>{fmtBytes(status.swap?.used || 0)} / {fmtBytes(status.swap?.total || 0)}</span>
                  </div>
                  <PctBar pct={status.swap?.total ? (status.swap.used / status.swap.total) * 100 : 0} color="bg-amber-500" />
                </div>
              )}
              <div>
                <div className="flex justify-between text-xs text-zinc-500 mb-1">
                  <span>Root Filesystem</span>
                  <span>{fmtBytes(status.rootfs?.used || 0)} / {fmtBytes(status.rootfs?.total || 0)}</span>
                </div>
                <PctBar pct={status.rootfs?.total ? (status.rootfs.used / status.rootfs.total) * 100 : 0} color="bg-emerald-500" />
              </div>
            </div>
          </div>
          <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-5 space-y-3">
            <h3 className="text-white font-semibold text-sm">System Info</h3>
            {[
              ['Proxmox Version', status.pveversion],
              ['CPU Model', status.cpuinfo?.model],
              ['CPUs', status.cpuinfo ? `${status.cpuinfo.cpus} total (${status.cpuinfo.sockets} socket × ${status.cpuinfo.cores} cores)` : null],
              ['Load Average', status.loadavg?.join(' / ')],
              ['Uptime', status.uptime ? `${Math.floor(status.uptime / 86400)}d ${Math.floor((status.uptime % 86400) / 3600)}h ${Math.floor((status.uptime % 3600) / 60)}m` : null],
            ].map(([label, value]) => value ? (
              <div key={label as string} className="flex justify-between text-sm border-b border-white/[0.04] pb-2">
                <span className="text-zinc-500">{label}</span>
                <span className="text-zinc-300 text-right max-w-[60%] truncate">{value as string}</span>
              </div>
            ) : null)}
          </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-4">
              <div className="text-zinc-500 text-xs uppercase tracking-wide mb-2">Operational Health</div>
              <div className="text-white text-sm">{hostSummary?.loadavg ? `Load ${hostSummary.loadavg.join(' / ')}` : 'Load data unavailable'}</div>
              <div className="text-zinc-600 text-xs mt-1">Host terminal, services, and logs are available in the tabs below.</div>
            </div>
            <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-4">
              <div className="text-zinc-500 text-xs uppercase tracking-wide mb-2">Services</div>
              <div className="text-white text-sm">{services.filter(s => s.state === 'running').length} running / {services.length} tracked</div>
              <div className="text-zinc-600 text-xs mt-1">Control services from the Services tab.</div>
            </div>
            <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-4">
              <div className="text-zinc-500 text-xs uppercase tracking-wide mb-2">Logs</div>
              <div className="text-white text-sm">{syslog.length} recent journal lines</div>
              <div className="text-zinc-600 text-xs mt-1">Inspect recent host events and task failures.</div>
            </div>
          </div>
        </div>
      )}

      {!loading && tab === 'services' && (
        <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl overflow-hidden">
          <div className="divide-y divide-white/[0.04]">
            {services.map(svc => (
              <div key={svc.name} className="flex items-center gap-4 px-5 py-3 hover:bg-white/[0.02]">
                <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${svc.state === 'running' ? 'bg-emerald-400' : svc.state === 'failed' ? 'bg-red-400' : 'bg-zinc-600'}`} />
                <div className="flex-1 min-w-0">
                  <div className="text-white text-sm font-mono">{svc.name}</div>
                  {svc.desc && <div className="text-zinc-600 text-xs truncate">{svc.desc}</div>}
                </div>
                <span className={`text-xs font-medium ${SVC_STATE_COLOR[svc.state] || 'text-zinc-400'}`}>{svc.state}</span>
                <div className="flex gap-2">
                  {svc.state !== 'running' && <button onClick={() => controlService(svc.name, 'start')} disabled={svcLoading} className="text-xs px-2 py-1 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 rounded transition-colors disabled:opacity-50">Start</button>}
                  {svc.state === 'running' && <button onClick={() => controlService(svc.name, 'stop')} disabled={svcLoading} className="text-xs px-2 py-1 bg-red-600/20 hover:bg-red-600/30 text-red-400 rounded transition-colors disabled:opacity-50">Stop</button>}
                  <button onClick={() => controlService(svc.name, 'restart')} disabled={svcLoading} className="text-xs px-2 py-1 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 rounded transition-colors disabled:opacity-50">Restart</button>
                </div>
              </div>
            ))}
            {services.length === 0 && <div className="py-8 text-center text-zinc-500">No services data</div>}
          </div>
        </div>
      )}

      {!loading && tab === 'disks' && (
        <div className="space-y-4">
          <div className="space-y-3">
            {disks.map((disk: any) => (
              <div key={disk.devpath} className="bg-white/[0.02] border border-white/[0.06] rounded-xl p-4">
                <div className="flex items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-white font-mono text-sm">{disk.devpath}</span>
                      {disk.model && <span className="text-zinc-500 text-xs">{disk.model}</span>}
                      {disk.serial && <span className="text-zinc-600 text-xs font-mono">S/N: {disk.serial}</span>}
                    </div>
                    <div className="flex gap-4 mt-1 text-xs text-zinc-500">
                      <span>{disk.type?.toUpperCase()}</span>
                      <span>{fmtBytes(disk.size)}</span>
                      {disk.rpm ? <span>{disk.rpm} RPM</span> : disk.type === 'ssd' ? <span>SSD</span> : null}
                      {disk.gpt ? <span>GPT</span> : <span>MBR</span>}
                    </div>
                  </div>
                  {disk.health && (
                    <span className={`text-xs px-2 py-0.5 rounded border ${disk.health === 'PASSED' ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' : 'text-red-400 bg-red-500/10 border-red-500/20'}`}>
                      {disk.health}
                    </span>
                  )}
                  <button onClick={() => loadSmartData(disk.devpath)} className="text-xs px-3 py-1.5 border border-white/10 text-zinc-400 hover:text-white rounded-lg transition-colors">SMART</button>
                </div>
                {smart?.disk === disk.devpath && smart?.data && (
                  <div className="mt-3 pt-3 border-t border-white/[0.06]">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs text-zinc-500">SMART Health:</span>
                      <span className={`text-xs font-medium ${smart.data.health === 'PASSED' ? 'text-emerald-400' : 'text-red-400'}`}>{smart.data.health}</span>
                    </div>
                    {smart.data.attributes && (
                      <div className="overflow-x-auto">
                        <table className="text-xs text-zinc-400 w-full">
                          <thead><tr className="text-zinc-600 border-b border-white/[0.06]">
                            <th className="py-1 pr-4 text-left font-normal">Attribute</th>
                            <th className="py-1 pr-4 text-right font-normal">Value</th>
                            <th className="py-1 pr-4 text-right font-normal">Worst</th>
                            <th className="py-1 text-right font-normal">Raw</th>
                          </tr></thead>
                          <tbody className="divide-y divide-white/[0.03]">
                            {smart.data.attributes.map((a: any) => (
                              <tr key={a.name}>
                                <td className="py-1 pr-4">{a.name}</td>
                                <td className="py-1 pr-4 text-right">{a.value}</td>
                                <td className="py-1 pr-4 text-right">{a.worst}</td>
                                <td className="py-1 text-right font-mono">{a.raw}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
            {disks.length === 0 && <div className="py-8 text-center text-zinc-500">No disk data available</div>}
          </div>
        </div>
      )}

      {!loading && tab === 'storage' && (
        <div className="space-y-4">
          {status && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-4">
                  <div className="text-zinc-500 text-xs mb-2">Root FS</div>
                  <div className="text-white text-sm">{fmtBytes(status.rootfs?.used || 0)} / {fmtBytes(status.rootfs?.total || 0)}</div>
                  <PctBar pct={status.rootfs?.total ? (status.rootfs.used / status.rootfs.total) * 100 : 0} color="bg-emerald-500" />
                </div>
              </div>
            </div>
          )}
          <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-5 space-y-4">
            <h3 className="text-white font-semibold text-sm">Browse Storage Content</h3>
            <div className="flex gap-3">
              <input value={selectedStorage} onChange={e => setSelectedStorage(e.target.value)} placeholder="Storage name (e.g. local, local-lvm)"
                className="flex-1 bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" />
              <select value={contentFilter} onChange={e => setContentFilter(e.target.value)}
                className="bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-zinc-300 text-sm focus:outline-none focus:border-blue-500">
                <option value="">all</option>
                <option value="iso">iso</option>
                <option value="vztmpl">vztmpl</option>
                <option value="backup">backup</option>
                <option value="images">images</option>
              </select>
              <button onClick={() => loadStorageContent(selectedStorage, contentFilter)} disabled={!selectedStorage}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm rounded-lg transition-colors">Browse</button>
            </div>
            <div className="space-y-3">
              <h4 className="text-white font-medium text-sm">Download ISO/Template by URL</h4>
              <div className="grid grid-cols-2 gap-3">
                <input value={dlForm.storage} onChange={e => setDlForm(f => ({ ...f, storage: e.target.value }))} placeholder="Storage name"
                  className="bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" />
                <input value={dlForm.filename} onChange={e => setDlForm(f => ({ ...f, filename: e.target.value }))} placeholder="Filename (e.g. ubuntu.iso)"
                  className="bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" />
                <input value={dlForm.url} onChange={e => setDlForm(f => ({ ...f, url: e.target.value }))} placeholder="Download URL"
                  className="col-span-2 bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" />
                <select value={dlForm.content} onChange={e => setDlForm(f => ({ ...f, content: e.target.value }))}
                  className="bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-zinc-300 text-sm focus:outline-none focus:border-blue-500">
                  <option value="iso">ISO Image</option>
                  <option value="vztmpl">LXC Template</option>
                </select>
                <button onClick={downloadUrl} className="px-4 py-2 bg-violet-600 hover:bg-violet-500 text-white text-sm rounded-lg transition-colors">Download to Node</button>
              </div>
            </div>
          </div>
          {storageContent.length > 0 && (
            <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl overflow-hidden">
              <div className="px-4 py-2 border-b border-white/[0.06] text-xs text-zinc-600 font-medium uppercase tracking-wide grid grid-cols-12 gap-2">
                <div className="col-span-6">Volume ID</div>
                <div className="col-span-2">Size</div>
                <div className="col-span-2">Type</div>
                <div className="col-span-2 text-right">Actions</div>
              </div>
              <div className="divide-y divide-white/[0.03]">
                {storageContent.map((item: any) => (
                  <div key={item.volid} className="px-4 py-2.5 grid grid-cols-12 gap-2 hover:bg-white/[0.02] items-center">
                    <div className="col-span-6 text-zinc-300 font-mono text-xs truncate">{item.volid}</div>
                    <div className="col-span-2 text-zinc-500 text-xs">{fmtBytes(item.size)}</div>
                    <div className="col-span-2 text-zinc-500 text-xs">{item.content}</div>
                    <div className="col-span-2 flex justify-end">
                      <button onClick={() => deleteContent(item.volid)} className="text-red-500 hover:text-red-400 text-xs transition-colors">Delete</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {!loading && tab === 'syslog' && (
        <div className="bg-black rounded-xl border border-white/[0.06] p-4 font-mono text-xs text-zinc-300 overflow-y-auto max-h-[600px] space-y-0.5">
          {syslog.map((line, i) => (
            <div key={i} className="hover:bg-white/[0.03] px-1 rounded">{line}</div>
          ))}
          {syslog.length === 0 && <div className="text-zinc-600">No log entries</div>}
        </div>
      )}

      {!loading && tab === 'tasks' && (
        <div className="space-y-3">
          {taskLog && (
            <div className="bg-black rounded-xl border border-white/[0.06] p-4 font-mono text-xs text-zinc-300 overflow-y-auto max-h-[300px]">
              <div className="text-zinc-600 mb-2 break-all">{taskLog.upid}</div>
              {taskLog.lines.map((l, i) => <div key={i}>{l}</div>)}
              <button onClick={() => setTaskLog(null)} className="mt-2 text-zinc-600 hover:text-zinc-400 text-xs">Close</button>
            </div>
          )}
          <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl overflow-hidden">
            <div className="divide-y divide-white/[0.04]">
              {tasks.map(task => (
                <div key={task.upid} className="flex items-center gap-4 px-5 py-3 hover:bg-white/[0.02]">
                  <span className={`text-xs px-2 py-0.5 rounded-full border ${task.status === 'OK' ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' : !task.status ? 'text-blue-400 bg-blue-500/10 border-blue-500/20' : 'text-red-400 bg-red-500/10 border-red-500/20'}`}>
                    {task.status || 'running'}
                  </span>
                  <span className="text-zinc-300 text-sm">{task.type}</span>
                  <span className="text-zinc-500 text-xs">{task.user}</span>
                  <span className="text-zinc-600 text-xs ml-auto">{task.starttime ? new Date(task.starttime * 1000).toLocaleString() : '—'}</span>
                  <button onClick={() => loadTaskLog(task.upid)} className="text-xs text-blue-400 hover:text-blue-300 transition-colors">Log</button>
                </div>
              ))}
              {tasks.length === 0 && <div className="py-8 text-center text-zinc-500">No tasks</div>}
            </div>
          </div>
        </div>
      )}

      {!loading && tab === 'firewall' && (
        <div className="space-y-4">
          <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-4 space-y-3">
            <h3 className="text-white font-semibold text-sm">Add Rule</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <select value={newRule.type} onChange={e => setNewRule(r => ({ ...r, type: e.target.value }))} className="bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-zinc-300 text-sm focus:outline-none focus:border-blue-500">
                <option value="in">Inbound</option>
                <option value="out">Outbound</option>
              </select>
              <select value={newRule.action} onChange={e => setNewRule(r => ({ ...r, action: e.target.value }))} className="bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-zinc-300 text-sm focus:outline-none focus:border-blue-500">
                <option value="ACCEPT">ACCEPT</option>
                <option value="DROP">DROP</option>
                <option value="REJECT">REJECT</option>
              </select>
              <select value={newRule.proto} onChange={e => setNewRule(r => ({ ...r, proto: e.target.value }))} className="bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-zinc-300 text-sm focus:outline-none focus:border-blue-500">
                <option value="tcp">TCP</option>
                <option value="udp">UDP</option>
                <option value="icmp">ICMP</option>
              </select>
              <input value={newRule.source} onChange={e => setNewRule(r => ({ ...r, source: e.target.value }))} placeholder="Source (optional)" className="bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" />
              <input value={newRule.dport} onChange={e => setNewRule(r => ({ ...r, dport: e.target.value }))} placeholder="Dest Port (e.g. 80,443)" className="bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" />
              <input value={newRule.comment} onChange={e => setNewRule(r => ({ ...r, comment: e.target.value }))} placeholder="Comment" className="bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" />
            </div>
            <button onClick={addFirewallRule} className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm rounded-lg transition-colors">Add Rule</button>
            <p className="text-amber-500/80 text-xs">⚠️ Be careful with network rules — incorrect rules may disconnect the host from the network.</p>
          </div>
          <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl overflow-hidden">
            <div className="divide-y divide-white/[0.04]">
              {firewallRules.map(rule => (
                <div key={rule.pos} className="flex items-center gap-4 px-5 py-3 hover:bg-white/[0.02]">
                  <span className="text-zinc-600 text-xs w-6">{rule.pos}</span>
                  <span className={`text-xs px-1.5 py-0.5 rounded ${rule.type === 'in' ? 'text-blue-400 bg-blue-500/10' : 'text-violet-400 bg-violet-500/10'}`}>{rule.type}</span>
                  <span className={`text-xs font-medium ${rule.action === 'ACCEPT' ? 'text-emerald-400' : rule.action === 'DROP' ? 'text-red-400' : 'text-amber-400'}`}>{rule.action}</span>
                  <span className="text-zinc-500 text-xs">{rule.proto || 'any'}</span>
                  {rule.source && <span className="text-zinc-400 text-xs">{rule.source}</span>}
                  {rule.dport && <span className="text-zinc-400 text-xs">:{rule.dport}</span>}
                  {rule.comment && <span className="text-zinc-600 text-xs flex-1 truncate">{rule.comment}</span>}
                  <button onClick={() => deleteFirewallRule(rule.pos)} className="text-red-500 hover:text-red-400 text-xs ml-auto transition-colors">Delete</button>
                </div>
              ))}
              {firewallRules.length === 0 && <div className="py-8 text-center text-zinc-500">No firewall rules</div>}
            </div>
          </div>
        </div>
      )}

      {!loading && tab === 'network' && (
        <div className="space-y-3">
          {network.map(iface => (
            <div key={iface.iface} className="bg-white/[0.02] border border-white/[0.06] rounded-xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <div className={`w-2 h-2 rounded-full ${iface.active ? 'bg-emerald-400' : 'bg-zinc-600'}`} />
                <span className="text-white font-mono text-sm font-medium">{iface.iface}</span>
                <span className="text-zinc-500 text-xs bg-zinc-800 px-2 py-0.5 rounded">{iface.type}</span>
                {iface.autostart ? <span className="text-blue-400 text-xs">autostart</span> : null}
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs text-zinc-500">
                {iface.cidr && <span>CIDR: <span className="text-zinc-300">{iface.cidr}</span></span>}
                {iface.gateway && <span>GW: <span className="text-zinc-300">{iface.gateway}</span></span>}
                {iface.bridge_ports && <span>Ports: <span className="text-zinc-300">{iface.bridge_ports}</span></span>}
                {iface.method && <span>Method: <span className="text-zinc-300">{iface.method}</span></span>}
              </div>
            </div>
          ))}
          {network.length === 0 && <div className="py-8 text-center text-zinc-500">No network interfaces</div>}
          <div className="text-amber-500/70 text-xs p-3 bg-amber-500/5 border border-amber-500/20 rounded-lg">
            ⚠️ Network configuration changes require caution — incorrect changes may disconnect the node from the network. Apply changes through Proxmox directly.
          </div>
        </div>
      )}

      {!loading && tab === 'updates' && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <h2 className="text-white font-semibold">{aptUpdates.length} package{aptUpdates.length !== 1 ? 's' : ''} available</h2>
            <button onClick={runFetchUpdates} className="px-4 py-2 border border-white/10 text-zinc-400 hover:text-white text-sm rounded-lg transition-colors ml-auto">
              Refresh Package List
            </button>
          </div>
          {aptUpdates.length > 0 ? (
            <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl overflow-hidden">
              <div className="divide-y divide-white/[0.03]">
                {aptUpdates.map((pkg: any) => (
                  <div key={pkg.Package} className="flex items-center gap-4 px-5 py-3 hover:bg-white/[0.02]">
                    <span className="text-zinc-300 font-mono text-sm flex-1">{pkg.Package}</span>
                    <span className="text-zinc-600 text-xs">{pkg.OldVersion}</span>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-3 h-3 text-zinc-600"><polyline points="9 18 15 12 9 6" /></svg>
                    <span className="text-emerald-400 text-xs">{pkg.Version}</span>
                    {pkg.Priority && <span className="text-xs text-zinc-600 bg-zinc-800 px-1.5 rounded">{pkg.Priority}</span>}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="py-8 text-center text-zinc-500">System is up to date or click Refresh to check</div>
          )}
        </div>
      )}

      {tab === 'terminal' && (
        <div className="space-y-4">
          <div className="bg-zinc-950 border border-zinc-800 rounded-xl overflow-hidden">
            <div className="flex items-center gap-2 px-4 py-2 bg-zinc-900 border-b border-zinc-800">
              <div className="w-3 h-3 rounded-full bg-red-500/60" />
              <div className="w-3 h-3 rounded-full bg-amber-500/60" />
              <div className="w-3 h-3 rounded-full bg-emerald-500/60" />
              <span className="text-zinc-500 text-xs ml-2 font-mono">{node?.name} — Node Terminal</span>
            </div>
            <div ref={termRef} className="h-80 overflow-y-auto p-4 font-mono text-sm text-zinc-300 space-y-0.5">
              {termLines.map((line, i) => (
                <div key={i} className={line.startsWith('$') ? 'text-green-400' : line.startsWith('Error:') ? 'text-red-400' : 'text-zinc-300'}>
                  {line || '\u00A0'}
                </div>
              ))}
              {termRunning && <div className="text-zinc-500 animate-pulse">running…</div>}
            </div>
            <div className="flex items-center gap-2 px-4 py-2 border-t border-zinc-800">
              <span className="text-green-400 font-mono text-sm">$</span>
              <input value={termInput} onChange={e => setTermInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && runCommand()}
                className="flex-1 bg-transparent outline-none font-mono text-sm text-white placeholder-zinc-600"
                placeholder="Type a command…" disabled={termRunning} autoFocus />
              <button onClick={runCommand} disabled={termRunning || !termInput.trim()}
                className="text-zinc-500 hover:text-zinc-300 disabled:opacity-30 transition-colors">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><polyline points="9 18 15 12 9 6" /></svg>
              </button>
            </div>
          </div>
          <div className="text-zinc-600 text-xs bg-zinc-900 rounded-lg p-3 border border-white/[0.04]">
            Note: This node terminal runs limited commands via the Proxmox API. For full shell access, connect via SSH or the Proxmox web interface.
          </div>
        </div>
      )}
    </div>
  )
}
