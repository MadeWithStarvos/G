import { useState, useEffect } from 'react'
import { api } from '../../lib/api'
import type { ActivityLog } from '../../lib/api'

export default function AdminActivityPage() {
  const [logs, setLogs] = useState<ActivityLog[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    api.admin.activity().then(setLogs).finally(() => setLoading(false))
  }, [])

  const filtered = logs.filter(l =>
    l.action.toLowerCase().includes(search.toLowerCase()) ||
    (l.ipAddress || '').includes(search)
  )

  const actionColor = (action: string) => {
    if (action.includes('fail') || action.includes('error') || action.includes('suspend')) return 'text-red-400 bg-red-500/10 border-red-500/20'
    if (action.includes('login') || action.includes('register')) return 'text-blue-400 bg-blue-500/10 border-blue-500/20'
    if (action.includes('create') || action.includes('provision') || action.includes('start')) return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20'
    if (action.includes('delete') || action.includes('terminate') || action.includes('stop')) return 'text-amber-400 bg-amber-500/10 border-amber-500/20'
    return 'text-zinc-400 bg-zinc-700/30 border-zinc-600/20'
  }

  return (
    <div className="max-w-5xl mx-auto animate-fade-in">
      <div className="mb-6">
        <h1 className="text-xl font-bold text-white">Audit Log</h1>
        <p className="text-zinc-500 text-sm mt-0.5">{logs.length} events recorded</p>
      </div>

      <div className="relative mb-4">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600">
          <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
        </svg>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Filter by action or IP…"
          className="w-full bg-white/[0.04] border border-white/[0.06] rounded-lg pl-10 pr-4 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/40 transition-all" />
      </div>

      <div className="glass rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 space-y-3">{[...Array(8)].map((_, i) => <div key={i} className="skeleton h-12 rounded-lg" />)}</div>
        ) : !filtered.length ? (
          <div className="py-16 text-center text-zinc-500 text-sm">No activity found</div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {filtered.map(log => (
              <div key={log.id} className="flex items-center gap-4 px-5 py-3.5">
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border whitespace-nowrap ${actionColor(log.action)}`}>
                  {log.action.split('.')[0]}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="text-white text-xs font-mono truncate">{log.action}</div>
                  {log.targetType && log.targetId && (
                    <div className="text-zinc-600 text-xs">{log.targetType}: {log.targetId.slice(0, 12)}…</div>
                  )}
                </div>
                {log.ipAddress && <div className="text-zinc-600 text-xs font-mono hidden sm:block">{log.ipAddress}</div>}
                <div className="text-zinc-700 text-xs flex-shrink-0">{formatDate(log.createdAt)}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function formatDate(iso: string) {
  const d = new Date(iso)
  const now = new Date()
  const diff = Math.floor((now.getTime() - d.getTime()) / 1000)
  if (diff < 60) return 'just now'
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`
  return d.toLocaleDateString()
}
