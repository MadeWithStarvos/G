import { useState, useEffect } from 'react'
import { apiFetch } from '../../lib/api'
import type { Server } from '../../lib/api'

interface ServerGroup { id: string; name: string; color: string; description: string | null; createdAt: string }

const COLORS = ['#6366f1', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#f97316']

export default function AdminGroupsPage() {
  const [groups, setGroups] = useState<ServerGroup[]>([])
  const [servers, setServers] = useState<Server[]>([])
  const [form, setForm] = useState({ name: '', color: '#6366f1', description: '' })
  const [editing, setEditing] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [err, setErr] = useState('')

  const load = async () => {
    const [g, s] = await Promise.all([
      apiFetch<ServerGroup[]>('/admin/server-groups'),
      apiFetch<Server[]>('/admin/servers'),
    ])
    setGroups(g); setServers(s)
  }
  useEffect(() => { load() }, [])

  const save = async () => {
    if (!form.name) { setErr('Name required'); return }
    setSaving(true); setErr('')
    try {
      if (editing) {
        await apiFetch(`/admin/server-groups/${editing}`, { method: 'PUT', body: JSON.stringify(form) })
      } else {
        await apiFetch('/admin/server-groups', { method: 'POST', body: JSON.stringify(form) })
      }
      setForm({ name: '', color: '#6366f1', description: '' }); setEditing(null)
      await load()
    } catch (e: any) { setErr(e.message) }
    setSaving(false)
  }

  const del = async (id: string) => {
    if (!confirm('Delete this group? Servers will be ungrouped.')) return
    await apiFetch(`/admin/server-groups/${id}`, { method: 'DELETE' })
    await load()
  }

  const startEdit = (g: ServerGroup) => {
    setForm({ name: g.name, color: g.color, description: g.description || '' })
    setEditing(g.id)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Server Groups</h1>
        <p className="text-zinc-500 text-sm mt-1">Organize servers by customer, project or purpose</p>
      </div>

      <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-5 space-y-4">
        <h2 className="text-white font-semibold text-sm">{editing ? 'Edit Group' : 'New Group'}</h2>
        {err && <div className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">{err}</div>}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="text-zinc-400 text-xs mb-1 block">Group Name</label>
            <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" placeholder="e.g. Production" />
          </div>
          <div>
            <label className="text-zinc-400 text-xs mb-1 block">Description</label>
            <input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" placeholder="Optional description" />
          </div>
          <div>
            <label className="text-zinc-400 text-xs mb-1 block">Color</label>
            <div className="flex gap-2 flex-wrap">
              {COLORS.map(c => (
                <button key={c} onClick={() => setForm(f => ({ ...f, color: c }))}
                  className={`w-6 h-6 rounded-full transition-transform ${form.color === c ? 'ring-2 ring-white ring-offset-2 ring-offset-zinc-900 scale-110' : 'hover:scale-110'}`}
                  style={{ backgroundColor: c }} />
              ))}
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          {editing && <button onClick={() => { setForm({ name: '', color: '#6366f1', description: '' }); setEditing(null) }} className="px-4 py-2 border border-white/10 text-zinc-400 hover:text-white text-sm rounded-lg transition-colors">Cancel</button>}
          <button onClick={save} disabled={saving} className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm rounded-lg transition-colors">
            {saving ? 'Saving…' : editing ? 'Update' : 'Create Group'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {groups.map(g => {
          const groupServers = servers.filter(s => (s as any).groupId === g.id)
          return (
            <div key={g.id} className="bg-white/[0.02] border border-white/[0.06] rounded-xl p-4">
              <div className="flex items-start gap-3">
                <div className="w-3 h-3 rounded-full mt-1.5 flex-shrink-0" style={{ backgroundColor: g.color }} />
                <div className="flex-1 min-w-0">
                  <div className="text-white font-medium text-sm">{g.name}</div>
                  {g.description && <div className="text-zinc-500 text-xs mt-0.5">{g.description}</div>}
                  <div className="text-zinc-600 text-xs mt-2">{groupServers.length} server{groupServers.length !== 1 ? 's' : ''}</div>
                  {groupServers.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {groupServers.slice(0, 6).map(s => (
                        <span key={s.id} className="text-xs text-zinc-400 bg-zinc-800 px-1.5 py-0.5 rounded truncate max-w-[120px]">{s.displayName}</span>
                      ))}
                      {groupServers.length > 6 && <span className="text-xs text-zinc-600">+{groupServers.length - 6} more</span>}
                    </div>
                  )}
                </div>
                <div className="flex gap-1">
                  <button onClick={() => startEdit(g)} className="text-zinc-500 hover:text-zinc-300 text-xs p-1 rounded hover:bg-white/[0.05] transition-colors">Edit</button>
                  <button onClick={() => del(g.id)} className="text-red-500 hover:text-red-400 text-xs p-1 rounded hover:bg-red-500/10 transition-colors">Del</button>
                </div>
              </div>
            </div>
          )
        })}
        {groups.length === 0 && (
          <div className="col-span-3 py-12 text-center text-zinc-500">No groups yet. Create one above.</div>
        )}
      </div>
    </div>
  )
}
