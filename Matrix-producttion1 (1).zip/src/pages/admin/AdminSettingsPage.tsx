import { useState, useEffect } from 'react'
import { api } from '../../lib/api'
import type { PanelSettings } from '../../lib/api'

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<PanelSettings>({ panelName: 'MatrixHost', hostname: '', faviconUrl: '/favicon.ico' })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState('')

  useEffect(() => {
    ;(api.admin as any).getSettings().then(setSettings).finally(() => setLoading(false))
  }, [])

  function showToast(msg: string) { setToast(msg); setTimeout(() => setToast(''), 4000) }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    try {
      await (api.admin as any).saveSettings(settings)
      showToast('Settings saved successfully')

      // Apply favicon immediately if set
      if (settings.faviconUrl) {
        const link = document.querySelector<HTMLLinkElement>('link[rel="icon"]') || (() => {
          const el = document.createElement('link')
          el.rel = 'icon'
          document.head.appendChild(el)
          return el
        })()
        link.href = settings.faviconUrl
      }

      // Apply panel name to document title
      if (settings.panelName) {
        document.title = settings.panelName
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`)
    } finally { setSaving(false) }
  }

  if (loading) return (
    <div className="space-y-4 max-w-2xl">
      {[...Array(4)].map((_, i) => <div key={i} className="skeleton h-16 rounded-xl" />)}
    </div>
  )

  return (
    <div className="max-w-2xl animate-fade-in">
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-zinc-800 border border-white/10 text-white text-sm px-4 py-3 rounded-xl shadow-2xl animate-slide-up">{toast}</div>
      )}

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">Panel Settings</h1>
        <p className="text-zinc-500 text-sm mt-1">Configure branding and display settings for your panel.</p>
      </div>

      <form onSubmit={handleSave} className="space-y-4">
        {/* Branding section */}
        <div className="glass rounded-xl p-6 space-y-5">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4 text-blue-400">
                <path d="M12 2L2 7l10 5 10-5-10-5z" /><path d="M2 17l10 5 10-5" /><path d="M2 12l10 5 10-5" />
              </svg>
            </div>
            <h2 className="text-white font-semibold text-sm">Branding</h2>
          </div>

          <div>
            <label className="block text-xs text-zinc-400 mb-1.5">Panel Name</label>
            <input
              value={settings.panelName}
              onChange={e => setSettings(s => ({ ...s, panelName: e.target.value }))}
              placeholder="MatrixHost"
              className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60 transition-colors"
            />
            <p className="text-zinc-600 text-xs mt-1">Shown in the browser tab and panel header.</p>
          </div>

          <div>
            <label className="block text-xs text-zinc-400 mb-1.5">Favicon URL</label>
            <div className="flex items-center gap-2">
              {settings.faviconUrl && (
                <img
                  src={settings.faviconUrl}
                  alt="favicon preview"
                  className="w-6 h-6 rounded object-contain bg-white/5 flex-shrink-0"
                  onError={e => { (e.target as HTMLImageElement).style.display = 'none' }}
                />
              )}
              <input
                value={settings.faviconUrl}
                onChange={e => setSettings(s => ({ ...s, faviconUrl: e.target.value }))}
                placeholder="/favicon.ico"
                className="flex-1 bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60 transition-colors"
              />
            </div>
            <p className="text-zinc-600 text-xs mt-1">Path or URL to your .ico or .png favicon.</p>
          </div>
        </div>

        {/* Domain section */}
        <div className="glass rounded-xl p-6 space-y-5">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-8 h-8 rounded-lg bg-violet-500/10 border border-violet-500/20 flex items-center justify-center">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4 text-violet-400">
                <circle cx="12" cy="12" r="10" /><line x1="2" y1="12" x2="22" y2="12" />
                <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
              </svg>
            </div>
            <h2 className="text-white font-semibold text-sm">Domain</h2>
          </div>

          <div>
            <label className="block text-xs text-zinc-400 mb-1.5">Panel Hostname</label>
            <input
              value={settings.hostname}
              onChange={e => setSettings(s => ({ ...s, hostname: e.target.value }))}
              placeholder="panel.yourdomain.com"
              className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60 transition-colors"
            />
            <p className="text-zinc-600 text-xs mt-1">The public-facing domain where this panel is hosted. Used in links and API responses.</p>
          </div>
        </div>

        {/* Preview */}
        <div className="glass rounded-xl p-5">
          <h3 className="text-zinc-400 text-xs font-medium mb-3">Preview</h3>
          <div className="flex items-center gap-3 bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-2.5">
            {settings.faviconUrl ? (
              <img src={settings.faviconUrl} alt="favicon" className="w-4 h-4 rounded object-contain"
                onError={e => { (e.target as HTMLImageElement).style.display = 'none' }} />
            ) : (
              <div className="w-4 h-4 rounded bg-zinc-700 flex-shrink-0" />
            )}
            <span className="text-white text-sm">{settings.panelName || 'MatrixHost'}</span>
            {settings.hostname && <span className="text-zinc-500 text-xs ml-auto font-mono">{settings.hostname}</span>}
          </div>
        </div>

        <div className="flex justify-end">
          <button type="submit" disabled={saving}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-semibold px-6 py-2.5 rounded-xl text-sm transition-all">
            {saving && <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
            {saving ? 'Saving…' : 'Save Settings'}
          </button>
        </div>
      </form>
    </div>
  )
}
