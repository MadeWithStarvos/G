import { useState, useEffect } from 'react'
import { api } from '../../lib/api'
import type { Node } from '../../lib/api'

interface Props { navigate: (r: any) => void }

export default function AdminNodesPage({ navigate }: Props) {
  const [nodes, setNodes] = useState<Node[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.admin.nodes().then(setNodes).finally(() => setLoading(false))
  }, [])

  return (
    <div className="max-w-6xl mx-auto animate-fade-in">
      <div className="mb-6">
        <h1 className="text-xl font-bold text-white">Nodes</h1>
        <p className="text-zinc-500 text-sm mt-0.5">{nodes.length} node{nodes.length !== 1 ? 's' : ''} discovered</p>
      </div>

      <div className="glass rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 space-y-3">{[...Array(4)].map((_, i) => <div key={i} className="skeleton h-16 rounded-lg" />)}</div>
        ) : !nodes.length ? (
          <div className="flex flex-col items-center justify-center py-20">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-10 h-10 text-zinc-700 mb-4">
              <rect x="4" y="4" width="16" height="16" rx="2" /><rect x="9" y="9" width="6" height="6" />
            </svg>
            <p className="text-zinc-500 text-sm">No nodes found</p>
            <p className="text-zinc-700 text-xs mt-1">Add a Proxmox cluster to discover nodes</p>
          </div>
        ) : (
          <>
            <div className="hidden lg:grid grid-cols-[auto_1fr_auto_auto_auto_auto] gap-4 px-5 py-3 border-b border-white/[0.06] text-xs font-medium text-zinc-600 uppercase tracking-wider">
              <span>Status</span><span>Node</span><span>CPU</span><span>RAM</span><span>Guests</span><span>Flags</span>
            </div>
            <div className="divide-y divide-white/[0.04]">
              {nodes.map(node => (
                <div key={node.id} className="grid grid-cols-1 lg:grid-cols-[auto_1fr_auto_auto_auto_auto_auto] gap-4 items-center px-5 py-4">
                  <span className={`status-dot ${node.status}`} />
                  <div>
                    <div className="text-white text-sm font-medium">{node.name}</div>
                    {node.proxmoxVersion && <div className="text-zinc-600 text-xs">PVE {node.proxmoxVersion}</div>}
                  </div>
                  <div className="text-right">
                    <div className="text-white text-sm">{node.cpuCores ?? '—'} cores</div>
                    {node.cpuUsage != null && <div className="text-zinc-600 text-xs">{(node.cpuUsage * 100).toFixed(1)}% used</div>}
                  </div>
                  <div className="text-right">
                    {node.totalRam != null ? (
                      <>
                        <div className="text-white text-sm">{formatRam(node.totalRam)}</div>
                        {node.usedRam != null && <div className="text-zinc-600 text-xs">{formatRam(node.usedRam)} used</div>}
                      </>
                    ) : <span className="text-zinc-600 text-sm">—</span>}
                  </div>
                  <div className="text-white text-sm text-right">{node.guestCount}</div>
                  <div className="flex gap-1.5">
                    {node.isMaintenanceMode && (
                      <span className="text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/20 px-1.5 py-0.5 rounded font-semibold uppercase">Maint</span>
                    )}
                    {!node.isProvisioningEnabled && (
                      <span className="text-[10px] bg-red-500/10 text-red-400 border border-red-500/20 px-1.5 py-0.5 rounded font-semibold uppercase">No Prov</span>
                    )}
                    {node.isProvisioningEnabled && !node.isMaintenanceMode && (
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded font-semibold uppercase">Active</span>
                    )}
                  </div>
                  <button onClick={() => navigate({ page: 'admin-node-detail', id: node.id })} className="text-xs px-3 py-1.5 rounded-lg border border-white/[0.08] text-zinc-300 hover:text-white hover:border-white/20 transition-all">
                    Open
                  </button>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  )
}

function formatRam(mb: number) {
  if (mb >= 1024) return `${(mb / 1024).toFixed(1)} GB`
  return `${mb} MB`
}
