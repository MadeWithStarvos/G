import { useState, useEffect } from 'react'
import { api } from '../../lib/api'
import type { Cluster, CreateClusterData } from '../../lib/api'

export default function AdminClustersPage() {
  const [clusters, setClusters] = useState<Cluster[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [testing, setTesting] = useState<string>('')
  const [syncing, setSyncing] = useState<string>('')
  const [toast, setToast] = useState('')
  const [form, setForm] = useState<CreateClusterData>({
    name: '', hostname: '', port: 8006, protocol: 'https', tokenId: '', tokenSecret: '', tlsVerify: true,
  })

  useEffect(() => {
    api.admin.clusters().then(setClusters).finally(() => setLoading(false))
  }, [])

  function showToast(msg: string) { setToast(msg); setTimeout(() => setToast(''), 4000) }

  const set = (k: keyof CreateClusterData) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm(f => ({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.type === 'number' ? Number(e.target.value) : e.target.value }))

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault(); setSaving(true)
    try {
      const cluster = await api.admin.createCluster(form)
      setClusters(c => [...c, cluster])
      setShowForm(false)
      setForm({ name: '', hostname: '', port: 8006, tokenId: '', tokenSecret: '', tlsVerify: true })
      showToast('Cluster added successfully')
    } catch (e: any) {
      showToast(`Error: ${e.message}`)
    } finally { setSaving(false) }
  }

  async function testConnection(id: string) {
    setTesting(id)
    try {
      const res = await api.admin.testCluster(id)
      setClusters(c => c.map(cl => cl.id === id ? { ...cl, connectionStatus: 'connected' } : cl))
      showToast(`Connected! PVE ${res.version?.version ?? ''}`)
    } catch (e: any) {
      setClusters(c => c.map(cl => cl.id === id ? { ...cl, connectionStatus: 'error' } : cl))
      showToast(`Connection failed: ${e.message}`)
    } finally { setTesting('') }
  }

  async function syncCluster(id: string) {
    setSyncing(id)
    try {
      const res = await api.admin.syncCluster(id)
      showToast(`Sync started (job ${res.jobId.slice(0, 8)})`)
      // Poll until done
      let tries = 0
      const poll = setInterval(async () => {
        tries++
        if (tries > 40) { clearInterval(poll); setSyncing(''); showToast('Sync timed out'); return }
        try {
          const job = await api.servers.getJob(res.jobId)
          if (job.status === 'completed') {
            clearInterval(poll); setSyncing('')
            const updated = await api.admin.clusters()
            setClusters(updated)
            showToast('Cluster synced successfully')
          } else if (job.status === 'failed') {
            clearInterval(poll); setSyncing('')
            showToast(`Sync failed: ${job.error}`)
          }
        } catch {}
      }, 2000)
    } catch (e: any) {
      showToast(`Error: ${e.message}`); setSyncing('')
    }
  }

  async function syncTemplates(id: string) {
    try {
      const res = await api.admin.syncTemplates(id)
      showToast(`Synced ${res.synced} template(s)`)
    } catch (e: any) { showToast(`Error: ${e.message}`) }
  }

  async function syncStorage(id: string) {
    try {
      const [s, b] = await Promise.all([api.admin.syncStorage(id), api.admin.syncBridges(id)])
      showToast(`Synced ${s.synced} storage pools, ${b.synced} bridges`)
    } catch (e: any) { showToast(`Error: ${e.message}`) }
  }

  const statusColors: Record<string, string> = {
    connected: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
    disconnected: 'text-red-400 bg-red-500/10 border-red-500/20',
    error: 'text-red-400 bg-red-500/10 border-red-500/20',
    unknown: 'text-zinc-400 bg-zinc-700/30 border-zinc-600/20',
  }

  return (
    <div className="max-w-5xl mx-auto animate-fade-in">
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-zinc-800 border border-white/10 text-white text-sm px-4 py-3 rounded-xl shadow-2xl animate-slide-up">{toast}</div>
      )}

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-white">Proxmox Clusters</h1>
          <p className="text-zinc-500 text-sm mt-0.5">{clusters.length} connection{clusters.length !== 1 ? 's' : ''}</p>
        </div>
        <button onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-all glow-blue">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
          Add Cluster
        </button>
      </div>

      {showForm && (
        <div className="glass rounded-xl p-5 mb-6 animate-slide-up">
          <h3 className="text-white font-semibold text-sm mb-4">Add Proxmox Cluster</h3>
          <form onSubmit={handleAdd} className="grid grid-cols-2 gap-4">
            {[
              { label: 'Cluster Name', key: 'name', placeholder: 'My Proxmox Cluster' },
              { label: 'Hostname / API URL', key: 'hostname', placeholder: '192.168.1.10 or pve.example.com' },
              { label: 'API Port', key: 'port', placeholder: '8006', type: 'number' },
              { label: 'Protocol', key: 'protocol', placeholder: '', type: 'select', options: ['https', 'http'] },
              { label: 'Token ID', key: 'tokenId', placeholder: 'root@pam!mytoken' },
              { label: 'Token Secret', key: 'tokenSecret', placeholder: '••••••••', type: 'password' },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">{f.label}</label>
                <input type={f.type || 'text'} value={(form as any)[f.key]} onChange={set(f.key as any)}
                  placeholder={f.placeholder} required
                  className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60 transition-all" />
              </div>
            ))}
            <div className="flex items-center gap-2 mt-1">
              <input type="checkbox" id="tlsVerify" checked={form.tlsVerify} onChange={set('tlsVerify')}
                className="w-4 h-4 rounded accent-blue-600" />
              <label htmlFor="tlsVerify" className="text-sm text-zinc-400">Verify TLS Certificate</label>
            </div>
            <div className="col-span-2 flex gap-3 pt-2">
              <button type="submit" disabled={saving}
                className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-semibold px-5 py-2.5 rounded-lg transition-all flex items-center gap-2">
                {saving && <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
                {saving ? 'Adding…' : 'Add Cluster'}
              </button>
              <button type="button" onClick={() => setShowForm(false)}
                className="text-zinc-400 hover:text-white text-sm px-4 py-2.5 rounded-lg border border-white/[0.08] hover:border-white/20 transition-all">Cancel</button>
            </div>
          </form>
        </div>
      )}

      <div className="glass rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 space-y-3">{[...Array(3)].map((_, i) => <div key={i} className="skeleton h-16 rounded-lg" />)}</div>
        ) : !clusters.length ? (
          <div className="flex flex-col items-center justify-center py-20">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-10 h-10 text-zinc-700 mb-4"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" /></svg>
            <p className="text-zinc-500 text-sm">No clusters added yet</p>
            <p className="text-zinc-700 text-xs mt-1">Add your first Proxmox cluster to get started</p>
          </div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {clusters.map(c => (
              <div key={c.id} className="px-5 py-4">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="w-9 h-9 rounded-lg bg-white/[0.04] flex items-center justify-center flex-shrink-0">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4 text-blue-400"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" /></svg>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-white text-sm font-medium">{c.name}</div>
                    <div className="text-zinc-500 text-xs font-mono">{c.hostname}:{c.port}</div>
                  </div>
                  <div className="text-zinc-600 text-xs font-mono truncate max-w-[160px] hidden lg:block">{c.tokenId}</div>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border uppercase tracking-wide ${statusColors[c.connectionStatus] || statusColors.unknown}`}>
                    {c.connectionStatus}
                  </span>
                  <div className="text-zinc-600 text-xs hidden md:block">{c.lastSyncAt ? new Date(c.lastSyncAt).toLocaleString() : 'Never synced'}</div>

                  {/* Action buttons */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => testConnection(c.id)}
                      disabled={testing === c.id}
                      className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/10 disabled:opacity-50 transition-all"
                    >
                      {testing === c.id ? <div className="w-3 h-3 border border-current border-t-transparent rounded-full animate-spin" /> : <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-3 h-3"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" /></svg>}
                      Test
                    </button>
                    <button
                      onClick={() => syncCluster(c.id)}
                      disabled={syncing === c.id}
                      className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-blue-500/20 text-blue-400 hover:bg-blue-500/10 disabled:opacity-50 transition-all"
                    >
                      {syncing === c.id ? <div className="w-3 h-3 border border-current border-t-transparent rounded-full animate-spin" /> : <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-3 h-3"><polyline points="1 4 1 10 7 10" /><polyline points="23 20 23 14 17 14" /><path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4-4.64 4.36A9 9 0 0 1 3.51 15" /></svg>}
                      Sync Nodes
                    </button>
                    <button
                      onClick={() => syncTemplates(c.id)}
                      className="text-xs px-3 py-1.5 rounded-lg border border-violet-500/20 text-violet-400 hover:bg-violet-500/10 transition-all"
                    >
                      Sync Templates
                    </button>
                    <button
                      onClick={() => syncStorage(c.id)}
                      className="text-xs px-3 py-1.5 rounded-lg border border-amber-500/20 text-amber-400 hover:bg-amber-500/10 transition-all"
                    >
                      Sync Storage
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
