import { useState, useEffect } from 'react'
import { api } from '../../lib/api'
import type { AdminDashboard, AlertItem } from '../../lib/api'

interface Props {
  navigate: (r: any) => void
}

export default function AdminDashboardPage({ navigate }: Props) {
  const [data, setData] = useState<AdminDashboard | null>(null)
  const [alerts, setAlerts] = useState<AlertItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([api.admin.dashboard(), api.admin.alerts()]).then(([dash, alertData]) => {
      setData(dash)
      setAlerts(alertData)
    }).finally(() => setLoading(false))
  }, [])

  if (loading) return <Skeleton />

  const stats = data?.stats
  const cards = [
    { label: 'Total Users', value: stats?.totalUsers ?? 0, color: 'blue', sub: 'registered accounts' },
    { label: 'Total Servers', value: stats?.totalServers ?? 0, color: 'violet', sub: 'all virtualization' },
    { label: 'Running', value: stats?.runningServers ?? 0, color: 'emerald', sub: 'active right now' },
    { label: 'Stopped', value: stats?.stoppedServers ?? 0, color: 'zinc', sub: 'idle instances' },
    { label: 'Suspended', value: stats?.suspendedServers ?? 0, color: 'amber', sub: 'restricted access' },
    { label: 'Clusters', value: stats?.totalClusters ?? 0, color: 'blue', sub: 'Proxmox connections' },
    { label: 'Total Nodes', value: stats?.totalNodes ?? 0, color: 'cyan', sub: 'physical hosts' },
    { label: 'Offline Nodes', value: stats?.offlineNodes ?? 0, color: 'red', sub: 'require attention' },
  ]

  const actionCards = [
    { label: 'Manage Servers', page: 'admin-servers', desc: 'View all servers', color: 'violet' },
    { label: 'Manage Users', page: 'admin-users', desc: 'View all accounts', color: 'blue' },
    { label: 'Proxmox Clusters', page: 'admin-clusters', desc: 'Add & configure', color: 'cyan' },
    { label: 'Node Management', page: 'admin-nodes', desc: 'Inspect hosts, services and logs', color: 'emerald' },
  ]

  return (
    <div className="max-w-6xl mx-auto animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
        <p className="text-zinc-500 text-sm mt-1">Infrastructure overview and system health.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {cards.map(c => (
          <div key={c.label} className="glass rounded-xl p-4">
            <div className="text-zinc-500 text-xs mb-2 font-medium">{c.label}</div>
            <div className={`text-2xl font-bold mb-0.5 ${colorText[c.color]}`}>{c.value}</div>
            <div className="text-zinc-700 text-xs">{c.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {actionCards.map(a => (
          <button
            key={a.page}
            onClick={() => navigate({ page: a.page })}
            className="glass rounded-xl p-4 text-left hover:bg-white/[0.04] transition-all group border-transparent hover:border-white/[0.08] border"
          >
            <div className={`text-sm font-semibold mb-1 ${colorText[a.color]} group-hover:opacity-100`}>{a.label}</div>
            <div className="text-zinc-600 text-xs">{a.desc}</div>
          </button>
        ))}
      </div>

      <div className="glass rounded-xl overflow-hidden mb-6">
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.06]">
          <h2 className="text-white font-semibold text-sm">Alerts Center</h2>
          <span className="text-zinc-600 text-xs">{alerts.filter(a => !a.isResolved).length} active</span>
        </div>
        {!alerts.length ? (
          <div className="py-10 text-center text-zinc-600 text-sm">No alerts recorded yet</div>
        ) : (
          <div className="divide-y divide-white/[0.04]">{alerts.slice(0, 6).map(alert => (
            <div key={alert.id} className="flex items-start gap-3 px-5 py-3">
              <span className={`mt-1 h-2.5 w-2.5 rounded-full ${alert.severity === 'critical' ? 'bg-red-500' : alert.severity === 'warning' ? 'bg-amber-500' : 'bg-blue-500'}`} />
              <div className="flex-1 min-w-0">
                <div className="text-white text-sm font-medium">{alert.message}</div>
                <div className="text-zinc-600 text-xs mt-0.5">{new Date(alert.createdAt).toLocaleString()}</div>
              </div>
              {alert.isResolved ? <span className="text-emerald-400 text-[10px] uppercase">resolved</span> : <span className="text-amber-400 text-[10px] uppercase">active</span>}
            </div>
          ))}</div>
        )}
      </div>

      {/* Recent activity */}
      <div className="glass rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.06]">
          <h2 className="text-white font-semibold text-sm">Recent Activity</h2>
          <button onClick={() => navigate({ page: 'admin-activity' })} className="text-blue-400 hover:text-blue-300 text-xs transition-colors">
            View all
          </button>
        </div>
        {!data?.recentActivity?.length ? (
          <div className="py-12 text-center text-zinc-600 text-sm">No activity recorded yet</div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {data.recentActivity.slice(0, 10).map(log => (
              <div key={log.id} className="flex items-center gap-4 px-5 py-3">
                <div className="w-7 h-7 rounded-lg bg-white/[0.04] flex items-center justify-center flex-shrink-0">
                  <span className="text-xs text-zinc-500">{log.action.split('.')[0][0].toUpperCase()}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-white text-xs font-medium font-mono">{log.action}</div>
                  {log.ipAddress && <div className="text-zinc-600 text-xs">from {log.ipAddress}</div>}
                </div>
                <div className="text-zinc-700 text-xs flex-shrink-0">{formatDate(log.createdAt)}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

const colorText: Record<string, string> = {
  blue: 'text-blue-400', violet: 'text-violet-400', emerald: 'text-emerald-400',
  zinc: 'text-zinc-400', amber: 'text-amber-400', red: 'text-red-400', cyan: 'text-cyan-400',
}

function formatDate(iso: string) {
  const d = new Date(iso)
  const now = new Date()
  const diff = Math.floor((now.getTime() - d.getTime()) / 1000)
  if (diff < 60) return 'just now'
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`
  return d.toLocaleDateString()
}

function Skeleton() {
  return (
    <div className="max-w-6xl mx-auto space-y-4">
      <div className="skeleton h-8 w-48 rounded-lg" />
      <div className="grid grid-cols-4 gap-4">{[...Array(8)].map((_, i) => <div key={i} className="skeleton h-24 rounded-xl" />)}</div>
      <div className="skeleton h-64 rounded-xl" />
    </div>
  )
}
