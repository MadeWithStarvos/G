import { useState, useEffect } from 'react'
import { apiFetch } from '../../lib/api'
import type { Cluster, Node, Server } from '../../lib/api'

interface ClusterWithNodes extends Cluster {
  nodes: (Node & { servers: Server[] })[]
}

function fmtBytes(b: number) {
  if (b > 1073741824) return (b / 1073741824).toFixed(1) + ' GB'
  return (b / 1048576).toFixed(0) + ' MB'
}

function PctBar({ pct, color }: { pct: number; color: string }) {
  return (
    <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
      <div className={`h-full rounded-full ${color} transition-all`} style={{ width: `${Math.min(100, pct)}%` }} />
    </div>
  )
}

export default function AdminClusterMapPage() {
  const [clusters, setClusters] = useState<Cluster[]>([])
  const [nodes, setNodes] = useState<Node[]>([])
  const [servers, setServers] = useState<Server[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      apiFetch<Cluster[]>('/admin/clusters'),
      apiFetch<Node[]>('/admin/nodes'),
      apiFetch<Server[]>('/admin/servers'),
    ]).then(([c, n, s]) => { setClusters(c); setNodes(n); setServers(s) })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  const tree: ClusterWithNodes[] = clusters.map(cluster => ({
    ...cluster,
    nodes: nodes.filter(n => n.clusterId === cluster.id).map(node => ({
      ...node,
      servers: servers.filter(s => s.nodeId === node.id && s.status !== 'terminated'),
    }))
  }))

  const totals = {
    clusters: clusters.length,
    nodes: nodes.length,
    online: nodes.filter(n => n.status === 'online').length,
    servers: servers.filter(s => s.status !== 'terminated').length,
    running: servers.filter(s => s.status === 'running').length,
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Cluster Map</h1>
        <p className="text-zinc-500 text-sm mt-1">Visual overview of clusters → nodes → servers</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {[
          { label: 'Clusters', value: totals.clusters, color: 'text-blue-400' },
          { label: 'Nodes', value: totals.nodes, color: 'text-zinc-300' },
          { label: 'Online', value: totals.online, color: 'text-emerald-400' },
          { label: 'Servers', value: totals.servers, color: 'text-zinc-300' },
          { label: 'Running', value: totals.running, color: 'text-emerald-400' },
        ].map(s => (
          <div key={s.label} className="bg-white/[0.02] border border-white/[0.06] rounded-xl p-3 text-center">
            <div className={`text-xl font-bold ${s.color}`}>{s.value}</div>
            <div className="text-zinc-600 text-xs mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {loading ? (
        <div className="py-12 text-center text-zinc-500">Loading…</div>
      ) : (
        <div className="space-y-6">
          {tree.map(cluster => (
            <div key={cluster.id} className="bg-white/[0.02] border border-white/[0.08] rounded-xl overflow-hidden">
              <div className="flex items-center gap-3 px-5 py-4 border-b border-white/[0.06] bg-blue-500/5">
                <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center flex-shrink-0">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4 text-blue-400">
                    <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" />
                  </svg>
                </div>
                <div>
                  <div className="text-white font-semibold">{cluster.name}</div>
                  <div className="text-zinc-500 text-xs">{cluster.hostname}:{cluster.port}</div>
                </div>
                <span className={`ml-auto text-xs px-2 py-0.5 rounded-full border ${cluster.connectionStatus === 'connected' ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' : 'text-zinc-500 bg-zinc-800 border-zinc-700'}`}>
                  {cluster.connectionStatus}
                </span>
                <span className="text-zinc-600 text-xs">{cluster.nodes.length} nodes</span>
              </div>

              <div className="p-4 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {cluster.nodes.map(node => {
                  const cpuPct = (node.cpuUsage || 0) * 100
                  const ramPct = node.totalRam && node.usedRam ? (node.usedRam / node.totalRam) * 100 : 0
                  const statusColor = node.status === 'online' ? 'text-emerald-400' : node.status === 'offline' ? 'text-red-400' : 'text-zinc-500'
                  return (
                    <div key={node.id} className="bg-black/20 border border-white/[0.06] rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <div className={`w-2 h-2 rounded-full flex-shrink-0 ${node.status === 'online' ? 'bg-emerald-400' : node.status === 'offline' ? 'bg-red-400' : 'bg-zinc-500'}`} />
                        <span className="text-white font-medium text-sm">{node.name}</span>
                        {node.isMaintenanceMode && (
                          <span className="text-amber-400 text-xs bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.5 rounded-full">maintenance</span>
                        )}
                        <span className="text-zinc-600 text-xs ml-auto">{node.proxmoxVersion || ''}</span>
                      </div>

                      {node.status === 'online' && (
                        <div className="space-y-2 mb-3">
                          <div>
                            <div className="flex justify-between text-xs text-zinc-500 mb-1">
                              <span>CPU</span>
                              <span>{cpuPct.toFixed(1)}%</span>
                            </div>
                            <PctBar pct={cpuPct} color={cpuPct > 80 ? 'bg-red-500' : cpuPct > 60 ? 'bg-amber-500' : 'bg-blue-500'} />
                          </div>
                          <div>
                            <div className="flex justify-between text-xs text-zinc-500 mb-1">
                              <span>RAM</span>
                              <span>{node.usedRam ? fmtBytes(node.usedRam) : '—'} / {node.totalRam ? fmtBytes(node.totalRam) : '—'}</span>
                            </div>
                            <PctBar pct={ramPct} color={ramPct > 90 ? 'bg-red-500' : ramPct > 75 ? 'bg-amber-500' : 'bg-violet-500'} />
                          </div>
                        </div>
                      )}

                      <div className="text-xs text-zinc-600 mb-2">{node.servers.length} server{node.servers.length !== 1 ? 's' : ''}</div>

                      {node.servers.length > 0 && (
                        <div className="flex flex-wrap gap-1.5">
                          {node.servers.slice(0, 12).map(srv => (
                            <div key={srv.id} title={`${srv.displayName} (${srv.status})`}
                              className={`w-6 h-6 rounded border text-[9px] flex items-center justify-center font-mono cursor-default transition-opacity
                                ${srv.status === 'running' ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-400' :
                                  srv.status === 'stopped' ? 'bg-zinc-800 border-zinc-700 text-zinc-500' :
                                  srv.status === 'provisioning' ? 'bg-blue-500/20 border-blue-500/30 text-blue-400 animate-pulse' :
                                  'bg-red-500/20 border-red-500/30 text-red-400'}`}>
                              {srv.vmid ? String(srv.vmid).slice(-2) : '?'}
                            </div>
                          ))}
                          {node.servers.length > 12 && (
                            <div className="w-6 h-6 rounded border border-zinc-700 bg-zinc-800 text-[9px] flex items-center justify-center text-zinc-500">
                              +{node.servers.length - 12}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )
                })}
                {cluster.nodes.length === 0 && (
                  <div className="text-zinc-600 text-sm p-4">No nodes synced for this cluster</div>
                )}
              </div>
            </div>
          ))}
          {clusters.length === 0 && (
            <div className="py-12 text-center text-zinc-500">No clusters configured</div>
          )}
        </div>
      )}
    </div>
  )
}
