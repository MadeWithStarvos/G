import { useState, useEffect } from 'react'
import { apiFetch } from '../../lib/api'

interface Announcement {
  id: string; title: string; content: string; type: string; isActive: boolean
  targetRole: string; startsAt: string | null; endsAt: string | null; createdAt: string
}

const TYPE_COLOR: Record<string, string> = {
  info: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
  success: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
  warning: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
  error: 'text-red-400 bg-red-500/10 border-red-500/20',
}

const BLANK = { title: '', content: '', type: 'info', isActive: true, targetRole: 'all', startsAt: '', endsAt: '' }

export default function AdminAnnouncementsPage() {
  const [list, setList] = useState<Announcement[]>([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState(BLANK)
  const [editing, setEditing] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [err, setErr] = useState('')

  const load = async () => {
    const data = await apiFetch<Announcement[]>('/admin/announcements')
    setList(data)
    setLoading(false)
  }
  useEffect(() => { load() }, [])

  const save = async () => {
    if (!form.title || !form.content) { setErr('Title and content are required'); return }
    setSaving(true); setErr('')
    try {
      const body = { ...form, startsAt: form.startsAt || null, endsAt: form.endsAt || null }
      if (editing) {
        await apiFetch(`/admin/announcements/${editing}`, { method: 'PUT', body: JSON.stringify(body) })
      } else {
        await apiFetch('/admin/announcements', { method: 'POST', body: JSON.stringify(body) })
      }
      setForm(BLANK); setEditing(null)
      await load()
    } catch (e: any) { setErr(e.message) }
    setSaving(false)
  }

  const del = async (id: string) => {
    if (!confirm('Delete this announcement?')) return
    await apiFetch(`/admin/announcements/${id}`, { method: 'DELETE' })
    await load()
  }

  const startEdit = (a: Announcement) => {
    setForm({ title: a.title, content: a.content, type: a.type, isActive: a.isActive, targetRole: a.targetRole, startsAt: a.startsAt || '', endsAt: a.endsAt || '' })
    setEditing(a.id)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Announcements</h1>
        <p className="text-zinc-500 text-sm mt-1">Show notices to users on their dashboard</p>
      </div>

      <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-5 space-y-4">
        <h2 className="text-white font-semibold text-sm">{editing ? 'Edit Announcement' : 'New Announcement'}</h2>
        {err && <div className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">{err}</div>}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2">
            <label className="text-zinc-400 text-xs mb-1 block">Title</label>
            <input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500" placeholder="Announcement title" />
          </div>
          <div className="sm:col-span-2">
            <label className="text-zinc-400 text-xs mb-1 block">Content</label>
            <textarea value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} rows={3}
              className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500 resize-none" placeholder="Announcement message…" />
          </div>
          <div>
            <label className="text-zinc-400 text-xs mb-1 block">Type</label>
            <select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}
              className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-zinc-300 text-sm focus:outline-none focus:border-blue-500">
              <option value="info">Info</option>
              <option value="success">Success</option>
              <option value="warning">Warning</option>
              <option value="error">Critical</option>
            </select>
          </div>
          <div>
            <label className="text-zinc-400 text-xs mb-1 block">Target</label>
            <select value={form.targetRole} onChange={e => setForm(f => ({ ...f, targetRole: e.target.value }))}
              className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-zinc-300 text-sm focus:outline-none focus:border-blue-500">
              <option value="all">All Users</option>
              <option value="customer">Customers only</option>
              <option value="admin">Admins only</option>
            </select>
          </div>
          <div>
            <label className="text-zinc-400 text-xs mb-1 block">Starts At (optional)</label>
            <input type="datetime-local" value={form.startsAt} onChange={e => setForm(f => ({ ...f, startsAt: e.target.value }))}
              className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-zinc-300 text-sm focus:outline-none focus:border-blue-500" />
          </div>
          <div>
            <label className="text-zinc-400 text-xs mb-1 block">Ends At (optional)</label>
            <input type="datetime-local" value={form.endsAt} onChange={e => setForm(f => ({ ...f, endsAt: e.target.value }))}
              className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-zinc-300 text-sm focus:outline-none focus:border-blue-500" />
          </div>
        </div>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 text-zinc-400 text-sm cursor-pointer">
            <input type="checkbox" checked={form.isActive} onChange={e => setForm(f => ({ ...f, isActive: e.target.checked }))}
              className="rounded accent-blue-500" />
            Active
          </label>
          <div className="flex gap-2 ml-auto">
            {editing && <button onClick={() => { setForm(BLANK); setEditing(null) }} className="px-4 py-2 border border-white/10 text-zinc-400 hover:text-white text-sm rounded-lg transition-colors">Cancel</button>}
            <button onClick={save} disabled={saving} className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm rounded-lg transition-colors">
              {saving ? 'Saving…' : editing ? 'Update' : 'Create'}
            </button>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="py-12 text-center text-zinc-500">Loading…</div>
      ) : list.length === 0 ? (
        <div className="py-12 text-center text-zinc-500">No announcements yet</div>
      ) : (
        <div className="space-y-3">
          {list.map(a => (
            <div key={a.id} className={`bg-white/[0.02] border rounded-xl p-4 ${a.isActive ? 'border-white/[0.08]' : 'border-white/[0.04] opacity-60'}`}>
              <div className="flex items-start gap-3">
                <span className={`text-xs px-2 py-0.5 rounded-full border flex-shrink-0 mt-0.5 ${TYPE_COLOR[a.type] || TYPE_COLOR.info}`}>{a.type}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-medium text-sm">{a.title}</span>
                    {!a.isActive && <span className="text-xs text-zinc-600 bg-zinc-800 px-2 py-0.5 rounded-full">inactive</span>}
                    <span className="text-xs text-zinc-600 ml-auto">{new Date(a.createdAt).toLocaleDateString()}</span>
                  </div>
                  <p className="text-zinc-400 text-sm mt-1">{a.content}</p>
                  <div className="flex items-center gap-3 mt-2 text-xs text-zinc-600">
                    <span>→ {a.targetRole === 'all' ? 'All users' : a.targetRole === 'admin' ? 'Admins only' : 'Customers only'}</span>
                    {a.startsAt && <span>from {new Date(a.startsAt).toLocaleDateString()}</span>}
                    {a.endsAt && <span>until {new Date(a.endsAt).toLocaleDateString()}</span>}
                  </div>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  <button onClick={() => startEdit(a)} className="text-zinc-500 hover:text-zinc-300 transition-colors text-xs px-2 py-1 rounded hover:bg-white/[0.05]">Edit</button>
                  <button onClick={() => del(a.id)} className="text-red-500 hover:text-red-400 transition-colors text-xs px-2 py-1 rounded hover:bg-red-500/10">Delete</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
