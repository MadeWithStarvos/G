import { useState, useEffect, useCallback } from 'react'
import { apiFetch } from '../lib/api'
import type { Job } from '../lib/api'

const STATUS_COLOR: Record<string, string> = {
  pending: 'text-zinc-400 bg-zinc-500/10 border-zinc-500/20',
  running: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
  completed: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
  failed: 'text-red-400 bg-red-500/10 border-red-500/20',
}

const JOB_LABELS: Record<string, string> = {
  provision: 'Provision', power: 'Power', delete: 'Delete',
  snapshot: 'Snapshot', snapshot_delete: 'Snapshot Delete', snapshot_rollback: 'Snapshot Rollback',
  backup: 'Backup', backup_delete: 'Backup Delete', backup_restore: 'Backup Restore',
  migrate: 'Migrate', reinstall: 'Reinstall', resize: 'Resize',
  sync_cluster: 'Sync Cluster', clone_server: 'Clone Server',
}

function fmtDuration(start: string, end: string | null) {
  if (!end) return '—'
  const ms = new Date(end).getTime() - new Date(start).getTime()
  if (ms < 1000) return `${ms}ms`
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`
  return `${Math.floor(ms / 60000)}m ${Math.floor((ms % 60000) / 1000)}s`
}

export default function TaskCenterPage() {
  const [jobs, setJobs] = useState<Job[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState({ status: '', type: '' })
  const [expanded, setExpanded] = useState<string | null>(null)

  const load = useCallback(async () => {
    try {
      const params = new URLSearchParams({ limit: '200' })
      if (filter.status) params.set('status', filter.status)
      if (filter.type) params.set('type', filter.type)
      const data = await apiFetch<Job[]>(`/admin/jobs?${params}`)
      setJobs(data)
    } catch {}
    setLoading(false)
  }, [filter])

  useEffect(() => { load() }, [load])
  useEffect(() => {
    const id = setInterval(load, 5000)
    return () => clearInterval(id)
  }, [load])

  const types = Array.from(new Set(jobs.map(j => j.type))).sort()
  const counts = { total: jobs.length, running: jobs.filter(j => j.status === 'running').length, failed: jobs.filter(j => j.status === 'failed').length }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Task Center</h1>
        <p className="text-zinc-500 text-sm mt-1">All Proxmox operations, UPIDs and job results</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Total Jobs', value: counts.total, color: 'text-white' },
          { label: 'Running', value: counts.running, color: 'text-blue-400' },
          { label: 'Failed', value: counts.failed, color: 'text-red-400' },
        ].map(s => (
          <div key={s.label} className="bg-white/[0.03] border border-white/[0.08] rounded-xl p-4">
            <div className="text-zinc-500 text-xs mb-1">{s.label}</div>
            <div className={`text-2xl font-bold ${s.color}`}>{s.value}</div>
          </div>
        ))}
      </div>

      <div className="flex gap-3 flex-wrap">
        <select value={filter.status} onChange={e => setFilter(f => ({ ...f, status: e.target.value }))}
          className="bg-zinc-900 border border-white/10 text-zinc-300 text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500">
          <option value="">All Statuses</option>
          <option value="pending">Pending</option>
          <option value="running">Running</option>
          <option value="completed">Completed</option>
          <option value="failed">Failed</option>
        </select>
        <select value={filter.type} onChange={e => setFilter(f => ({ ...f, type: e.target.value }))}
          className="bg-zinc-900 border border-white/10 text-zinc-300 text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500">
          <option value="">All Types</option>
          {types.map(t => <option key={t} value={t}>{JOB_LABELS[t] || t}</option>)}
        </select>
        <button onClick={load} className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm rounded-lg transition-colors ml-auto">
          Refresh
        </button>
      </div>

      <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl overflow-hidden">
        {loading ? (
          <div className="py-16 text-center text-zinc-500">Loading…</div>
        ) : jobs.length === 0 ? (
          <div className="py-16 text-center text-zinc-500">No tasks found</div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {jobs.map(job => (
              <div key={job.id}>
                <button
                  onClick={() => setExpanded(expanded === job.id ? null : job.id)}
                  className="w-full px-5 py-3 flex items-center gap-4 hover:bg-white/[0.02] transition-colors text-left"
                >
                  <span className={`text-xs px-2 py-0.5 rounded-full border ${STATUS_COLOR[job.status]}`}>
                    {job.status === 'running' ? (
                      <span className="flex items-center gap-1">
                        <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse inline-block" />
                        running
                      </span>
                    ) : job.status}
                  </span>
                  <span className="text-zinc-300 text-sm font-medium w-32 flex-shrink-0">
                    {JOB_LABELS[job.type] || job.type}
                  </span>
                  <span className="text-zinc-500 text-xs flex-1 truncate">
                    {job.serverId ? `server:${job.serverId.slice(-6)}` : job.clusterId ? `cluster:${job.clusterId.slice(-6)}` : '—'}
                  </span>
                  {job.upid && (
                    <span className="text-zinc-600 text-xs font-mono hidden lg:block truncate max-w-xs">
                      {job.upid}
                    </span>
                  )}
                  {job.progress > 0 && job.status === 'running' && (
                    <div className="w-24 h-1.5 bg-zinc-800 rounded-full overflow-hidden hidden sm:block">
                      <div className="h-full bg-blue-500 rounded-full transition-all" style={{ width: `${Math.min(100, job.progress)}%` }} />
                    </div>
                  )}
                  <span className="text-zinc-600 text-xs flex-shrink-0">
                    {new Date(job.createdAt).toLocaleString()}
                  </span>
                  <span className="text-zinc-600 text-xs w-16 text-right flex-shrink-0">
                    {fmtDuration(job.createdAt, job.completedAt)}
                  </span>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
                    className={`w-4 h-4 text-zinc-600 flex-shrink-0 transition-transform ${expanded === job.id ? 'rotate-180' : ''}`}>
                    <polyline points="6 9 12 15 18 9" />
                  </svg>
                </button>
                {expanded === job.id && (
                  <div className="px-5 py-4 bg-black/20 border-t border-white/[0.04] space-y-3">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                      <div>
                        <div className="text-zinc-600 mb-1">Job ID</div>
                        <div className="text-zinc-300 font-mono">{job.id}</div>
                      </div>
                      <div>
                        <div className="text-zinc-600 mb-1">Node</div>
                        <div className="text-zinc-300">{job.node || '—'}</div>
                      </div>
                      <div>
                        <div className="text-zinc-600 mb-1">VMID</div>
                        <div className="text-zinc-300">{job.vmid || '—'}</div>
                      </div>
                      <div>
                        <div className="text-zinc-600 mb-1">Started</div>
                        <div className="text-zinc-300">{job.startedAt ? new Date(job.startedAt).toLocaleString() : '—'}</div>
                      </div>
                    </div>
                    {job.upid && (
                      <div>
                        <div className="text-zinc-600 text-xs mb-1">UPID</div>
                        <div className="text-zinc-300 font-mono text-xs bg-zinc-900 rounded px-2 py-1 break-all">{job.upid}</div>
                      </div>
                    )}
                    {job.message && (
                      <div>
                        <div className="text-zinc-600 text-xs mb-1">Message</div>
                        <div className="text-zinc-300 text-xs">{job.message}</div>
                      </div>
                    )}
                    {job.error && (
                      <div>
                        <div className="text-red-500 text-xs mb-1">Error</div>
                        <div className="text-red-300 text-xs bg-red-500/5 border border-red-500/20 rounded px-3 py-2 font-mono">{job.error}</div>
                      </div>
                    )}
                    {job.input && (
                      <details className="text-xs">
                        <summary className="text-zinc-600 cursor-pointer hover:text-zinc-400">Input params</summary>
                        <pre className="mt-2 text-zinc-400 bg-zinc-900 rounded p-2 overflow-x-auto text-[10px]">
                          {JSON.stringify(JSON.parse(job.input || '{}'), null, 2)}
                        </pre>
                      </details>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
