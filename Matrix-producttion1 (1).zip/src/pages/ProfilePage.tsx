import { useState } from 'react'
import { useAuth } from '../lib/auth'
import { apiFetch } from '../lib/api'

export default function ProfilePage() {
  const { user } = useAuth()
  const [tab, setTab] = useState<'profile' | 'password' | 'security'>('profile')

  const [form, setForm] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    username: user?.username || '',
  })
  const [saving, setSaving] = useState(false)
  const [saveMsg, setSaveMsg] = useState('')

  const [pwd, setPwd] = useState({ current: '', newPwd: '', confirm: '' })
  const [pwdMsg, setPwdMsg] = useState('')
  const [pwdErr, setPwdErr] = useState('')
  const [pwdSaving, setPwdSaving] = useState(false)

  const displayName = user?.firstName
    ? `${user.firstName}${user.lastName ? ' ' + user.lastName : ''}`
    : user?.username || 'User'
  const initials = displayName.split(' ').map((p: string) => p[0]).join('').slice(0, 2).toUpperCase()
  const roleLabel: Record<string, string> = {
    superadmin: 'Super Admin', admin: 'Admin', support: 'Support', customer: 'Customer',
  }

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    setSaveMsg('')
    try {
      await apiFetch('/profile', { method: 'PUT', body: JSON.stringify(form) })
      setSaveMsg('Profile updated successfully.')
    } catch (err: any) {
      setSaveMsg(err.message || 'Failed to save.')
    } finally {
      setSaving(false)
    }
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault()
    setPwdErr('')
    setPwdMsg('')
    if (pwd.newPwd !== pwd.confirm) { setPwdErr('New passwords do not match.'); return }
    if (pwd.newPwd.length < 8) { setPwdErr('Password must be at least 8 characters.'); return }
    setPwdSaving(true)
    try {
      await apiFetch('/profile/password', {
        method: 'PUT',
        body: JSON.stringify({ currentPassword: pwd.current, newPassword: pwd.newPwd }),
      })
      setPwdMsg('Password changed successfully.')
      setPwd({ current: '', newPwd: '', confirm: '' })
    } catch (err: any) {
      setPwdErr(err.message || 'Failed to change password.')
    } finally {
      setPwdSaving(false)
    }
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-7">
        <h1 className="text-2xl font-bold text-white">Account Settings</h1>
        <p className="text-zinc-500 text-sm mt-1">Manage your profile and security preferences.</p>
      </div>

      {/* Avatar card */}
      <div className="glass rounded-xl p-5 flex items-center gap-5 mb-6">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-600 to-violet-600 flex items-center justify-center text-white text-xl font-bold flex-shrink-0 shadow-lg">
          {initials}
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-white font-semibold text-lg">{displayName}</div>
          <div className="text-zinc-500 text-sm">{user?.email}</div>
          <span className="inline-flex items-center mt-1.5 text-[10px] font-semibold px-2 py-0.5 rounded border bg-blue-500/10 text-blue-400 border-blue-500/20 uppercase tracking-wide">
            {roleLabel[user?.role || 'customer']}
          </span>
        </div>
        <div className="hidden sm:block text-right text-xs text-zinc-600">
          <div>Member since</div>
          <div className="text-zinc-400">{user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : '—'}</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-5 bg-white/[0.03] rounded-lg p-1 border border-white/[0.06] w-fit">
        {(['profile', 'password', 'security'] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all capitalize ${
              tab === t ? 'bg-white/[0.08] text-white' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Profile tab */}
      {tab === 'profile' && (
        <div className="glass rounded-xl p-6">
          <h2 className="text-white font-semibold mb-5">Personal Information</h2>
          <form onSubmit={saveProfile} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">First name</label>
                <input value={form.firstName} onChange={e => setForm(f => ({ ...f, firstName: e.target.value }))}
                  placeholder="John" className="input-field w-full" />
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">Last name</label>
                <input value={form.lastName} onChange={e => setForm(f => ({ ...f, lastName: e.target.value }))}
                  placeholder="Doe" className="input-field w-full" />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Username</label>
              <input value={form.username} disabled
                className="w-full bg-white/[0.03] border border-white/[0.06] rounded-lg px-3.5 py-2.5 text-sm text-zinc-500 cursor-not-allowed" />
              <p className="text-zinc-700 text-xs mt-1">Username cannot be changed.</p>
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Email address</label>
              <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                required className="input-field w-full" />
            </div>
            {saveMsg && (
              <div className={`text-sm px-3.5 py-2.5 rounded-lg border ${saveMsg.includes('success') ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400'}`}>
                {saveMsg}
              </div>
            )}
            <button type="submit" disabled={saving}
              className="bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white font-semibold px-5 py-2 rounded-lg text-sm transition-all flex items-center gap-2">
              {saving && <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
              Save changes
            </button>
          </form>
        </div>
      )}

      {/* Password tab */}
      {tab === 'password' && (
        <div className="glass rounded-xl p-6">
          <h2 className="text-white font-semibold mb-1">Change Password</h2>
          <p className="text-zinc-500 text-sm mb-5">Use a strong password with at least 8 characters.</p>
          <form onSubmit={changePassword} className="space-y-4 max-w-sm">
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Current password</label>
              <input type="password" value={pwd.current} onChange={e => setPwd(p => ({ ...p, current: e.target.value }))}
                required autoComplete="current-password" className="input-field w-full" />
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">New password</label>
              <input type="password" value={pwd.newPwd} onChange={e => setPwd(p => ({ ...p, newPwd: e.target.value }))}
                required minLength={8} autoComplete="new-password" className="input-field w-full" />
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Confirm new password</label>
              <input type="password" value={pwd.confirm} onChange={e => setPwd(p => ({ ...p, confirm: e.target.value }))}
                required autoComplete="new-password" className="input-field w-full" />
            </div>
            {pwdErr && <div className="text-sm bg-red-500/10 border border-red-500/20 text-red-400 px-3.5 py-2.5 rounded-lg">{pwdErr}</div>}
            {pwdMsg && <div className="text-sm bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-3.5 py-2.5 rounded-lg">{pwdMsg}</div>}
            <button type="submit" disabled={pwdSaving}
              className="bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white font-semibold px-5 py-2 rounded-lg text-sm transition-all flex items-center gap-2">
              {pwdSaving && <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
              Update password
            </button>
          </form>
        </div>
      )}

      {/* Security tab */}
      {tab === 'security' && (
        <div className="glass rounded-xl p-6 space-y-5">
          <h2 className="text-white font-semibold mb-1">Security Overview</h2>

          <div className="flex items-center justify-between py-4 border-b border-white/[0.06]">
            <div>
              <div className="text-white text-sm font-medium">Two-Factor Authentication</div>
              <div className="text-zinc-500 text-xs mt-0.5">Add an extra layer of security to your account.</div>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 font-medium">
              Not enabled
            </span>
          </div>

          <div className="flex items-center justify-between py-4 border-b border-white/[0.06]">
            <div>
              <div className="text-white text-sm font-medium">Email Verified</div>
              <div className="text-zinc-500 text-xs mt-0.5">{user?.email}</div>
            </div>
            <span className={`text-xs px-2.5 py-1 rounded-full border font-medium ${user?.emailVerified ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-amber-500/10 border-amber-500/20 text-amber-400'}`}>
              {user?.emailVerified ? 'Verified' : 'Unverified'}
            </span>
          </div>

          <div className="flex items-center justify-between py-4">
            <div>
              <div className="text-white text-sm font-medium">Account Role</div>
              <div className="text-zinc-500 text-xs mt-0.5">Your current permission level.</div>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 font-medium">
              {roleLabel[user?.role || 'customer']}
            </span>
          </div>
        </div>
      )}
    </div>
  )
}
