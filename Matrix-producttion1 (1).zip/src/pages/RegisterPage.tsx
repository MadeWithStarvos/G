import { useState } from 'react'
import { useAuth } from '../lib/auth'
import panelBg from '/bg.jpg'

interface Props {
  onNavigate: (r: any) => void
}

export default function RegisterPage({ onNavigate }: Props) {
  const { register } = useAuth()
  const [form, setForm] = useState({
    email: '', username: '', password: '', firstName: '', lastName: '',
  })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }))

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await register(form)
    } catch (err: any) {
      setError(err.message || 'Registration failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div
      className="min-h-screen flex items-center justify-center px-4 py-12 relative"
      style={{
        backgroundImage: `url(${panelBg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
      }}
    >
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-black/70 backdrop-blur-[2px]" />

      {/* Card */}
      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="flex items-center justify-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center shadow-lg shadow-blue-900/40">
            <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 text-white">
              <rect x="3" y="3" width="7" height="7" rx="1" fill="currentColor" opacity="0.9" />
              <rect x="14" y="3" width="7" height="7" rx="1" fill="currentColor" opacity="0.6" />
              <rect x="3" y="14" width="7" height="7" rx="1" fill="currentColor" opacity="0.6" />
              <rect x="14" y="14" width="7" height="7" rx="1" fill="currentColor" opacity="0.3" />
            </svg>
          </div>
          <span className="text-white font-bold text-xl tracking-wide">MatrixHost</span>
        </div>

        <div className="bg-white/[0.05] border border-white/[0.1] rounded-2xl p-8 shadow-2xl backdrop-blur-xl">
          <div className="mb-7">
            <h1 className="text-2xl font-bold text-white mb-1">Create account</h1>
            <p className="text-zinc-500 text-sm">Join MatrixHost today</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">First name</label>
                <input type="text" value={form.firstName} onChange={set('firstName')} placeholder="John"
                  className="w-full bg-white/[0.06] border border-white/[0.1] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60 focus:ring-1 focus:ring-blue-500/30 transition-all" />
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1.5">Last name</label>
                <input type="text" value={form.lastName} onChange={set('lastName')} placeholder="Doe"
                  className="w-full bg-white/[0.06] border border-white/[0.1] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60 focus:ring-1 focus:ring-blue-500/30 transition-all" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Username</label>
              <input type="text" value={form.username} onChange={set('username')} placeholder="johndoe"
                required pattern="[a-zA-Z0-9_-]+" minLength={3}
                className="w-full bg-white/[0.06] border border-white/[0.1] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60 focus:ring-1 focus:ring-blue-500/30 transition-all" />
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Email address</label>
              <input type="email" value={form.email} onChange={set('email')} placeholder="you@example.com"
                required autoComplete="email"
                className="w-full bg-white/[0.06] border border-white/[0.1] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60 focus:ring-1 focus:ring-blue-500/30 transition-all" />
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Password</label>
              <input type="password" value={form.password} onChange={set('password')} placeholder="Min 8 characters"
                required minLength={8} autoComplete="new-password"
                className="w-full bg-white/[0.06] border border-white/[0.1] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60 focus:ring-1 focus:ring-blue-500/30 transition-all" />
            </div>

            {error && (
              <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-lg px-3.5 py-2.5 text-red-400 text-sm">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4 flex-shrink-0">
                  <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
                </svg>
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white font-semibold py-2.5 rounded-lg transition-all text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-900/30 mt-2"
            >
              {loading && <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
              {loading ? 'Creating account…' : 'Create account'}
            </button>
          </form>

          <p className="text-center text-zinc-600 text-sm mt-6">
            Already have an account?{' '}
            <button onClick={() => onNavigate({ page: 'login' })}
              className="text-blue-400 hover:text-blue-300 transition-colors font-medium">
              Sign in
            </button>
          </p>
        </div>

        <p className="text-center text-zinc-700 text-xs mt-6">
          Powered by Proxmox VE · MatrixHost by Starvos
        </p>
      </div>
    </div>
  )
}
