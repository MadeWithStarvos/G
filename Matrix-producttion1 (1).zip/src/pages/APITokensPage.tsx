import { useState, useEffect } from 'react'
import { apiFetch } from '../lib/api'

interface Token {
  id: string
  name: string
  lastUsedAt: string | null
  expiresAt: string | null
  isActive: boolean
  createdAt: string
  scopes: string[]
  tokenPreview?: string
}

export default function APITokensPage() {
  const [tokens, setTokens] = useState<Token[]>([])
  const [loading, setLoading] = useState(true)
  const [showCreate, setShowCreate] = useState(false)
  const [name, setName] = useState('')
  const [creating, setCreating] = useState(false)
  const [newToken, setNewToken] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [revoking, setRevoking] = useState<string | null>(null)

  async function load() {
    try {
      const data = await apiFetch<Token[]>('/profile/tokens')
      setTokens(data)
    } catch { }
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  async function createToken(e: React.FormEvent) {
    e.preventDefault()
    setCreating(true)
    try {
      const res = await apiFetch<{ token: string; id: string }>('/profile/tokens', {
        method: 'POST',
        body: JSON.stringify({ name }),
      })
      setNewToken(res.token)
      setName('')
      setShowCreate(false)
      load()
    } catch (err: any) {
      alert(err.message)
    } finally {
      setCreating(false)
    }
  }

  async function revokeToken(id: string) {
    setRevoking(id)
    try {
      await apiFetch(`/profile/tokens/${id}`, { method: 'DELETE' })
      setTokens(t => t.filter(x => x.id !== id))
    } catch (err: any) {
      alert(err.message)
    } finally {
      setRevoking(null)
    }
  }

  function copyToken() {
    if (!newToken) return
    navigator.clipboard.writeText(newToken).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex items-start justify-between mb-7">
        <div>
          <h1 className="text-2xl font-bold text-white">API Tokens</h1>
          <p className="text-zinc-500 text-sm mt-1">Create tokens to access the MatrixHost API programmatically.</p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold px-4 py-2 rounded-lg text-sm transition-all shadow-lg shadow-blue-900/30"
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-4 h-4">
            <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
          </svg>
          New Token
        </button>
      </div>

      {/* New token revealed */}
      {newToken && (
        <div className="glass rounded-xl p-5 mb-5 border border-emerald-500/20 bg-emerald-500/5">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center flex-shrink-0 mt-0.5">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4 text-emerald-400">
                <path d="M20 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z" />
                <circle cx="12" cy="12" r="2" />
              </svg>
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-emerald-400 font-semibold text-sm mb-1">Token created — copy it now</div>
              <div className="text-zinc-400 text-xs mb-3">This token will never be shown again. Store it somewhere safe.</div>
              <div className="flex items-center gap-2">
                <code className="flex-1 bg-black/40 border border-white/[0.08] rounded-lg px-3 py-2 text-xs text-zinc-300 font-mono truncate">
                  {newToken}
                </code>
                <button onClick={copyToken}
                  className={`flex-shrink-0 px-3 py-2 rounded-lg text-xs font-medium transition-all border ${copied ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-white/[0.06] border-white/[0.1] text-zinc-300 hover:text-white'}`}>
                  {copied ? 'Copied!' : 'Copy'}
                </button>
              </div>
            </div>
            <button onClick={() => setNewToken(null)} className="text-zinc-600 hover:text-zinc-400 transition-colors flex-shrink-0">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4">
                <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {/* Create form */}
      {showCreate && (
        <div className="glass rounded-xl p-5 mb-5">
          <h3 className="text-white font-semibold text-sm mb-4">Create New Token</h3>
          <form onSubmit={createToken} className="flex gap-3">
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Token name (e.g. CLI access)"
              required
              className="flex-1 input-field"
            />
            <button type="submit" disabled={creating}
              className="bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white font-semibold px-4 py-2 rounded-lg text-sm transition-all flex items-center gap-2 flex-shrink-0">
              {creating && <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
              Create
            </button>
            <button type="button" onClick={() => setShowCreate(false)}
              className="text-zinc-500 hover:text-zinc-300 px-3 py-2 rounded-lg text-sm transition-colors border border-white/[0.06] flex-shrink-0">
              Cancel
            </button>
          </form>
        </div>
      )}

      {/* Token list */}
      <div className="glass rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-white/[0.06]">
          <h2 className="text-white font-semibold text-sm">Active Tokens</h2>
        </div>

        {loading ? (
          <div className="p-8 flex justify-center">
            <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : !tokens.length ? (
          <div className="flex flex-col items-center justify-center py-14 text-center px-6">
            <div className="w-12 h-12 rounded-xl bg-zinc-800 flex items-center justify-center mb-4">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-6 h-6 text-zinc-600">
                <path d="M20 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z" />
                <circle cx="12" cy="12" r="2" />
              </svg>
            </div>
            <p className="text-white font-medium text-sm">No API tokens</p>
            <p className="text-zinc-600 text-xs mt-1">Create a token to get API access.</p>
          </div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {tokens.map(t => (
              <div key={t.id} className="flex items-center gap-4 px-5 py-4">
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4 text-blue-400">
                    <path d="M20 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z" />
                    <circle cx="12" cy="12" r="2" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-white text-sm font-medium">{t.name}</div>
                  <div className="text-zinc-600 text-xs mt-0.5">
                    Created {new Date(t.createdAt).toLocaleDateString()}
                    {t.lastUsedAt && ` · Last used ${new Date(t.lastUsedAt).toLocaleDateString()}`}
                    {t.expiresAt && ` · Expires ${new Date(t.expiresAt).toLocaleDateString()}`}
                  </div>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded border bg-emerald-500/10 border-emerald-500/20 text-emerald-400 uppercase font-semibold tracking-wide">
                  Active
                </span>
                <button
                  onClick={() => revokeToken(t.id)}
                  disabled={revoking === t.id}
                  className="text-zinc-600 hover:text-red-400 transition-colors p-1.5 rounded-lg hover:bg-red-500/10 flex-shrink-0"
                  title="Revoke token"
                >
                  {revoking === t.id
                    ? <div className="w-4 h-4 border-2 border-red-400/30 border-t-red-400 rounded-full animate-spin" />
                    : <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4">
                        <polyline points="3 6 5 6 21 6" /><path d="M19 6l-1 14H6L5 6" /><path d="M10 11v6" /><path d="M14 11v6" />
                      </svg>
                  }
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Info */}
      <div className="mt-4 px-1">
        <p className="text-zinc-700 text-xs">
          Tokens grant full API access to your account. Revoke immediately if compromised.
          Use the <code className="text-zinc-500">Authorization: Bearer &lt;token&gt;</code> header in requests.
        </p>
      </div>
    </div>
  )
}
