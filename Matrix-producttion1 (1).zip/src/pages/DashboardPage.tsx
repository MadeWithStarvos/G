import { useState, useEffect } from 'react'
import { api } from '../lib/api'
import type { ServerDashboard } from '../lib/api'
import { useAuth } from '../lib/auth'

interface Props {
  navigate: (r: any) => void
}

export default function DashboardPage({ navigate }: Props) {
  const { user } = useAuth()
  const [data, setData] = useState<ServerDashboard | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    api.servers.dashboard()
      .then(setData)
      .catch(e => setError(e.message))
      .finally(() => setLoading(false))
  }, [])

  const displayName = user?.firstName || user?.username || 'there'

  if (loading) return <PageSkeleton />
  if (error) return <ErrorState message={error} />

  const stats = [
    { label: 'Total Servers', value: data?.total ?? 0, color: 'blue', icon: ServerIcon },
    { label: 'Running', value: data?.running ?? 0, color: 'emerald', icon: PlayIcon },
    { label: 'Stopped', value: data?.stopped ?? 0, color: 'zinc', icon: StopIcon },
    { label: 'Suspended', value: data?.suspended ?? 0, color: 'amber', icon: PauseIcon },
  ]

  const resources = [
    { label: 'Total vCPU', value: data?.totalVcpu ?? 0, unit: 'cores', icon: CpuIcon },
    { label: 'Total RAM', value: formatRam(data?.totalRam ?? 0), unit: '', icon: MemIcon },
    { label: 'Total Storage', value: `${data?.totalDisk ?? 0}`, unit: 'GB', icon: DiskIcon },
  ]

  return (
    <div className="max-w-6xl mx-auto animate-fade-in">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">
          Welcome back, <span className="gradient-text">{displayName}</span>
        </h1>
        <p className="text-zinc-500 text-sm mt-1">Here's what's happening with your infrastructure.</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {stats.map(s => (
          <div key={s.label} className="glass rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-zinc-500 text-xs font-medium">{s.label}</span>
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${colorMap[s.color].bg}`}>
                <s.icon className={`w-3.5 h-3.5 ${colorMap[s.color].text}`} />
              </div>
            </div>
            <div className={`text-2xl font-bold ${colorMap[s.color].text}`}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Resources row */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        {resources.map(r => (
          <div key={r.label} className="glass rounded-xl p-4 flex items-center gap-4">
            <div className="w-9 h-9 rounded-lg bg-blue-500/10 flex items-center justify-center flex-shrink-0">
              <r.icon className="w-4 h-4 text-blue-400" />
            </div>
            <div>
              <div className="text-zinc-500 text-xs">{r.label}</div>
              <div className="text-white font-semibold text-sm">{r.value} <span className="text-zinc-500 font-normal text-xs">{r.unit}</span></div>
            </div>
          </div>
        ))}
      </div>

      {/* Server list */}
      <div className="glass rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.06]">
          <h2 className="text-white font-semibold text-sm">Your Servers</h2>
          <button
            onClick={() => navigate({ page: 'servers' })}
            className="text-blue-400 hover:text-blue-300 text-xs font-medium transition-colors"
          >
            View all
          </button>
        </div>

        {!data?.servers?.length ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-12 h-12 rounded-xl bg-zinc-800 flex items-center justify-center mb-4">
              <ServerEmptyIcon />
            </div>
            <p className="text-white font-medium text-sm">No servers yet</p>
            <p className="text-zinc-600 text-xs mt-1">Your servers will appear here once provisioned.</p>
          </div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {data.servers.slice(0, 6).map(server => (
              <div
                key={server.id}
                onClick={() => navigate({ page: 'server-detail', id: server.id })}
                className="flex items-center gap-4 px-5 py-3.5 hover:bg-white/[0.02] transition-colors cursor-pointer"
              >
                <span className={`status-dot ${server.isSuspended ? 'suspended' : server.status}`} />
                <div className="flex-1 min-w-0">
                  <div className="text-white text-sm font-medium truncate">{server.displayName}</div>
                  <div className="text-zinc-600 text-xs truncate">{server.hostname}</div>
                </div>
                <div className="hidden sm:flex items-center gap-4 text-xs text-zinc-500">
                  <span>{server.vcpuCores} vCPU</span>
                  <span>{formatRam(server.ramMb)}</span>
                  <span>{server.diskGb} GB</span>
                </div>
                <StatusBadge status={server.isSuspended ? 'suspended' : server.status} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

const colorMap: Record<string, { bg: string; text: string }> = {
  blue: { bg: 'bg-blue-500/10', text: 'text-blue-400' },
  emerald: { bg: 'bg-emerald-500/10', text: 'text-emerald-400' },
  zinc: { bg: 'bg-zinc-700/40', text: 'text-zinc-400' },
  amber: { bg: 'bg-amber-500/10', text: 'text-amber-400' },
}

function formatRam(mb: number) {
  if (mb >= 1024) return `${(mb / 1024).toFixed(mb % 1024 === 0 ? 0 : 1)} GB`
  return `${mb} MB`
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    running: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    stopped: 'bg-zinc-700/40 text-zinc-400 border-zinc-600/20',
    suspended: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    provisioning: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    failed: 'bg-red-500/10 text-red-400 border-red-500/20',
  }
  return (
    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border uppercase tracking-wide ${map[status] || map.stopped}`}>
      {status}
    </span>
  )
}

function PageSkeleton() {
  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="skeleton h-8 w-64 rounded-lg" />
      <div className="grid grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => <div key={i} className="skeleton h-24 rounded-xl" />)}
      </div>
      <div className="skeleton h-48 rounded-xl" />
    </div>
  )
}

function ErrorState({ message }: { message: string }) {
  return (
    <div className="flex items-center justify-center min-h-64">
      <div className="text-center">
        <p className="text-red-400 text-sm">{message}</p>
      </div>
    </div>
  )
}

function ServerIcon({ className }: { className?: string }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><rect x="2" y="2" width="20" height="8" rx="2" /><rect x="2" y="14" width="20" height="8" rx="2" /></svg>
}
function PlayIcon({ className }: { className?: string }) {
  return <svg viewBox="0 0 24 24" fill="currentColor" className={className}><polygon points="5 3 19 12 5 21 5 3" /></svg>
}
function StopIcon({ className }: { className?: string }) {
  return <svg viewBox="0 0 24 24" fill="currentColor" className={className}><rect x="3" y="3" width="18" height="18" rx="2" /></svg>
}
function PauseIcon({ className }: { className?: string }) {
  return <svg viewBox="0 0 24 24" fill="currentColor" className={className}><rect x="6" y="4" width="4" height="16" /><rect x="14" y="4" width="4" height="16" /></svg>
}
function CpuIcon({ className }: { className?: string }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><rect x="4" y="4" width="16" height="16" rx="2" /><rect x="9" y="9" width="6" height="6" /></svg>
}
function MemIcon({ className }: { className?: string }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><rect x="2" y="6" width="20" height="12" rx="2" /><line x1="6" y1="10" x2="6" y2="14" /><line x1="10" y1="10" x2="10" y2="14" /><line x1="14" y1="10" x2="14" y2="14" /><line x1="18" y1="10" x2="18" y2="14" /></svg>
}
function DiskIcon({ className }: { className?: string }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><ellipse cx="12" cy="5" rx="9" ry="3" /><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" /><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" /></svg>
}
function ServerEmptyIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-6 h-6 text-zinc-600"><rect x="2" y="2" width="20" height="8" rx="2" /><rect x="2" y="14" width="20" height="8" rx="2" /></svg>
}
