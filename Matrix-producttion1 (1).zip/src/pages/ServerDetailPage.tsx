import { useState, useEffect, useRef } from 'react'
import { api } from '../lib/api'
import type { Server, Job, MetricPoint, Snapshot, PveSnapshot, ServerTimer, Backup, Template } from '../lib/api'

interface Props { id: string; navigate: (r: any) => void }

type Tab = 'overview' | 'metrics' | 'snapshots' | 'backups' | 'reinstall' | 'resize' | 'migrate'

export default function ServerDetailPage({ id, navigate }: Props) {
  const [server, setServer] = useState<Server | null>(null)
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState('')
  const [error, setError] = useState('')
  const [toast, setToast] = useState('')
  const [tab, setTab] = useState<Tab>('overview')
  const [currentJob, setCurrentJob] = useState<Job | null>(null)
  const [editingExpiry, setEditingExpiry] = useState(false)
  const [expiryValue, setExpiryValue] = useState('')

  useEffect(() => {
    api.servers.get(id).then(s => {
      setServer(s)
      setExpiryValue(s.expiresAt ? s.expiresAt.slice(0, 16) : '')
    }).catch(e => setError(e.message)).finally(() => setLoading(false))
  }, [id])

  function showToast(msg: string) { setToast(msg); setTimeout(() => setToast(''), 4000) }

  async function doAction(action: string) {
    if (!server) return
    setActionLoading(action)
    try {
      const res = await api.servers.power(id, action)
      if (res.jobId) {
        showToast(`${action} queued — tracking job…`)
        trackJob(res.jobId)
      } else {
        setServer(s => s ? { ...s, status: (res.status || s.status) as any } : s)
        showToast(`${action.charAt(0).toUpperCase() + action.slice(1)} sent`)
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`)
    } finally { setActionLoading('') }
  }

  function trackJob(jobId: string) {
    let tries = 0
    const poll = setInterval(async () => {
      tries++
      if (tries > 120) { clearInterval(poll); setCurrentJob(null); return }
      try {
        const job = await api.servers.getJob(jobId)
        setCurrentJob(job)
        if (job.status === 'completed' || job.status === 'failed') {
          clearInterval(poll)
          setTimeout(() => setCurrentJob(null), 3000)
          if (job.status === 'completed') {
            const updated = await api.servers.get(id)
            setServer(updated)
          } else {
            showToast(`Job failed: ${job.error}`)
          }
        }
      } catch {}
    }, 2000)
  }

  async function updateExpiry() {
    if (!server) return
    try {
      const res = await fetch('/api/admin/servers/' + server.id + '/meta', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token') || ''}` },
        body: JSON.stringify({ expiresAt: expiryValue || null })
      })
      if (!res.ok) throw new Error('Unable to update expiry')
      const updated = await res.json()
      setServer(s => s ? { ...s, expiresAt: updated.expiresAt ?? null } : s)
      showToast('Expiry updated')
    } catch (e: any) {
      showToast(`Error: ${e.message}`)
    }
  }

  async function syncStatus() {
    if (!server) return
    try {
      const res = await api.servers.sync(id) as any
      if (res.synced) { setServer(res.server); showToast('Status synced from Proxmox') }
      else showToast(res.reason || 'No Proxmox connection')
    } catch (e: any) { showToast(`Sync error: ${e.message}`) }
  }

  if (loading) return <Skeleton />
  if (error || !server) return (
    <div className="flex items-center justify-center min-h-64">
      <div className="text-center">
        <p className="text-red-400 text-sm mb-3">{error || 'Server not found'}</p>
        <button onClick={() => navigate({ page: 'servers' })} className="text-blue-400 text-sm hover:underline">Back to servers</button>
      </div>
    </div>
  )

  const status = server.isSuspended ? 'suspended' : server.status
  const isRunning = server.status === 'running' && !server.isSuspended
  const isStopped = server.status === 'stopped' && !server.isSuspended

  return (
    <div className="max-w-5xl mx-auto animate-fade-in">
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-zinc-800 border border-white/10 text-white text-sm px-4 py-3 rounded-xl shadow-2xl animate-slide-up">{toast}</div>
      )}

      {/* Back + header */}
      <div className="flex items-start gap-4 mb-5">
        <button onClick={() => navigate({ page: 'servers' })} className="mt-1 text-zinc-600 hover:text-zinc-400 transition-colors">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><polyline points="15 18 9 12 15 6" /></svg>
        </button>
        <div className="flex-1">
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-xl font-bold text-white">{server.displayName}</h1>
            <StatusBadge status={status} />
            {server.vmid && <span className="text-zinc-600 text-xs font-mono">VMID: {server.vmid}</span>}
          </div>
          <p className="text-zinc-500 text-sm font-mono mt-0.5">{server.hostname}</p>
        </div>
        <button onClick={syncStatus} className="text-zinc-500 hover:text-zinc-300 text-xs flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/[0.08] hover:border-white/20 transition-all">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-3 h-3"><polyline points="1 4 1 10 7 10" /><polyline points="23 20 23 14 17 14" /><path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4-4.64 4.36A9 9 0 0 1 3.51 15" /></svg>
          Sync
        </button>
      </div>

      {/* Job tracker */}
      {currentJob && (
        <div className="mb-4 glass rounded-xl px-4 py-3 flex items-center gap-3">
          <div className="w-3.5 h-3.5 border-2 border-blue-400 border-t-transparent rounded-full animate-spin flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-white text-xs font-medium capitalize">{currentJob.type.replace('_', ' ')}</span>
              <span className="text-zinc-500 text-xs">{currentJob.message}</span>
            </div>
            <p className="text-zinc-500 text-xs truncate">Stage {Math.ceil(currentJob.progress / 10)} of 10</p>
          </div>
          <div className="w-24 bg-zinc-800 rounded-full h-1">
            <div className="bg-blue-500 h-1 rounded-full transition-all" style={{ width: `${currentJob.progress}%` }} />
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-white/[0.03] border border-white/[0.06] rounded-xl mb-5 overflow-x-auto">
        {(['overview', 'metrics', 'snapshots', 'backups', 'resize', 'reinstall', 'migrate'] as Tab[]).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`flex-shrink-0 px-3 py-2 rounded-lg text-xs font-medium capitalize transition-all ${tab === t ? 'bg-blue-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-white/[0.04]'}`}
          >{t}</button>
        ))}
      </div>

      {/* Tab content */}
      {tab === 'overview' && (
        <OverviewTab
          server={server}
          isRunning={isRunning}
          isStopped={isStopped}
          actionLoading={actionLoading}
          doAction={doAction}
          editingExpiry={editingExpiry}
          expiryValue={expiryValue}
          setEditingExpiry={setEditingExpiry}
          setExpiryValue={setExpiryValue}
          updateExpiry={updateExpiry}
        />
      )}
      {tab === 'metrics' && <MetricsTab server={server} />}
      {tab === 'snapshots' && <SnapshotsTab server={server} showToast={showToast} />}
      {tab === 'backups' && <BackupsTab server={server} showToast={showToast} trackJob={trackJob} />}
      {tab === 'resize' && <ResizeTab server={server} showToast={showToast} trackJob={trackJob} setServer={setServer} />}
      {tab === 'reinstall' && <ReinstallTab server={server} showToast={showToast} trackJob={trackJob} />}
      {tab === 'migrate' && <MigrateTab server={server} showToast={showToast} trackJob={trackJob} />}
    </div>
  )
}

// ─── Overview Tab ─────────────────────────────────────────────────────────────
function OverviewTab({ server, isRunning, isStopped, actionLoading, doAction, editingExpiry, expiryValue, setEditingExpiry, setExpiryValue, updateExpiry }: {
  server: Server; isRunning: boolean; isStopped: boolean; actionLoading: string; doAction: (a: string) => void
  editingExpiry: boolean; expiryValue: string; setEditingExpiry: (value: boolean | ((prev: boolean) => boolean)) => void
  setExpiryValue: (value: string) => void; updateExpiry: () => void
}) {
  return (
    <div className="space-y-4">
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 glass rounded-xl p-5">
          <h3 className="text-white font-semibold text-sm mb-4">Server Overview</h3>
          <div className="grid grid-cols-2 gap-x-8 gap-y-3">
            {[
              ['ID', server.id.slice(0, 12) + '…'],
              ['Type', server.virtType.toUpperCase()],
              ['vCPU', `${server.vcpuCores} cores`],
              ['RAM', formatRam(server.ramMb)],
              ['Disk', `${server.diskGb} GB`],
              ['OS', server.os || '—'],
              ['IPv4', server.primaryIpv4 || '—'],
              ['IPv6', server.primaryIpv6 || '—'],
              ['Created', new Date(server.createdAt).toLocaleDateString()],
              ['VMID', server.vmid?.toString() || '—'],
            ].map(([k, v]) => (
              <div key={k}>
                <div className="text-zinc-600 text-xs mb-0.5">{k}</div>
                <div className="text-white text-sm font-mono">{v}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass rounded-xl p-5">
          <h3 className="text-white font-semibold text-sm mb-4">Power Controls</h3>
          {server.isSuspended && (
            <div className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 rounded-lg px-3 py-2.5 mb-4">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4 text-amber-400 flex-shrink-0"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" /><line x1="12" y1="9" x2="12" y2="13" /><line x1="12" y1="17" x2="12.01" y2="17" /></svg>
              <p className="text-amber-400 text-xs">Server is suspended</p>
            </div>
          )}
          <div className="space-y-2">
            {[
              { action: 'start', label: 'Start', disabled: isRunning, color: 'emerald' },
              { action: 'shutdown', label: 'Graceful Shutdown', disabled: isStopped, color: 'zinc' },
              { action: 'stop', label: 'Force Stop', disabled: isStopped, color: 'zinc' },
              { action: 'restart', label: 'Restart', disabled: isStopped, color: 'blue' },
              { action: 'reset', label: 'Force Reset', disabled: isStopped, color: 'red' },
            ].map(({ action, label, disabled, color }) => (
              <button key={action} disabled={disabled || !!server.isSuspended || !!actionLoading} onClick={() => doAction(action)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm transition-all border disabled:opacity-40 disabled:cursor-not-allowed ${colorBtnMap[color]}`}>
                <span className="font-medium">{label}</span>
                {actionLoading === action
                  ? <div className="w-3.5 h-3.5 border border-current border-t-transparent rounded-full animate-spin opacity-60" />
                  : <span className="text-xs opacity-50 font-mono">{action}</span>}
              </button>
            ))}
          </div>
        </div>
      </div>

      <TimerCard server={server} />
      <div className="glass rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-white font-semibold text-sm">Server Expiration</h3>
            <p className="text-zinc-500 text-xs mt-0.5">Set an expiry date to manage lifecycle and cleanup.</p>
          </div>
          <button onClick={() => setEditingExpiry((v: boolean) => !v)} className="text-xs px-3 py-1.5 rounded-lg border border-white/[0.08] text-zinc-300 hover:text-white transition-all">
            {editingExpiry ? 'Cancel' : 'Edit'}
          </button>
        </div>
        {server.expiresAt ? (
          <div className="text-zinc-400 text-sm">Expires {new Date(server.expiresAt).toLocaleString()}</div>
        ) : (
          <div className="text-zinc-500 text-sm">No expiration date set.</div>
        )}
        {editingExpiry && (
          <div className="mt-4 flex flex-wrap items-end gap-3">
            <div>
              <label className="block text-xs text-zinc-500 mb-1.5">Expiry Date</label>
              <input type="datetime-local" value={expiryValue} onChange={e => setExpiryValue(e.target.value)} className="bg-white/[0.05] border border-white/[0.08] rounded-lg px-3 py-2 text-sm text-white" />
            </div>
            <button onClick={updateExpiry} className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg text-sm">Save Expiry</button>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Timer Card ───────────────────────────────────────────────────────────────
function TimerCard({ server }: { server: Server }) {
  const [timer, setTimer] = useState<ServerTimer | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [action, setAction] = useState('shutdown')
  const [minutes, setMinutes] = useState(60)
  const [remaining, setRemaining] = useState('')
  const [toast, setToast] = useState('')

  function showToast(msg: string) { setToast(msg); setTimeout(() => setToast(''), 4000) }

  function loadTimer() {
    ;(api.servers as any).getTimer(server.id)
      .then((r: { timer: ServerTimer | null }) => setTimer(r.timer))
      .catch(() => {})
      .finally(() => setLoading(false))
  }

  useEffect(() => { loadTimer() }, [server.id])

  useEffect(() => {
    if (!timer) { setRemaining(''); return }
    function tick() {
      const diff = new Date(timer!.triggerAt).getTime() - Date.now()
      if (diff <= 0) { setRemaining('Executing…'); return }
      const h = Math.floor(diff / 3600000)
      const m = Math.floor((diff % 3600000) / 60000)
      const s = Math.floor((diff % 60000) / 1000)
      setRemaining(h > 0 ? `${h}h ${m}m ${s}s` : `${m}m ${s}s`)
    }
    tick()
    const id = setInterval(tick, 1000)
    return () => clearInterval(id)
  }, [timer])

  async function setTimerAction(e: React.FormEvent) {
    e.preventDefault()
    if (server.isSuspended) return
    setSaving(true)
    try {
      const t = await (api.servers as any).setTimer(server.id, action, minutes)
      setTimer(t)
      showToast(`Timer set — ${actionLabel(action)} in ${minutes}m`)
    } catch (e: any) { showToast(`Error: ${e.message}`) }
    finally { setSaving(false) }
  }

  async function cancelTimer() {
    try {
      await (api.servers as any).cancelTimer(server.id)
      setTimer(null)
      showToast('Timer cancelled')
    } catch (e: any) { showToast(`Error: ${e.message}`) }
  }

  if (loading) return <div className="skeleton h-24 rounded-xl" />

  return (
    <div className="glass rounded-xl p-5">
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-zinc-800 border border-white/10 text-white text-sm px-4 py-3 rounded-xl shadow-2xl">{toast}</div>
      )}
      <div className="flex items-center gap-2 mb-4">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4 text-zinc-400">
          <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
        </svg>
        <h3 className="text-white font-semibold text-sm">Power Timer</h3>
        <span className="text-zinc-600 text-xs">Schedule a power action at a future time</span>
      </div>

      {timer ? (
        <div className="flex items-center gap-4 bg-blue-500/5 border border-blue-500/15 rounded-xl px-4 py-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-blue-400 font-semibold text-sm capitalize">{actionLabel(timer.action)}</span>
              <span className="text-zinc-500 text-xs">scheduled in</span>
              <span className="text-white font-mono text-sm tabular-nums">{remaining || '…'}</span>
            </div>
            <p className="text-zinc-600 text-xs mt-0.5">
              At {new Date(timer.triggerAt).toLocaleTimeString()} · {new Date(timer.triggerAt).toLocaleDateString()}
            </p>
          </div>
          <button onClick={cancelTimer}
            className="flex-shrink-0 text-xs px-3 py-1.5 rounded-lg border border-red-500/20 text-red-400 hover:bg-red-500/10 transition-all">
            Cancel
          </button>
        </div>
      ) : (
        <form onSubmit={setTimerAction} className="flex items-end gap-3 flex-wrap">
          <div className="flex-1 min-w-[140px]">
            <label className="block text-xs text-zinc-500 mb-1.5">Action</label>
            <select value={action} onChange={e => setAction(e.target.value)}
              className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500/60 appearance-none">
              <option value="shutdown">Graceful Shutdown</option>
              <option value="stop">Force Stop</option>
              <option value="restart">Restart</option>
              <option value="reset">Force Reset</option>
              <option value="start">Start</option>
            </select>
          </div>
          <div className="w-36">
            <label className="block text-xs text-zinc-500 mb-1.5">In (minutes)</label>
            <input type="number" min={1} max={1440} value={minutes} onChange={e => setMinutes(Number(e.target.value))}
              className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500/60" />
          </div>
          <button type="submit" disabled={saving || !!server.isSuspended}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-all whitespace-nowrap">
            {saving && <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
            Set Timer
          </button>
        </form>
      )}
    </div>
  )
}

function actionLabel(a: string) {
  return { shutdown: 'Graceful Shutdown', stop: 'Force Stop', restart: 'Restart', reset: 'Force Reset', start: 'Start' }[a] ?? a
}

// ─── Metrics Tab ──────────────────────────────────────────────────────────────
function MetricsTab({ server }: { server: Server }) {
  const [data, setData] = useState<MetricPoint[]>([])
  const [timeframe, setTimeframe] = useState('hour')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    setLoading(true); setError('')
    api.servers.metrics(server.id, timeframe)
      .then(r => setData(r.data))
      .catch(e => setError(e.message))
      .finally(() => setLoading(false))
  }, [server.id, timeframe])

  if (!server.vmid || !server.clusterId) {
    return (
      <div className="glass rounded-xl p-8 flex flex-col items-center justify-center text-center gap-3">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-10 h-10 text-zinc-700"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12" /></svg>
        <p className="text-zinc-500 text-sm">Metrics are only available for servers assigned to Proxmox.</p>
      </div>
    )
  }

  const validData = data.filter(d => d.time > 0)

  return (
    <div className="space-y-4">
      <div className="glass rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white font-semibold text-sm">Resource Usage</h3>
          <div className="flex gap-1 p-1 bg-white/[0.03] border border-white/[0.06] rounded-lg">
            {['hour', 'day', 'week', 'month'].map(tf => (
              <button key={tf} onClick={() => setTimeframe(tf)}
                className={`px-3 py-1 rounded text-xs font-medium capitalize transition-all ${timeframe === tf ? 'bg-blue-600 text-white' : 'text-zinc-400 hover:text-white'}`}>
                {tf}
              </button>
            ))}
          </div>
        </div>

        {loading && <div className="flex justify-center py-8"><div className="w-6 h-6 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" /></div>}
        {error && <p className="text-red-400 text-sm text-center py-4">{error}</p>}

        {!loading && !error && validData.length > 0 && (
          <div className="space-y-4">
            <MiniChart label="CPU Usage" data={validData} valueKey="cpu" color="#3b82f6" unit="%" multiplier={100} />
            <MiniChart label="Memory Usage" data={validData} valueKey="mem" color="#8b5cf6" maxKey="maxmem" unit="" formatVal={formatBytes} />
            <MiniChart label="Network In" data={validData} valueKey="netin" color="#10b981" unit="/s" formatVal={formatBps} />
            <MiniChart label="Network Out" data={validData} valueKey="netout" color="#f59e0b" unit="/s" formatVal={formatBps} />
          </div>
        )}
        {!loading && !error && validData.length === 0 && (
          <p className="text-zinc-500 text-sm text-center py-6">No metrics data available yet. Start the server to collect data.</p>
        )}
      </div>
    </div>
  )
}

function MiniChart({ label, data, valueKey, color, maxKey, unit, multiplier = 1, formatVal }: {
  label: string; data: MetricPoint[]; valueKey: keyof MetricPoint; color: string
  maxKey?: keyof MetricPoint; unit: string; multiplier?: number
  formatVal?: (v: number) => string
}) {
  const vals = data.map(d => ((d[valueKey] as number) || 0) * multiplier)
  const maxVal = maxKey ? Math.max(...data.map(d => ((d[maxKey] as number) || 0) * multiplier)) : Math.max(...vals, 1)
  const latest = vals[vals.length - 1] || 0
  const display = formatVal ? formatVal(latest / multiplier) : `${(latest).toFixed(1)}${unit}`

  const points = vals.map((v, i) => {
    const x = (i / (vals.length - 1)) * 200
    const y = 30 - (v / (maxVal || 1)) * 28
    return `${x},${y}`
  }).join(' ')

  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-zinc-400 text-xs">{label}</span>
        <span className="text-white text-xs font-mono">{display}</span>
      </div>
      <div className="bg-white/[0.03] rounded-lg p-2">
        <svg viewBox="0 0 200 32" preserveAspectRatio="none" className="w-full h-10">
          <defs>
            <linearGradient id={`g-${label}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity="0.3" />
              <stop offset="100%" stopColor={color} stopOpacity="0" />
            </linearGradient>
          </defs>
          {vals.length > 1 && (
            <>
              <polygon
                points={`0,32 ${points} 200,32`}
                fill={`url(#g-${label})`}
              />
              <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" />
            </>
          )}
        </svg>
      </div>
    </div>
  )
}

// ─── Snapshots Tab ────────────────────────────────────────────────────────────
function SnapshotsTab({ server, showToast }: { server: Server; showToast: (m: string) => void }) {
  const [loading, setLoading] = useState(true)
  const [snaps, setSnaps] = useState<Snapshot[]>([])
  const [pveSnaps, setPveSnaps] = useState<PveSnapshot[]>([])
  const [creating, setCreating] = useState(false)
  const [name, setName] = useState('')
  const [desc, setDesc] = useState('')
  const [showForm, setShowForm] = useState(false)

  function load() {
    setLoading(true)
    api.servers.snapshots(server.id)
      .then(r => { setSnaps(r.snapshots); setPveSnaps(r.proxmoxSnapshots) })
      .catch(e => showToast(`Error: ${e.message}`))
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [server.id])

  async function createSnapshot(e: React.FormEvent) {
    e.preventDefault()
    if (!name.trim()) return
    setCreating(true)
    try {
      const res = await api.servers.createSnapshot(server.id, name.trim(), desc.trim() || undefined)
      showToast(`Snapshot queued (job ${res.jobId.slice(0, 8)})`)
      setShowForm(false); setName(''); setDesc('')
      setTimeout(load, 5000)
    } catch (e: any) { showToast(`Error: ${e.message}`) }
    finally { setCreating(false) }
  }

  async function deleteSnapshot(snapname: string) {
    if (!confirm(`Delete snapshot "${snapname}"?`)) return
    try {
      await api.servers.deleteSnapshot(server.id, snapname)
      showToast('Snapshot deletion queued')
      setTimeout(load, 5000)
    } catch (e: any) { showToast(`Error: ${e.message}`) }
  }

  async function rollback(snapname: string) {
    if (!confirm(`Roll back to "${snapname}"? The server will be stopped.`)) return
    try {
      await api.servers.rollbackSnapshot(server.id, snapname)
      showToast('Rollback queued')
    } catch (e: any) { showToast(`Error: ${e.message}`) }
  }

  if (!server.vmid || !server.clusterId) {
    return (
      <div className="glass rounded-xl p-8 flex flex-col items-center justify-center text-center gap-3">
        <p className="text-zinc-500 text-sm">Snapshots require a server assigned to a Proxmox node.</p>
      </div>
    )
  }

  const allSnaps = pveSnaps.length > 0 ? pveSnaps : snaps.map(s => ({ name: s.proxmoxName, description: s.name, parent: '', snaptime: new Date(s.createdAt).getTime() / 1000, running: 0 }))

  return (
    <div className="glass rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-white font-semibold text-sm">Snapshots ({allSnaps.length})</h3>
        <button onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold px-3 py-1.5 rounded-lg transition-all">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-3.5 h-3.5"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
          Create Snapshot
        </button>
      </div>

      {showForm && (
        <form onSubmit={createSnapshot} className="glass rounded-lg p-4 mb-4 space-y-3">
          <div>
            <label className="block text-xs text-zinc-400 mb-1">Snapshot Name</label>
            <input value={name} onChange={e => setName(e.target.value)} required placeholder="my-snapshot"
              className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3 py-2 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60" />
          </div>
          <div>
            <label className="block text-xs text-zinc-400 mb-1">Description (optional)</label>
            <input value={desc} onChange={e => setDesc(e.target.value)} placeholder="Before upgrade…"
              className="w-full bg-white/[0.05] border border-white/[0.08] rounded-lg px-3 py-2 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/60" />
          </div>
          <div className="flex gap-2">
            <button type="submit" disabled={creating}
              className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-semibold px-4 py-2 rounded-lg flex items-center gap-2">
              {creating && <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
              {creating ? 'Creating…' : 'Create'}
            </button>
            <button type="button" onClick={() => setShowForm(false)} className="text-zinc-400 hover:text-white text-sm px-4 py-2 rounded-lg border border-white/[0.08]">Cancel</button>
          </div>
        </form>
      )}

      {loading ? (
        <div className="space-y-2">{[...Array(3)].map((_, i) => <div key={i} className="skeleton h-14 rounded-lg" />)}</div>
      ) : allSnaps.length === 0 ? (
        <p className="text-zinc-500 text-sm text-center py-6">No snapshots yet. Create one above.</p>
      ) : (
        <div className="divide-y divide-white/[0.04]">
          {allSnaps.map(s => (
            <div key={s.name} className="flex items-center gap-3 py-3">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4 text-violet-400 flex-shrink-0"><path d="M12 2L2 7l10 5 10-5-10-5z" /><path d="M2 17l10 5 10-5" /><path d="M2 12l10 5 10-5" /></svg>
              <div className="flex-1 min-w-0">
                <div className="text-white text-sm font-mono">{s.name}</div>
                {s.description && <div className="text-zinc-500 text-xs">{s.description}</div>}
                {s.snaptime > 0 && <div className="text-zinc-600 text-xs">{new Date(s.snaptime * 1000).toLocaleString()}</div>}
              </div>
              <div className="flex items-center gap-1.5">
                <button onClick={() => rollback(s.name)} className="text-xs px-2.5 py-1 rounded border border-amber-500/20 text-amber-400 hover:bg-amber-500/10 transition-all">Rollback</button>
                <button onClick={() => deleteSnapshot(s.name)} className="text-xs px-2.5 py-1 rounded border border-red-500/20 text-red-400 hover:bg-red-500/10 transition-all">Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ─── Backups Tab ──────────────────────────────────────────────────────────────
function BackupsTab({ server, showToast, trackJob }: { server: Server; showToast: (m: string) => void; trackJob: (jobId: string) => void }) {
  const [backups, setBackups] = useState<Backup[]>([])
  const [loading, setLoading] = useState(true)
  const [storage, setStorage] = useState('local')
  const [mode, setMode] = useState<'stop' | 'suspend' | 'snapshot'>('stop')
  const [creating, setCreating] = useState(false)

  function load() {
    ;(api.servers as any).backups(server.id).then(setBackups).catch((e: any) => showToast(e.message)).finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [server.id])

  async function createBackup() {
    setCreating(true)
    try {
      const res = await (api.servers as any).createBackup(server.id, { storage, mode })
      showToast('Backup started')
      trackJob(res.jobId)
      setTimeout(load, 3000)
    } catch (e: any) { showToast(`Error: ${e.message}`) }
    finally { setCreating(false) }
  }

  async function restoreBackup(backupId: string) {
    if (!confirm('Restore from this backup? The server will be stopped and overwritten.')) return
    try {
      const res = await (api.servers as any).restoreBackup(server.id, backupId)
      showToast('Restore queued')
      trackJob(res.jobId)
    } catch (e: any) { showToast(`Error: ${e.message}`) }
  }

  async function deleteBackup(backupId: string) {
    if (!confirm('Delete this backup? This cannot be undone.')) return
    try {
      const res = await (api.servers as any).deleteBackup(server.id, backupId)
      showToast('Deletion queued')
      trackJob(res.jobId)
      setTimeout(load, 2000)
    } catch (e: any) { showToast(`Error: ${e.message}`) }
  }

  return (
    <div className="space-y-4">
      <div className="glass rounded-xl p-5">
        <h3 className="text-white font-semibold text-sm mb-4">Create Backup</h3>
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <label className="block text-zinc-400 text-xs mb-1">Storage</label>
            <input value={storage} onChange={e => setStorage(e.target.value)}
              className="w-full bg-zinc-900 border border-white/10 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500"
              placeholder="local" />
          </div>
          <div>
            <label className="block text-zinc-400 text-xs mb-1">Mode</label>
            <select value={mode} onChange={e => setMode(e.target.value as any)}
              className="w-full bg-zinc-900 border border-white/10 text-white text-sm rounded-lg px-3 py-2 focus:outline-none">
              <option value="stop">Stop (safest)</option>
              <option value="suspend">Suspend</option>
              <option value="snapshot">Snapshot (live)</option>
            </select>
          </div>
        </div>
        <button onClick={createBackup} disabled={creating}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg disabled:opacity-50 transition-colors">
          {creating ? 'Starting…' : 'Create Backup'}
        </button>
      </div>

      <div className="glass rounded-xl p-5">
        <h3 className="text-white font-semibold text-sm mb-4">Backups</h3>
        {loading ? <div className="skeleton h-24 rounded-lg" /> : backups.length === 0
          ? <p className="text-zinc-500 text-sm">No backups yet.</p>
          : (
            <div className="space-y-2">
              {backups.map(b => (
                <div key={b.id} className="flex items-center justify-between p-3 bg-zinc-900/50 rounded-lg border border-white/[0.06]">
                  <div>
                    <p className="text-white text-sm font-medium">{b.name}</p>
                    <p className="text-zinc-500 text-xs mt-0.5">{b.volid || 'Processing…'} {b.size ? `· ${(b.size / 1e9).toFixed(2)} GB` : ''}</p>
                    <p className="text-zinc-600 text-xs">{new Date(b.createdAt).toLocaleString()}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] uppercase font-semibold px-2 py-0.5 rounded border ${
                      b.status === 'available' ? 'border-emerald-500/20 bg-emerald-500/10 text-emerald-400'
                      : b.status === 'failed' ? 'border-red-500/20 bg-red-500/10 text-red-400'
                      : 'border-blue-500/20 bg-blue-500/10 text-blue-400'
                    }`}>{b.status}</span>
                    {b.status === 'available' && <>
                      <button onClick={() => restoreBackup(b.id)} className="text-xs px-2.5 py-1 rounded border border-amber-500/20 text-amber-400 hover:bg-amber-500/10 transition-colors">Restore</button>
                      <button onClick={() => deleteBackup(b.id)} className="text-xs px-2.5 py-1 rounded border border-red-500/20 text-red-400 hover:bg-red-500/10 transition-colors">Delete</button>
                    </>}
                  </div>
                </div>
              ))}
            </div>
          )}
      </div>
    </div>
  )
}

// ─── Resize Tab ───────────────────────────────────────────────────────────────
function ResizeTab({ server, showToast, trackJob, setServer }: {
  server: Server; showToast: (m: string) => void; trackJob: (jobId: string) => void
  setServer: (fn: (s: Server | null) => Server | null) => void
}) {
  const [vcpu, setVcpu] = useState(String(server.vcpuCores))
  const [ram, setRam] = useState(String(server.ramMb))
  const [disk, setDisk] = useState(String(server.diskGb))
  const [busy, setBusy] = useState(false)

  async function doResize() {
    const params: Record<string, number> = {}
    if (Number(vcpu) !== server.vcpuCores) params.vcpuCores = Number(vcpu)
    if (Number(ram) !== server.ramMb) params.ramMb = Number(ram)
    if (Number(disk) !== server.diskGb) params.diskGb = Number(disk)
    if (!Object.keys(params).length) { showToast('No changes to apply'); return }
    if (Number(disk) < server.diskGb) { showToast('Disk cannot be shrunk'); return }
    setBusy(true)
    try {
      const res = await (api.servers as any).resize(server.id, params)
      showToast('Resize queued — note: CPU/RAM changes require a restart')
      trackJob(res.jobId)
    } catch (e: any) { showToast(`Error: ${e.message}`) }
    finally { setBusy(false) }
  }

  return (
    <div className="glass rounded-xl p-5 max-w-md">
      <h3 className="text-white font-semibold text-sm mb-1">Resource Resize</h3>
      <p className="text-zinc-500 text-xs mb-4">CPU and RAM changes require a server restart. Disks can only be expanded.</p>
      <div className="space-y-3 mb-5">
        <div>
          <label className="block text-zinc-400 text-xs mb-1">vCPU Cores (current: {server.vcpuCores})</label>
          <input type="number" min="1" max="128" value={vcpu} onChange={e => setVcpu(e.target.value)}
            className="w-full bg-zinc-900 border border-white/10 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500" />
        </div>
        <div>
          <label className="block text-zinc-400 text-xs mb-1">RAM (MB) (current: {server.ramMb} MB)</label>
          <input type="number" min="256" step="256" value={ram} onChange={e => setRam(e.target.value)}
            className="w-full bg-zinc-900 border border-white/10 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500" />
        </div>
        <div>
          <label className="block text-zinc-400 text-xs mb-1">Disk (GB) — expand only (current: {server.diskGb} GB)</label>
          <input type="number" min={server.diskGb} value={disk} onChange={e => setDisk(e.target.value)}
            className="w-full bg-zinc-900 border border-white/10 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500" />
        </div>
      </div>
      {server.status === 'running' && (
        <div className="mb-4 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs">
          CPU and RAM changes will require a restart to take full effect.
        </div>
      )}
      <button onClick={doResize} disabled={busy}
        className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg disabled:opacity-50 transition-colors">
        {busy ? 'Applying…' : 'Apply Changes'}
      </button>
    </div>
  )
}

// ─── Reinstall Tab ────────────────────────────────────────────────────────────
function ReinstallTab({ server, showToast, trackJob }: { server: Server; showToast: (m: string) => void; trackJob: (jobId: string) => void }) {
  const [templates, setTemplates] = useState<Template[]>([])
  const [templateId, setTemplateId] = useState('')
  const [password, setPassword] = useState('')
  const [username, setUsername] = useState('root')
  const [confirmed, setConfirmed] = useState(false)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    api.admin.templates().then(ts => {
      const compatible = ts.filter(t => t.isEnabled && (t.virtType === (server.virtType === 'kvm' ? 'kvm' : 'lxc')))
      setTemplates(compatible)
      if (compatible.length) setTemplateId(compatible[0].id)
    }).catch(() => {})
  }, [server.id])

  async function doReinstall() {
    if (!confirmed) { showToast('Please confirm data destruction first'); return }
    if (!templateId) { showToast('Select a template'); return }
    setBusy(true)
    try {
      const res = await (api.servers as any).reinstall(server.id, { templateId, password, username })
      showToast('Reinstall queued')
      trackJob(res.jobId)
    } catch (e: any) { showToast(`Error: ${e.message}`) }
    finally { setBusy(false) }
  }

  return (
    <div className="glass rounded-xl p-5 max-w-md">
      <h3 className="text-white font-semibold text-sm mb-1">Reinstall OS</h3>
      <p className="text-zinc-500 text-xs mb-4">Destroys all data on the VM and reinstalls from a template. Network configuration is preserved.</p>
      <div className="space-y-3 mb-4">
        <div>
          <label className="block text-zinc-400 text-xs mb-1">Template</label>
          <select value={templateId} onChange={e => setTemplateId(e.target.value)}
            className="w-full bg-zinc-900 border border-white/10 text-white text-sm rounded-lg px-3 py-2 focus:outline-none">
            {templates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-zinc-400 text-xs mb-1">Username</label>
          <input value={username} onChange={e => setUsername(e.target.value)}
            className="w-full bg-zinc-900 border border-white/10 text-white text-sm rounded-lg px-3 py-2 focus:outline-none" placeholder="root" />
        </div>
        <div>
          <label className="block text-zinc-400 text-xs mb-1">Password</label>
          <input type="password" value={password} onChange={e => setPassword(e.target.value)}
            className="w-full bg-zinc-900 border border-white/10 text-white text-sm rounded-lg px-3 py-2 focus:outline-none" placeholder="New root password" />
        </div>
      </div>
      <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
        <p className="text-red-400 text-xs font-semibold mb-2">⚠ This will permanently destroy all data on the VM</p>
        <label className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" checked={confirmed} onChange={e => setConfirmed(e.target.checked)} className="w-4 h-4" />
          <span className="text-red-300 text-xs">I understand all data will be lost</span>
        </label>
      </div>
      <button onClick={doReinstall} disabled={busy || !confirmed || !templateId}
        className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm rounded-lg disabled:opacity-50 transition-colors">
        {busy ? 'Reinstalling…' : 'Reinstall OS'}
      </button>
    </div>
  )
}

// ─── Migrate Tab ──────────────────────────────────────────────────────────────
function MigrateTab({ server, showToast, trackJob }: { server: Server; showToast: (m: string) => void; trackJob: (jobId: string) => void }) {
  const [targetNode, setTargetNode] = useState('')
  const [targetStorage, setTargetStorage] = useState('')
  const [busy, setBusy] = useState(false)

  async function doMigrate() {
    if (!targetNode.trim()) { showToast('Enter a target node name'); return }
    setBusy(true)
    try {
      const res = await (api.servers as any).migrate(server.id, { targetNode: targetNode.trim(), targetStorage: targetStorage.trim() || undefined })
      showToast('Migration queued')
      trackJob(res.jobId)
    } catch (e: any) { showToast(`Error: ${e.message}`) }
    finally { setBusy(false) }
  }

  return (
    <div className="glass rounded-xl p-5 max-w-md">
      <h3 className="text-white font-semibold text-sm mb-1">Migrate to Node</h3>
      <p className="text-zinc-500 text-xs mb-4">Moves the VM to another node in the same cluster. Live migration is attempted when the server is running.</p>
      <div className="space-y-3 mb-5">
        <div>
          <label className="block text-zinc-400 text-xs mb-1">Target Node Name</label>
          <input value={targetNode} onChange={e => setTargetNode(e.target.value)}
            className="w-full bg-zinc-900 border border-white/10 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500"
            placeholder="pve2" />
        </div>
        <div>
          <label className="block text-zinc-400 text-xs mb-1">Target Storage (optional)</label>
          <input value={targetStorage} onChange={e => setTargetStorage(e.target.value)}
            className="w-full bg-zinc-900 border border-white/10 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500"
            placeholder="local-lvm (leave blank to keep same)" />
        </div>
      </div>
      {server.status === 'running' && (
        <div className="mb-4 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs">
          Server is running — live migration will be attempted (requires shared storage or compatible setup).
        </div>
      )}
      <button onClick={doMigrate} disabled={busy || !targetNode.trim()}
        className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg disabled:opacity-50 transition-colors">
        {busy ? 'Queueing…' : 'Start Migration'}
      </button>
    </div>
  )
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
const colorBtnMap: Record<string, string> = {
  emerald: 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20',
  zinc: 'bg-zinc-700/30 border-zinc-700/30 text-zinc-400 hover:bg-zinc-700/50',
  blue: 'bg-blue-500/10 border-blue-500/20 text-blue-400 hover:bg-blue-500/20',
  red: 'bg-red-500/10 border-red-500/20 text-red-400 hover:bg-red-500/20',
}

function formatRam(mb: number) {
  if (mb >= 1024) return `${(mb / 1024).toFixed(mb % 1024 === 0 ? 0 : 1)} GB`
  return `${mb} MB`
}

function formatBytes(bytes: number) {
  if (bytes > 1e9) return `${(bytes / 1e9).toFixed(1)} GB`
  if (bytes > 1e6) return `${(bytes / 1e6).toFixed(1)} MB`
  if (bytes > 1e3) return `${(bytes / 1e3).toFixed(1)} KB`
  return `${bytes} B`
}

function formatBps(bps: number) {
  if (bps > 1e6) return `${(bps / 1e6).toFixed(1)} MB/s`
  if (bps > 1e3) return `${(bps / 1e3).toFixed(1)} KB/s`
  return `${bps} B/s`
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    running: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    stopped: 'bg-zinc-700/40 text-zinc-400 border-zinc-600/20',
    suspended: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    provisioning: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    failed: 'bg-red-500/10 text-red-400 border-red-500/20',
    terminating: 'bg-red-500/10 text-red-400 border-red-500/20',
  }
  return (
    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border uppercase tracking-wide ${map[status] || map.stopped}`}>{status}</span>
  )
}

function Skeleton() {
  return (
    <div className="max-w-5xl mx-auto space-y-4">
      <div className="skeleton h-8 w-48 rounded-lg" />
      <div className="skeleton h-10 rounded-xl" />
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 skeleton h-56 rounded-xl" />
        <div className="skeleton h-56 rounded-xl" />
      </div>
    </div>
  )
}
