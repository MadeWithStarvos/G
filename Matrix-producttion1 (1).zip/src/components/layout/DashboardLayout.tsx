import { useState } from 'react'
import { useAuth } from '../../lib/auth'
import type { ReactNode } from 'react'

type NavPage = string

interface Props {
  children: ReactNode
  navigate: (r: any) => void
  currentPage: NavPage
}

const navItems = [
  { label: 'Dashboard', page: 'dashboard', icon: GridIcon },
  { label: 'Servers', page: 'servers', icon: ServerIcon },
]

const accountNavItems = [
  { label: 'Profile', page: 'profile', icon: UserIcon },
  { label: 'API Tokens', page: 'api-tokens', icon: KeyIcon },
]

const adminNavItems = [
  { label: 'Overview', page: 'admin-dashboard', icon: ChartIcon },
  { label: 'Servers', page: 'admin-servers', icon: ServerIcon },
  { label: 'Users', page: 'admin-users', icon: UsersIcon },
  { label: 'Clusters', page: 'admin-clusters', icon: CloudIcon },
  { label: 'Nodes', page: 'admin-nodes', icon: CpuIcon },
  { label: 'Templates', page: 'admin-templates', icon: LayersIcon },
  { label: 'Locations', page: 'admin-locations', icon: GlobeIcon },
  { label: 'Activity', page: 'admin-activity', icon: ActivityIcon },
  { label: 'Settings', page: 'admin-settings', icon: SettingsIcon },
]

const mockNotifications = [
  { id: '1', title: 'Node offline', message: 'Node pve01 is reporting an offline status and needs attention.', time: '2m ago', read: false, type: 'warning' },
  { id: '2', title: 'High load detected', message: 'CPU usage on pve02 exceeded 85% for the last 10 minutes.', time: '1h ago', read: false, type: 'warning' },
  { id: '3', title: 'Backup failed', message: 'A scheduled backup for one of the managed servers did not complete.', time: '1d ago', read: true, type: 'info' },
]

export default function DashboardLayout({ children, navigate, currentPage }: Props) {
  const { user, logout } = useAuth()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [adminExpanded, setAdminExpanded] = useState(currentPage.startsWith('admin'))
  const [accountExpanded, setAccountExpanded] = useState(['profile', 'api-tokens'].includes(currentPage))
  const [notifOpen, setNotifOpen] = useState(false)

  const isAdmin = user?.role === 'superadmin' || user?.role === 'admin'

  const displayName = user?.firstName
    ? `${user.firstName}${user.lastName ? ' ' + user.lastName : ''}`
    : user?.username || 'User'

  const initials = displayName.split(' ').map((p: string) => p[0]).join('').slice(0, 2).toUpperCase()
  const roleLabel = user?.role === 'superadmin' ? 'Super Admin' : user?.role === 'admin' ? 'Admin' : user?.role === 'support' ? 'Support' : 'Customer'

  const unreadCount = mockNotifications.filter(n => !n.read).length

  const notifTypeIcon: Record<string, string> = {
    success: 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400',
    warning: 'bg-amber-500/10 border-amber-500/20 text-amber-400',
    info: 'bg-blue-500/10 border-blue-500/20 text-blue-400',
  }

  return (
    <div className="min-h-screen flex">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/60 z-20 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Notifications overlay */}
      {notifOpen && (
        <div className="fixed inset-0 z-40" onClick={() => setNotifOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-30 w-64 flex flex-col
        bg-black/70 backdrop-blur-xl border-r border-white/[0.06]
        transform transition-transform duration-200 ease-in-out
        lg:translate-x-0 lg:static lg:z-auto
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-5 border-b border-white/[0.06]">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center flex-shrink-0 glow-blue">
            <MatrixIcon />
          </div>
          <div>
            <div className="text-white font-bold text-sm tracking-wide">MatrixHost</div>
            <div className="text-zinc-500 text-xs">by Starvos</div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-0.5">
          {navItems.map(item => (
            <NavButton
              key={item.page}
              label={item.label}
              icon={<item.icon />}
              active={currentPage === item.page}
              onClick={() => { navigate({ page: item.page }); setSidebarOpen(false) }}
            />
          ))}

          {/* Account section */}
          <div className="pt-4 pb-1 px-2">
            <button
              onClick={() => setAccountExpanded(!accountExpanded)}
              className="flex items-center justify-between w-full text-xs font-semibold text-zinc-500 uppercase tracking-widest hover:text-zinc-300 transition-colors"
            >
              <span>Account</span>
              <ChevronIcon className={`transition-transform ${accountExpanded ? 'rotate-180' : ''}`} />
            </button>
          </div>
          {accountExpanded && accountNavItems.map(item => (
            <NavButton
              key={item.page}
              label={item.label}
              icon={<item.icon />}
              active={currentPage === item.page}
              onClick={() => { navigate({ page: item.page }); setSidebarOpen(false) }}
            />
          ))}

          {isAdmin && (
            <>
              <div className="pt-4 pb-1 px-2">
                <button
                  onClick={() => setAdminExpanded(!adminExpanded)}
                  className="flex items-center justify-between w-full text-xs font-semibold text-zinc-500 uppercase tracking-widest hover:text-zinc-300 transition-colors"
                >
                  <span>Administration</span>
                  <ChevronIcon className={`transition-transform ${adminExpanded ? 'rotate-180' : ''}`} />
                </button>
              </div>
              {adminExpanded && adminNavItems.map(item => (
                <NavButton
                  key={item.page}
                  label={item.label}
                  icon={<item.icon />}
                  active={currentPage === item.page}
                  onClick={() => { navigate({ page: item.page }); setSidebarOpen(false) }}
                  admin
                />
              ))}
            </>
          )}
        </nav>

        {/* User footer */}
        <div className="px-3 py-4 border-t border-white/[0.06]">
          <button
            onClick={() => { navigate({ page: 'profile' }); setSidebarOpen(false) }}
            className="w-full flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-white/[0.04] transition-colors text-left"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-600 to-violet-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
              {initials}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-white text-sm font-medium truncate">{displayName}</div>
              <div className="text-zinc-500 text-xs">{roleLabel}</div>
            </div>
            <button
              onClick={e => { e.stopPropagation(); logout() }}
              className="text-zinc-600 hover:text-zinc-400 transition-colors p-1 rounded"
              title="Sign out"
            >
              <LogoutIcon />
            </button>
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
        {/* Top bar */}
        <header className="flex items-center gap-4 px-4 sm:px-6 py-4 border-b border-white/[0.06] bg-black/60 backdrop-blur-xl sticky top-0 z-10">
          <button
            className="lg:hidden text-zinc-400 hover:text-white transition-colors"
            onClick={() => setSidebarOpen(true)}
          >
            <MenuIcon />
          </button>
          <div className="flex-1" />
          <div className="flex items-center gap-3">
            {/* System status */}
            <div className="hidden sm:flex items-center gap-1.5 text-xs text-zinc-500">
              <span className="status-dot online" />
              <span>Online</span>
            </div>

            {/* Notifications bell */}
            <div className="relative">
              <button
                onClick={() => setNotifOpen(!notifOpen)}
                className="relative w-8 h-8 flex items-center justify-center rounded-lg text-zinc-400 hover:text-white hover:bg-white/[0.06] transition-all"
              >
                <BellIcon />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full" />
                )}
              </button>

              {notifOpen && (
                <div className="absolute right-0 top-full mt-2 w-80 bg-[#111] border border-white/[0.1] rounded-xl shadow-2xl z-50 overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-3 border-b border-white/[0.06]">
                    <span className="text-white font-semibold text-sm">Alerts Center</span>
                    {unreadCount > 0 && (
                      <span className="text-xs bg-blue-500/10 border border-blue-500/20 text-blue-400 px-2 py-0.5 rounded-full">
                        {unreadCount} new
                      </span>
                    )}
                  </div>
                  <div className="divide-y divide-white/[0.04] max-h-72 overflow-y-auto">
                    {mockNotifications.map(n => (
                      <div key={n.id} className={`px-4 py-3 hover:bg-white/[0.03] transition-colors ${!n.read ? 'bg-white/[0.02]' : ''}`}>
                        <div className="flex items-start gap-3">
                          <div className={`w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 ${!n.read ? 'bg-blue-500' : 'bg-transparent'}`} />
                          <div className="flex-1 min-w-0">
                            <div className="text-white text-xs font-medium">{n.title}</div>
                            <div className="text-zinc-500 text-xs mt-0.5">{n.message}</div>
                          </div>
                          <span className="text-zinc-600 text-[10px] flex-shrink-0">{n.time}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="px-4 py-2.5 border-t border-white/[0.06]">
                    <button className="text-blue-400 hover:text-blue-300 text-xs font-medium transition-colors">
                      Mark all as read
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Avatar quick link */}
            <button
              onClick={() => navigate({ page: 'profile' })}
              className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-600 to-violet-600 flex items-center justify-center text-white text-xs font-bold hover:opacity-80 transition-opacity"
              title="Profile"
            >
              {initials}
            </button>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-auto p-4 sm:p-6">
          {children}
        </main>
      </div>
    </div>
  )
}

function NavButton({ label, icon, active, onClick, admin }: {
  label: string; icon: ReactNode; active: boolean; onClick: () => void; admin?: boolean
}) {
  return (
    <button
      onClick={onClick}
      className={`
        w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-150
        ${active
          ? admin
            ? 'bg-violet-500/10 text-violet-400 border border-violet-500/20'
            : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
          : 'text-zinc-400 hover:text-white hover:bg-white/[0.04] border border-transparent'
        }
      `}
    >
      <span className="w-4 h-4 flex-shrink-0">{icon}</span>
      <span className="font-medium">{label}</span>
    </button>
  )
}

function MatrixIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" className="w-4 h-4 text-white">
      <rect x="3" y="3" width="7" height="7" rx="1" fill="currentColor" opacity="0.9" />
      <rect x="14" y="3" width="7" height="7" rx="1" fill="currentColor" opacity="0.6" />
      <rect x="3" y="14" width="7" height="7" rx="1" fill="currentColor" opacity="0.6" />
      <rect x="14" y="14" width="7" height="7" rx="1" fill="currentColor" opacity="0.3" />
    </svg>
  )
}
function GridIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></svg>
}
function ServerIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><rect x="2" y="2" width="20" height="8" rx="2" /><rect x="2" y="14" width="20" height="8" rx="2" /><line x1="6" y1="6" x2="6.01" y2="6" /><line x1="6" y1="18" x2="6.01" y2="18" /></svg>
}
function UserIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>
}
function KeyIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><path d="M20 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z" /><circle cx="12" cy="12" r="2" /></svg>
}
function CreditCardIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><rect x="1" y="4" width="22" height="16" rx="2" /><line x1="1" y1="10" x2="23" y2="10" /></svg>
}
function ChartIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><line x1="18" y1="20" x2="18" y2="10" /><line x1="12" y1="20" x2="12" y2="4" /><line x1="6" y1="20" x2="6" y2="14" /></svg>
}
function UsersIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>
}
function CloudIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" /></svg>
}
function CpuIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><rect x="4" y="4" width="16" height="16" rx="2" /><rect x="9" y="9" width="6" height="6" /><line x1="9" y1="1" x2="9" y2="4" /><line x1="15" y1="1" x2="15" y2="4" /><line x1="9" y1="20" x2="9" y2="23" /><line x1="15" y1="20" x2="15" y2="23" /><line x1="20" y1="9" x2="23" y2="9" /><line x1="20" y1="14" x2="23" y2="14" /><line x1="1" y1="9" x2="4" y2="9" /><line x1="1" y1="14" x2="4" y2="14" /></svg>
}
function LayersIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><polygon points="12 2 2 7 12 12 22 7 12 2" /><polyline points="2 17 12 22 22 17" /><polyline points="2 12 12 17 22 12" /></svg>
}
function GlobeIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><circle cx="12" cy="12" r="10" /><line x1="2" y1="12" x2="22" y2="12" /><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" /></svg>
}
function ActivityIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12" /></svg>
}
function LogoutIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" y1="12" x2="9" y2="12" /></svg>
}
function MenuIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5"><line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="18" x2="21" y2="18" /></svg>
}
function BellIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.73 21a2 2 0 0 1-3.46 0" /></svg>
}
function SettingsIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" /></svg>
}
function ChevronIcon({ className }: { className?: string }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={`w-3 h-3 ${className}`}><polyline points="6 9 12 15 18 9" /></svg>
}
