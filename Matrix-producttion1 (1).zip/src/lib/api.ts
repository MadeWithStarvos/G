const BASE = '/api'

export async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const token = localStorage.getItem('token')
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options?.headers,
    },
  })
  if (!res.ok) {
    const data = await res.json().catch(() => ({ error: 'Request failed' }))
    throw new Error(data.error || `HTTP ${res.status}`)
  }
  return res.json()
}

export const api = {
  auth: {
    login: (email: string, password: string) =>
      apiFetch<{ token: string; user: User }>('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),
    register: (data: RegisterData) =>
      apiFetch<{ token: string; user: User }>('/auth/register', { method: 'POST', body: JSON.stringify(data) }),
    logout: () => apiFetch('/auth/logout', { method: 'POST' }),
    me: () => apiFetch<User>('/auth/me'),
  },
  servers: {
    list: () => apiFetch<Server[]>('/servers'),
    dashboard: () => apiFetch<ServerDashboard>('/servers/dashboard'),
    get: (id: string) => apiFetch<Server>(`/servers/${id}`),
    power: (id: string, action: string) =>
      apiFetch<{ success: boolean; jobId?: string; status?: string }>(`/servers/${id}/power`, { method: 'POST', body: JSON.stringify({ action }) }),
    sync: (id: string) => apiFetch<{ server: Server; synced: boolean; vmStatus?: any }>(`/servers/${id}/sync`, { method: 'POST' }),
    delete: (id: string) => apiFetch<{ success?: boolean; jobId?: string }>(`/servers/${id}`, { method: 'DELETE' }),
    metrics: (id: string, timeframe = 'hour') => apiFetch<{ data: MetricPoint[]; source: string; timeframe: string }>(`/servers/${id}/metrics?timeframe=${timeframe}`),
    jobs: (id: string) => apiFetch<Job[]>(`/servers/${id}/jobs`),
    getJob: (jobId: string) => apiFetch<Job>(`/servers/jobs/${jobId}`),
    snapshots: (id: string) => apiFetch<{ snapshots: Snapshot[]; proxmoxSnapshots: PveSnapshot[] }>(`/servers/${id}/snapshots`),
    createSnapshot: (id: string, name: string, description?: string) =>
      apiFetch<{ snapId: string; jobId: string }>(`/servers/${id}/snapshots`, { method: 'POST', body: JSON.stringify({ name, description }) }),
    deleteSnapshot: (id: string, snapname: string) =>
      apiFetch<{ jobId: string }>(`/servers/${id}/snapshots/${snapname}`, { method: 'DELETE' }),
    rollbackSnapshot: (id: string, snapname: string) =>
      apiFetch<{ jobId: string }>(`/servers/${id}/snapshots/${snapname}/rollback`, { method: 'POST' }),
  },
  admin: {
    dashboard: () => apiFetch<AdminDashboard>('/admin/dashboard'),
    users: () => apiFetch<User[]>('/admin/users'),
    getUser: (id: string) => apiFetch<User>(`/admin/users/${id}`),
    suspendUser: (id: string) => apiFetch(`/admin/users/${id}/suspend`, { method: 'PUT' }),
    unsuspendUser: (id: string) => apiFetch(`/admin/users/${id}/unsuspend`, { method: 'PUT' }),
    clusters: () => apiFetch<Cluster[]>('/admin/clusters'),
    createCluster: (data: CreateClusterData) =>
      apiFetch<Cluster>('/admin/clusters', { method: 'POST', body: JSON.stringify(data) }),
    testCluster: (id: string) => apiFetch<{ success: boolean; version: any }>(`/admin/clusters/${id}/test`, { method: 'POST' }),
    syncCluster: (id: string) => apiFetch<{ jobId: string }>(`/admin/clusters/${id}/sync`, { method: 'POST' }),
    syncTemplates: (id: string) => apiFetch<{ success: boolean; synced: number }>(`/admin/clusters/${id}/sync-templates`, { method: 'POST' }),
    osLibrary: () => apiFetch<OsLibraryTemplate[]>('/admin/os-library'),
    installOsLibraryTemplate: (clusterId: string, data: { node: string; storage: string; templateKey: string; name?: string; description?: string }) =>
      apiFetch<Template>(`/admin/clusters/${clusterId}/install-library-template`, { method: 'POST', body: JSON.stringify(data) }),
    syncStorage: (id: string) => apiFetch<{ success: boolean; synced: number }>(`/admin/clusters/${id}/sync-storage`, { method: 'POST' }),
    syncBridges: (id: string) => apiFetch<{ success: boolean; synced: number }>(`/admin/clusters/${id}/sync-bridges`, { method: 'POST' }),
    nodes: () => apiFetch<Node[]>('/admin/nodes'),
    updateNode: (id: string, data: Partial<Node>) => apiFetch<Node>(`/admin/nodes/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    syncNode: (id: string) => apiFetch<Node>(`/admin/nodes/${id}/sync`, { method: 'POST' }),
    locations: () => apiFetch<Location[]>('/admin/locations'),
    createLocation: (data: CreateLocationData) =>
      apiFetch<Location>('/admin/locations', { method: 'POST', body: JSON.stringify(data) }),
    allServers: () => apiFetch<Server[]>('/admin/servers'),
    activity: () => apiFetch<ActivityLog[]>('/admin/activity'),
    jobs: () => apiFetch<Job[]>('/admin/jobs'),
    templates: () => apiFetch<Template[]>('/admin/templates'),
    createTemplate: (data: CreateTemplateData) =>
      apiFetch<Template>('/admin/templates', { method: 'POST', body: JSON.stringify(data) }),
    updateTemplate: (id: string, data: Partial<CreateTemplateData>) =>
      apiFetch<Template>(`/admin/templates/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    deleteTemplate: (id: string) =>
      apiFetch<{ success: boolean }>(`/admin/templates/${id}`, { method: 'DELETE' }),
    storage: () => apiFetch<StoragePool[]>('/admin/storage'),
    bridges: () => apiFetch<NetworkBridge[]>('/admin/bridges'),
    alerts: () => apiFetch<AlertItem[]>('/admin/alerts'),
    resolveAlert: (id: string) => apiFetch<{ success: boolean }>(`/admin/alerts/${id}/resolve`, { method: 'POST' }),
    ipPools: () => apiFetch<IpPool[]>('/admin/ip-pools'),
    createIpPool: (data: CreateIpPoolData) =>
      apiFetch<IpPool>('/admin/ip-pools', { method: 'POST', body: JSON.stringify(data) }),
    ipAddresses: (poolId: string) => apiFetch<IpAddress[]>(`/admin/ip-pools/${poolId}/addresses`),
    addIpAddresses: (poolId: string, addresses: string[]) =>
      apiFetch<{ added: number }>(`/admin/ip-pools/${poolId}/addresses`, { method: 'POST', body: JSON.stringify({ addresses }) }),
  },
  provision: {
    create: (data: ProvisionData) =>
      apiFetch<{ serverId: string; jobId: string; vmid: number }>('/provision', { method: 'POST', body: JSON.stringify(data) }),
  },
}

// Augment servers api with timer methods
Object.assign(api.servers, {
  getTimer: (id: string) => apiFetch<{ timer: ServerTimer | null }>(`/servers/${id}/timer`),
  setTimer: (id: string, action: string, minutes: number) =>
    apiFetch<ServerTimer>(`/servers/${id}/timer`, { method: 'POST', body: JSON.stringify({ action, minutes }) }),
  cancelTimer: (id: string) => apiFetch<{ success: boolean }>(`/servers/${id}/timer`, { method: 'DELETE' }),
  // Backups
  backups: (id: string) => apiFetch<Backup[]>(`/servers/${id}/backups`),
  createBackup: (id: string, data: { storage?: string; mode?: string; notes?: string }) =>
    apiFetch<{ backupId: string; jobId: string }>(`/servers/${id}/backups`, { method: 'POST', body: JSON.stringify(data) }),
  deleteBackup: (id: string, backupId: string) =>
    apiFetch<{ jobId: string }>(`/servers/${id}/backups/${backupId}`, { method: 'DELETE' }),
  restoreBackup: (id: string, backupId: string) =>
    apiFetch<{ jobId: string }>(`/servers/${id}/backups/${backupId}/restore`, { method: 'POST' }),
  // Migration
  migrate: (id: string, data: { targetNode: string; targetStorage?: string }) =>
    apiFetch<{ jobId: string }>(`/servers/${id}/migrate`, { method: 'POST', body: JSON.stringify(data) }),
  // Reinstall
  reinstall: (id: string, data: { templateId: string; password?: string; username?: string; sshKeys?: string }) =>
    apiFetch<{ jobId: string }>(`/servers/${id}/reinstall`, { method: 'POST', body: JSON.stringify(data) }),
  // Resize
  resize: (id: string, data: { vcpuCores?: number; ramMb?: number; diskGb?: number }) =>
    apiFetch<{ jobId: string }>(`/servers/${id}/resize`, { method: 'POST', body: JSON.stringify(data) }),
})

// Augment admin api with settings methods
Object.assign(api.admin, {
  getSettings: () => apiFetch<PanelSettings>('/admin/settings'),
  saveSettings: (data: Partial<PanelSettings>) =>
    apiFetch<{ success: boolean }>('/admin/settings', { method: 'PUT', body: JSON.stringify(data) }),
})

// ─── Types ────────────────────────────────────────────────────────────────────

export interface User {
  id: string; email: string; username: string
  firstName: string | null; lastName: string | null
  role: 'superadmin' | 'admin' | 'support' | 'customer'
  emailVerified: boolean; twoFactorEnabled?: boolean
  createdAt?: string; lastLoginAt?: string | null; isActive?: boolean; isSuspended?: boolean
}

export interface RegisterData {
  email: string; username: string; password: string; firstName?: string; lastName?: string
}

export interface Server {
  id: string; userId: string; displayName: string; hostname: string
  vmid: number | null; virtType: 'kvm' | 'lxc'
  status: 'provisioning' | 'running' | 'stopped' | 'suspended' | 'failed' | 'terminating' | 'terminated'
  os: string | null; vcpuCores: number; ramMb: number; diskGb: number
  primaryIpv4: string | null; primaryIpv6: string | null; isSuspended: boolean
  locationId: string | null; nodeId: string | null; clusterId: string | null
  notes: string | null; tags: string | null; expiresAt: string | null
  createdAt: string; updatedAt: string
}

export interface ServerDashboard {
  total: number; running: number; stopped: number; suspended: number
  totalVcpu: number; totalRam: number; totalDisk: number; servers: Server[]
}

export interface MetricPoint {
  time: number; cpu?: number; mem?: number; maxmem?: number
  netin?: number; netout?: number; diskread?: number; diskwrite?: number
}

export interface Job {
  id: string; type: string
  status: 'pending' | 'running' | 'completed' | 'failed'
  serverId: string | null; clusterId: string | null; userId: string | null
  node: string | null; vmid: number | null; upid: string | null
  progress: number; message: string | null; error: string | null
  input: string | null; output: string | null
  createdAt: string; startedAt: string | null; completedAt: string | null
}

export interface Snapshot {
  id: string; serverId: string; name: string; description: string | null
  proxmoxName: string; status: string; createdAt: string
}

export interface PveSnapshot {
  name: string; description: string; parent: string; snaptime: number; running: number
}

export interface AdminDashboard {
  stats: { totalUsers: number; totalServers: number; runningServers: number; stoppedServers: number; suspendedServers: number; totalClusters: number; totalNodes: number; offlineNodes: number }
  recentActivity: ActivityLog[]
}

export interface Cluster {
  id: string; name: string; hostname: string; port: number; protocol?: 'http' | 'https'; tokenId: string
  tlsVerify: boolean; locationId: string | null; isEnabled: boolean
  connectionStatus: string; lastSyncAt: string | null; createdAt: string
}

export interface Node {
  id: string; clusterId: string; name: string; status: 'online' | 'offline' | 'unknown'
  cpuCores: number | null; cpuUsage: number | null; cpuModel: string | null
  totalRam: number | null; usedRam: number | null; guestCount: number
  isMaintenanceMode: boolean; isProvisioningEnabled: boolean
  proxmoxVersion: string | null; uptime: number | null; lastSyncAt: string | null
}

export interface Location {
  id: string; name: string; shortCode: string; country: string; description: string | null; isEnabled: boolean
}

export interface CreateLocationData {
  name: string; shortCode: string; country: string; description?: string; isEnabled?: boolean
}

export interface CreateClusterData {
  name: string; hostname: string; port?: number; protocol?: 'http' | 'https'; tokenId: string; tokenSecret: string; tlsVerify?: boolean; locationId?: string
}

export interface AlertItem {
  id: string; nodeId: string | null; clusterId: string | null; type: string
  severity: 'info' | 'warning' | 'critical'; message: string; isResolved: boolean
  resolvedAt: string | null; createdAt: string
}

export interface ActivityLog {
  id: string; userId: string | null; actorId: string | null; action: string
  targetType: string | null; targetId: string | null; ipAddress: string | null
  metadata: string | null; createdAt: string
}

export interface Template {
  id: string; clusterId: string; node: string; vmid: number | null; volid: string | null
  name: string; osName: string | null; osVersion: string | null
  virtType: 'kvm' | 'lxc'; description: string | null; isEnabled: boolean
  createdAt: string; updatedAt: string
}

export interface OsLibraryTemplate {
  key: string; name: string; description: string; virtType: 'kvm' | 'lxc'
  osName: string; osVersion: string; url: string; filename: string; content: string
}

export interface CreateTemplateData {
  clusterId: string; node: string; vmid?: number; volid?: string; name: string
  osName?: string; osVersion?: string; virtType: 'kvm' | 'lxc'; description?: string; isEnabled?: boolean
}

export interface StoragePool {
  id: string; clusterId: string; node: string; storage: string; type: string | null
  content: string | null; total: number | null; used: number | null; avail: number | null
  status: string; isActive: boolean
}

export interface NetworkBridge {
  id: string; clusterId: string; node: string; iface: string; type: string | null
  cidr: string | null; gateway: string | null; bridgePorts: string | null; isActive: boolean
}

export interface IpPool {
  id: string; name: string; clusterId: string | null; gateway: string; subnet: string
  dns1: string | null; dns2: string | null; bridge: string | null; vlan: number | null
  isIpv6: boolean; isEnabled: boolean; createdAt: string
}

export interface CreateIpPoolData {
  name: string; clusterId?: string; gateway: string; subnet: string
  dns1?: string; dns2?: string; bridge?: string; vlan?: number; isIpv6?: boolean
}

export interface IpAddress {
  id: string; poolId: string; address: string
  status: 'available' | 'reserved' | 'allocated' | 'disabled'; serverId: string | null
  createdAt: string; updatedAt: string
}

export interface ServerTimer {
  id: string; serverId: string; userId: string | null; action: string
  triggerAt: string; status: 'pending' | 'executed' | 'cancelled' | 'failed'; createdAt: string
}

export interface PanelSettings {
  panelName: string; hostname: string; faviconUrl: string
}

export interface Backup {
  id: string; serverId: string; name: string; node: string; storage: string
  volid: string | null; size: number | null; backupType: string
  status: 'creating' | 'available' | 'restoring' | 'deleting' | 'failed'
  proxmoxUpid: string | null; createdAt: string
}

export interface ProvisionData {
  userId: string; clusterId: string; nodeId?: string; templateId: string
  displayName: string; hostname: string; cpuCores: number; ramMb: number; diskGb: number
  storagePool?: string; ipPoolId?: string; password?: string
  username?: string; sshKeys?: string; bridge?: string; nameserver?: string
}
