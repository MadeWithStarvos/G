import { createContext, useContext } from 'react'
import type { User } from './api'

export interface AuthContext {
  user: User | null
  token: string | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (data: { email: string; username: string; password: string; firstName?: string; lastName?: string }) => Promise<void>
  logout: () => void
}

export const AuthCtx = createContext<AuthContext | null>(null)

export function useAuth(): AuthContext {
  const ctx = useContext(AuthCtx)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
