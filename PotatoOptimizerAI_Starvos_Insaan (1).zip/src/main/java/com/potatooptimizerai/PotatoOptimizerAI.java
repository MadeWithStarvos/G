package com.potatooptimizerai;

import net.fabricmc.api.ClientModInitializer;
import com.potatooptimizerai.config.ModConfig;

public class PotatoOptimizerAI implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModConfig.load();
        System.out.println("Potato Optimizer AI loaded by Starvos & Insaan");
    }
}