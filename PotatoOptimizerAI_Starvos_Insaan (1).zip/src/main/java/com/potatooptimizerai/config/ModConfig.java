package com.potatooptimizerai.config;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;

public class ModConfig {
    public static String mode = "BALANCED";
    private static File file = new File("config/potatooptimizerai.txt");

    public static void load() {
        try {
            if (!file.exists()) {
                file.getParentFile().mkdirs();
                FileWriter fw = new FileWriter(file);
                fw.write("mode=BALANCED");
                fw.close();
            }
            String txt = new String(Files.readAllBytes(file.toPath()));
            if (txt.contains("AGGRESSIVE")) mode = "AGGRESSIVE";
            else if (txt.contains("NORMAL")) mode = "NORMAL";
            else mode = "BALANCED";
        } catch (Exception e) {
            mode = "BALANCED";
        }
    }
}