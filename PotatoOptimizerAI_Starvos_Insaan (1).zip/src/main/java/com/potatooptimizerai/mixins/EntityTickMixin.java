package com.potatooptimizerai.mixins;

import com.potatooptimizerai.config.ModConfig;
import net.minecraft.entity.Entity;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class EntityTickMixin {
    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void optimizeEntities(CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        Entity e = (Entity)(Object)this;
        double dist = e.squaredDistanceTo(mc.player);

        if (ModConfig.mode.equals("AGGRESSIVE") && dist > 40*40) ci.cancel();
        if (ModConfig.mode.equals("BALANCED") && dist > 70*70) ci.cancel();
        if (ModConfig.mode.equals("NORMAL") && dist > 100*100) ci.cancel();
    }
}